import 'dart:convert';

class TwitterUser {
  final String runId;
  final String restId;
  final String? name;
  final String? screenName;
  final String? avatarUrl;
  final String? avatarLocalPath;
  final String? bannerUrl;
  final String? bannerLocalPath;
  final String? bio;
  final String? location;
  final String? pinnedTweetIdStr;
  final String? parodyCommentaryFanLabel;
  final String? birthdateYear;
  final String? birthdateMonth;
  final String? birthdateDay;
  final String? automatedScreenName;
  final String? joinedTime;
  final String? link;
  final bool isVerified;
  final bool isProtected;
  final int followersCount;
  final int followingCount;
  final int statusesCount;
  final int listedCount;
  final int favouritesCount;
  final int mediaCount;
  final bool isFollowing;
  final bool isFollower;
  final bool canDm;
  final bool canMediaTag;

  const TwitterUser({
    required this.runId,
    required this.restId,
    this.name,
    this.screenName,
    this.avatarUrl,
    this.avatarLocalPath,
    this.bannerUrl,
    this.bannerLocalPath,
    this.bio,
    this.location,
    this.pinnedTweetIdStr,
    this.parodyCommentaryFanLabel,
    this.birthdateYear,
    this.birthdateMonth,
    this.birthdateDay,
    this.automatedScreenName,
    this.joinedTime,
    this.link,
    this.isVerified = false,
    this.isProtected = false,
    this.followersCount = 0,
    this.followingCount = 0,
    this.statusesCount = 0,
    this.listedCount = 0,
    this.favouritesCount = 0,
    this.mediaCount = 0,
    this.isFollowing = false,
    this.isFollower = false,
    this.canDm = false,
    this.canMediaTag = false,
  });

  factory TwitterUser.fromJson(Map<String, dynamic> json) {
    bool parseBool(dynamic v) {
      if (v == null) return false;
      if (v is bool) return v;
      if (v is num) return v != 0;
      final s = v.toString().toLowerCase();
      return s == 'true' || s == '1' || s == 'yes';
    }

    int parseInt(dynamic v) {
      if (v == null) return 0;
      if (v is int) return v;
      if (v is double) return v.toInt();
      return int.tryParse(v.toString()) ?? 0;
    }

    return TwitterUser(
      runId: json['runId']?.toString() ?? '',
      restId: json['restId']?.toString() ?? '',
      name: json['name'] as String?,
      screenName: json['screenName'] as String?,
      avatarUrl: json['avatarUrl'] as String?,
      avatarLocalPath: json['avatarLocalPath'] as String?,
      bannerUrl: json['bannerUrl'] as String?,
      bannerLocalPath: json['bannerLocalPath'] as String?,
      bio: json['bio'] as String?,
      location: json['location'] as String?,
      pinnedTweetIdStr: json['pinnedTweetIdStr'] as String?,
      parodyCommentaryFanLabel: json['parodyCommentaryFanLabel'] as String?,
      birthdateYear: json['birthdateYear'] as String?,
      birthdateMonth: json['birthdateMonth'] as String?,
      birthdateDay: json['birthdateDay'] as String?,
      automatedScreenName: json['automatedScreenName'] as String?,
      joinedTime: json['joinedTime'] as String?,
      link: json['link'] as String?,
      isVerified: parseBool(json['isVerified']),
      isProtected: parseBool(json['isProtected']),
      followersCount: parseInt(json['followersCount']),
      followingCount: parseInt(json['followingCount']),
      statusesCount: parseInt(json['statusesCount']),
      listedCount: parseInt(json['listedCount']),
      favouritesCount: parseInt(json['favouritesCount']),
      mediaCount: parseInt(json['mediaCount']),
      isFollowing: parseBool(json['isFollowing']),
      isFollower: parseBool(json['isFollower']),
      canDm: parseBool(json['canDm']),
      canMediaTag: parseBool(json['canMediaTag']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'runId': runId,
      'restId': restId,
      'name': name,
      'screenName': screenName,
      'avatarUrl': avatarUrl,
      'avatarLocalPath': avatarLocalPath,
      'bannerUrl': bannerUrl,
      'bannerLocalPath': bannerLocalPath,
      'bio': bio,
      'location': location,
      'pinnedTweetIdStr': pinnedTweetIdStr,
      'parodyCommentaryFanLabel': parodyCommentaryFanLabel,
      'birthdateYear': birthdateYear,
      'birthdateMonth': birthdateMonth,
      'birthdateDay': birthdateDay,
      'automatedScreenName': automatedScreenName,
      'joinedTime': joinedTime,
      'link': link,
      'isVerified': isVerified,
      'isProtected': isProtected,
      'followersCount': followersCount,
      'followingCount': followingCount,
      'statusesCount': statusesCount,
      'listedCount': listedCount,
      'favouritesCount': favouritesCount,
      'mediaCount': mediaCount,
      'isFollowing': isFollowing,
      'isFollower': isFollower,
      'canDm': canDm,
      'canMediaTag': canMediaTag,
    };
  }

  // --- 新增的辅助方法 ---

  Map<String, dynamic> profileAsMap() => {
        'name': name,
        'screenName': screenName,
        'avatarUrl': avatarUrl,
        'bannerUrl': bannerUrl,
        'bio': bio,
        'location': location,
        'pinnedTweetIdStr': pinnedTweetIdStr,
        'parodyCommentaryFanLabel': parodyCommentaryFanLabel,
        'birthdateYear': birthdateYear,
        'birthdateMonth': birthdateMonth,
        'birthdateDay': birthdateDay,
        'automatedScreenName': automatedScreenName,
        'joinedTime': joinedTime,
        'link': link,
        'isVerified': isVerified,
        'isProtected': isProtected,
      };

  Map<String, dynamic> statisticsAsMap() => {
        'followersCount': followersCount,
        'followingCount': followingCount,
        'statusesCount': statusesCount,
        'listedCount': listedCount,
        'favouritesCount': favouritesCount,
        'mediaCount': mediaCount,
      };

  String profileAsJson() => jsonEncode(profileAsMap());
  String statisticsAsJson() => jsonEncode(statisticsAsMap());
}