class Account {
  final String? latestRawJson;
  final String id;
  final String cookie;
  final String? name;
  final String? screenName;
  final String? avatarUrl;
  final String? avatarLocalPath;
  final String? bannerUrl;
  final String? bannerLocalPath;
  final String? bio;
  final String? location;
  final String? link;
  final String? joinTime;
  final int followersCount;
  final int followingCount;
  final int statusesCount;
  final int mediaCount;
  final int favouritesCount;
  final int listedCount;
  final bool isVerified;
  final bool isProtected;

  final String? pinnedTweetIdStr;
  final String? parodyCommentaryFanLabel;
  final String? birthdateYear;
  final String? birthdateMonth;
  final String? birthdateDay;
  final String? automatedScreenName;

  Account({
    required this.id,
    required this.cookie,
    this.name,
    this.screenName,
    this.avatarUrl,
    this.avatarLocalPath,
    this.bannerUrl,
    this.bannerLocalPath,
    this.bio,
    this.location,
    this.link,
    this.joinTime,
    this.followersCount = 0,
    this.followingCount = 0,
    this.statusesCount = 0,
    this.mediaCount = 0,
    this.favouritesCount = 0,
    this.listedCount = 0,
    this.latestRawJson,
    this.isVerified = false,
    this.isProtected = false,
    this.pinnedTweetIdStr,
    this.parodyCommentaryFanLabel,
    this.birthdateYear,
    this.birthdateMonth,
    this.birthdateDay,
    this.automatedScreenName,
  });

  factory Account.fromJson(Map<String, dynamic> json) {
    return Account(
      id: json['id'] as String? ?? '',
      cookie: json['cookie'] as String? ?? '',
      name: json['name'] as String?,
      screenName: json['screenName'] as String?,
      avatarUrl: json['avatarUrl'] as String?,
      avatarLocalPath: json['avatarLocalPath'] as String?,
      bannerUrl: json['bannerUrl'] as String?,
      bannerLocalPath: json['bannerLocalPath'] as String?,
      bio: json['bio'] as String?,
      location: json['location'] as String?,
      link: json['link'] as String?,
      joinTime: json['joinTime'] as String?,
      followersCount: json['followersCount'] as int? ?? 0,
      followingCount: json['followingCount'] as int? ?? 0,
      statusesCount: json['statusesCount'] ?? 0,
      mediaCount: json['mediaCount'] ?? 0,
      favouritesCount: json['favouritesCount'] ?? 0,
      listedCount: json['listedCount'] ?? 0,
      latestRawJson: json['latestRawJson'] as String?,
      isVerified: json['verified'] as bool? ?? false,
      isProtected: json['protected'] as bool? ?? false,
      pinnedTweetIdStr: json['pinnedTweetIdStr'] as String?,
      parodyCommentaryFanLabel: json['parodyCommentaryFanLabel'] as String?,
      birthdateYear: json['birthdateYear'] as String?,
      birthdateMonth: json['birthdateMonth'] as String?,
      birthdateDay: json['birthdateDay'] as String?,
      automatedScreenName: json['automatedScreenName'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'cookie': cookie,
      'name': name,
      'screenName': screenName,
      'avatarUrl': avatarUrl,
      'avatarLocalPath': avatarLocalPath,
      'bannerUrl': bannerUrl,
      'bannerLocalPath': bannerLocalPath,
      'bio': bio,
      'location': location,
      'link': link,
      'joinTime': joinTime,
      'followersCount': followersCount,
      'followingCount': followingCount,
      'statusesCount': statusesCount,
      'mediaCount': mediaCount,
      'favouritesCount': favouritesCount,
      'listedCount': listedCount,
      'latestRawJson': latestRawJson,
      'verified': isVerified,
      'protected': isProtected,
      'pinnedTweetIdStr': pinnedTweetIdStr,
      'parodyCommentaryFanLabel': parodyCommentaryFanLabel,
      'birthdateYear': birthdateYear,
      'birthdateMonth': birthdateMonth,
      'birthdateDay': birthdateDay,
      'automatedScreenName': automatedScreenName,
    };
  }

  Account copyWith({
    String? id,
    String? cookie,
    String? name,
    String? screenName,
    String? avatarUrl,
    String? avatarLocalPath,
    String? bannerUrl,
    String? bannerLocalPath,
    String? bio,
    String? location,
    String? link,
    String? joinTime,
    int? followersCount,
    int? followingCount,
    int? statusesCount,
    int? mediaCount,
    int? favouritesCount,
    int? listedCount,
    String? latestRawJson,
    bool? isProtected,
    bool? isVerified,
    String? pinnedTweetIdStr,
    String? parodyCommentaryFanLabel,
    String? birthdateYear,
    String? birthdateMonth,
    String? birthdateDay,
    String? automatedScreenName,
  }) {
    return Account(
      id: id ?? this.id,
      cookie: cookie ?? this.cookie,
      name: name ?? this.name,
      screenName: screenName ?? this.screenName,
      avatarUrl: avatarUrl ?? this.avatarUrl,
      avatarLocalPath: avatarLocalPath ?? this.avatarLocalPath,
      bannerUrl: bannerUrl ?? this.bannerUrl,
      bannerLocalPath: bannerLocalPath ?? this.bannerLocalPath,
      bio: bio ?? this.bio,
      location: location ?? this.location,
      link: link ?? this.link,
      joinTime: joinTime ?? this.joinTime,
      followersCount: followersCount ?? this.followersCount,
      followingCount: followingCount ?? this.followingCount,
      statusesCount: statusesCount ?? this.statusesCount,
      mediaCount: mediaCount ?? this.mediaCount,
      favouritesCount: favouritesCount ?? this.favouritesCount,
      listedCount: listedCount ?? this.listedCount,
      latestRawJson: latestRawJson ?? this.latestRawJson,
      isVerified: isVerified ?? this.isVerified,
      isProtected: isProtected ?? this.isProtected,
      pinnedTweetIdStr: pinnedTweetIdStr ?? this.pinnedTweetIdStr,
      parodyCommentaryFanLabel:
          parodyCommentaryFanLabel ?? this.parodyCommentaryFanLabel,
      birthdateYear: birthdateYear ?? this.birthdateYear,
      birthdateMonth: birthdateMonth ?? this.birthdateMonth,
      birthdateDay: birthdateDay ?? this.birthdateDay,
      automatedScreenName: automatedScreenName ?? this.automatedScreenName,
    );
  }

  @override
  String toString() {
    return 'Account(id: $id, name: $name, screenName: $screenName, avatarUrl: $avatarUrl, cookie: ${cookie.length > 10 ? '${cookie.substring(0, 10)}...' : cookie})';
  }
}