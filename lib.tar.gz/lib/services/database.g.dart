// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $LoggedAccountsTable extends LoggedAccounts
    with TableInfo<$LoggedAccountsTable, LoggedAccount> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $LoggedAccountsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _restIdMeta = const VerificationMeta('restId');
  @override
  late final GeneratedColumn<String> restId = GeneratedColumn<String>(
    'rest_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [restId];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'logged_accounts';
  @override
  VerificationContext validateIntegrity(
    Insertable<LoggedAccount> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('rest_id')) {
      context.handle(
        _restIdMeta,
        restId.isAcceptableOrUnknown(data['rest_id']!, _restIdMeta),
      );
    } else if (isInserting) {
      context.missing(_restIdMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {restId};
  @override
  LoggedAccount map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return LoggedAccount(
      restId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}rest_id'],
      )!,
    );
  }

  @override
  $LoggedAccountsTable createAlias(String alias) {
    return $LoggedAccountsTable(attachedDatabase, alias);
  }
}

class LoggedAccount extends DataClass implements Insertable<LoggedAccount> {
  final String restId;
  const LoggedAccount({required this.restId});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['rest_id'] = Variable<String>(restId);
    return map;
  }

  LoggedAccountsCompanion toCompanion(bool nullToAbsent) {
    return LoggedAccountsCompanion(restId: Value(restId));
  }

  factory LoggedAccount.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return LoggedAccount(restId: serializer.fromJson<String>(json['restId']));
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{'restId': serializer.toJson<String>(restId)};
  }

  LoggedAccount copyWith({String? restId}) =>
      LoggedAccount(restId: restId ?? this.restId);
  LoggedAccount copyWithCompanion(LoggedAccountsCompanion data) {
    return LoggedAccount(
      restId: data.restId.present ? data.restId.value : this.restId,
    );
  }

  @override
  String toString() {
    return (StringBuffer('LoggedAccount(')
          ..write('restId: $restId')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => restId.hashCode;
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is LoggedAccount && other.restId == this.restId);
}

class LoggedAccountsCompanion extends UpdateCompanion<LoggedAccount> {
  final Value<String> restId;
  final Value<int> rowid;
  const LoggedAccountsCompanion({
    this.restId = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  LoggedAccountsCompanion.insert({
    required String restId,
    this.rowid = const Value.absent(),
  }) : restId = Value(restId);
  static Insertable<LoggedAccount> custom({
    Expression<String>? restId,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (restId != null) 'rest_id': restId,
      if (rowid != null) 'rowid': rowid,
    });
  }

  LoggedAccountsCompanion copyWith({Value<String>? restId, Value<int>? rowid}) {
    return LoggedAccountsCompanion(
      restId: restId ?? this.restId,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (restId.present) {
      map['rest_id'] = Variable<String>(restId.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('LoggedAccountsCompanion(')
          ..write('restId: $restId, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $TwiUserProfileTable extends TwiUserProfile
    with TableInfo<$TwiUserProfileTable, TwiUserProfileEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TwiUserProfileTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    false,
    hasAutoIncrement: true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'PRIMARY KEY AUTOINCREMENT',
    ),
  );
  static const VerificationMeta _runIdMeta = const VerificationMeta('runId');
  @override
  late final GeneratedColumn<String> runId = GeneratedColumn<String>(
    'run_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _restIdMeta = const VerificationMeta('restId');
  @override
  late final GeneratedColumn<String> restId = GeneratedColumn<String>(
    'rest_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
    'name',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _screenNameMeta = const VerificationMeta(
    'screenName',
  );
  @override
  late final GeneratedColumn<String> screenName = GeneratedColumn<String>(
    'screen_name',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _avatarUrlMeta = const VerificationMeta(
    'avatarUrl',
  );
  @override
  late final GeneratedColumn<String> avatarUrl = GeneratedColumn<String>(
    'avatar_url',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _bannerUrlMeta = const VerificationMeta(
    'bannerUrl',
  );
  @override
  late final GeneratedColumn<String> bannerUrl = GeneratedColumn<String>(
    'banner_url',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _bioMeta = const VerificationMeta('bio');
  @override
  late final GeneratedColumn<String> bio = GeneratedColumn<String>(
    'bio',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _linkMeta = const VerificationMeta('link');
  @override
  late final GeneratedColumn<String> link = GeneratedColumn<String>(
    'link',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _avatarLocalPathMeta = const VerificationMeta(
    'avatarLocalPath',
  );
  @override
  late final GeneratedColumn<String> avatarLocalPath = GeneratedColumn<String>(
    'avatar_local_path',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _bannerLocalPathMeta = const VerificationMeta(
    'bannerLocalPath',
  );
  @override
  late final GeneratedColumn<String> bannerLocalPath = GeneratedColumn<String>(
    'banner_local_path',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _locationMeta = const VerificationMeta(
    'location',
  );
  @override
  late final GeneratedColumn<String> location = GeneratedColumn<String>(
    'location',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pinnedTweetIdStrMeta = const VerificationMeta(
    'pinnedTweetIdStr',
  );
  @override
  late final GeneratedColumn<String> pinnedTweetIdStr = GeneratedColumn<String>(
    'pinned_tweet_id_str',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _parodyCommentaryFanLabelMeta =
      const VerificationMeta('parodyCommentaryFanLabel');
  @override
  late final GeneratedColumn<String> parodyCommentaryFanLabel =
      GeneratedColumn<String>(
        'parody_commentary_fan_label',
        aliasedName,
        true,
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _birthdateYearMeta = const VerificationMeta(
    'birthdateYear',
  );
  @override
  late final GeneratedColumn<String> birthdateYear = GeneratedColumn<String>(
    'birthdate_year',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _birthdateMonthMeta = const VerificationMeta(
    'birthdateMonth',
  );
  @override
  late final GeneratedColumn<String> birthdateMonth = GeneratedColumn<String>(
    'birthdate_month',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _birthdateDayMeta = const VerificationMeta(
    'birthdateDay',
  );
  @override
  late final GeneratedColumn<String> birthdateDay = GeneratedColumn<String>(
    'birthdate_day',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _automatedScreenNameMeta =
      const VerificationMeta('automatedScreenName');
  @override
  late final GeneratedColumn<String> automatedScreenName =
      GeneratedColumn<String>(
        'automated_screen_name',
        aliasedName,
        true,
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _joinedTimeMeta = const VerificationMeta(
    'joinedTime',
  );
  @override
  late final GeneratedColumn<String> joinedTime = GeneratedColumn<String>(
    'joined_time',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _isVerifiedMeta = const VerificationMeta(
    'isVerified',
  );
  @override
  late final GeneratedColumn<bool> isVerified = GeneratedColumn<bool>(
    'is_verified',
    aliasedName,
    false,
    type: DriftSqlType.bool,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'CHECK ("is_verified" IN (0, 1))',
    ),
    defaultValue: const Constant(false),
  );
  static const VerificationMeta _isProtectedMeta = const VerificationMeta(
    'isProtected',
  );
  @override
  late final GeneratedColumn<bool> isProtected = GeneratedColumn<bool>(
    'is_protected',
    aliasedName,
    false,
    type: DriftSqlType.bool,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'CHECK ("is_protected" IN (0, 1))',
    ),
    defaultValue: const Constant(false),
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    runId,
    restId,
    name,
    screenName,
    avatarUrl,
    bannerUrl,
    bio,
    link,
    avatarLocalPath,
    bannerLocalPath,
    location,
    pinnedTweetIdStr,
    parodyCommentaryFanLabel,
    birthdateYear,
    birthdateMonth,
    birthdateDay,
    automatedScreenName,
    joinedTime,
    isVerified,
    isProtected,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'twi_user_profile';
  @override
  VerificationContext validateIntegrity(
    Insertable<TwiUserProfileEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('run_id')) {
      context.handle(
        _runIdMeta,
        runId.isAcceptableOrUnknown(data['run_id']!, _runIdMeta),
      );
    } else if (isInserting) {
      context.missing(_runIdMeta);
    }
    if (data.containsKey('rest_id')) {
      context.handle(
        _restIdMeta,
        restId.isAcceptableOrUnknown(data['rest_id']!, _restIdMeta),
      );
    } else if (isInserting) {
      context.missing(_restIdMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
        _nameMeta,
        name.isAcceptableOrUnknown(data['name']!, _nameMeta),
      );
    }
    if (data.containsKey('screen_name')) {
      context.handle(
        _screenNameMeta,
        screenName.isAcceptableOrUnknown(data['screen_name']!, _screenNameMeta),
      );
    }
    if (data.containsKey('avatar_url')) {
      context.handle(
        _avatarUrlMeta,
        avatarUrl.isAcceptableOrUnknown(data['avatar_url']!, _avatarUrlMeta),
      );
    }
    if (data.containsKey('banner_url')) {
      context.handle(
        _bannerUrlMeta,
        bannerUrl.isAcceptableOrUnknown(data['banner_url']!, _bannerUrlMeta),
      );
    }
    if (data.containsKey('bio')) {
      context.handle(
        _bioMeta,
        bio.isAcceptableOrUnknown(data['bio']!, _bioMeta),
      );
    }
    if (data.containsKey('link')) {
      context.handle(
        _linkMeta,
        link.isAcceptableOrUnknown(data['link']!, _linkMeta),
      );
    }
    if (data.containsKey('avatar_local_path')) {
      context.handle(
        _avatarLocalPathMeta,
        avatarLocalPath.isAcceptableOrUnknown(
          data['avatar_local_path']!,
          _avatarLocalPathMeta,
        ),
      );
    }
    if (data.containsKey('banner_local_path')) {
      context.handle(
        _bannerLocalPathMeta,
        bannerLocalPath.isAcceptableOrUnknown(
          data['banner_local_path']!,
          _bannerLocalPathMeta,
        ),
      );
    }
    if (data.containsKey('location')) {
      context.handle(
        _locationMeta,
        location.isAcceptableOrUnknown(data['location']!, _locationMeta),
      );
    }
    if (data.containsKey('pinned_tweet_id_str')) {
      context.handle(
        _pinnedTweetIdStrMeta,
        pinnedTweetIdStr.isAcceptableOrUnknown(
          data['pinned_tweet_id_str']!,
          _pinnedTweetIdStrMeta,
        ),
      );
    }
    if (data.containsKey('parody_commentary_fan_label')) {
      context.handle(
        _parodyCommentaryFanLabelMeta,
        parodyCommentaryFanLabel.isAcceptableOrUnknown(
          data['parody_commentary_fan_label']!,
          _parodyCommentaryFanLabelMeta,
        ),
      );
    }
    if (data.containsKey('birthdate_year')) {
      context.handle(
        _birthdateYearMeta,
        birthdateYear.isAcceptableOrUnknown(
          data['birthdate_year']!,
          _birthdateYearMeta,
        ),
      );
    }
    if (data.containsKey('birthdate_month')) {
      context.handle(
        _birthdateMonthMeta,
        birthdateMonth.isAcceptableOrUnknown(
          data['birthdate_month']!,
          _birthdateMonthMeta,
        ),
      );
    }
    if (data.containsKey('birthdate_day')) {
      context.handle(
        _birthdateDayMeta,
        birthdateDay.isAcceptableOrUnknown(
          data['birthdate_day']!,
          _birthdateDayMeta,
        ),
      );
    }
    if (data.containsKey('automated_screen_name')) {
      context.handle(
        _automatedScreenNameMeta,
        automatedScreenName.isAcceptableOrUnknown(
          data['automated_screen_name']!,
          _automatedScreenNameMeta,
        ),
      );
    }
    if (data.containsKey('joined_time')) {
      context.handle(
        _joinedTimeMeta,
        joinedTime.isAcceptableOrUnknown(data['joined_time']!, _joinedTimeMeta),
      );
    }
    if (data.containsKey('is_verified')) {
      context.handle(
        _isVerifiedMeta,
        isVerified.isAcceptableOrUnknown(data['is_verified']!, _isVerifiedMeta),
      );
    }
    if (data.containsKey('is_protected')) {
      context.handle(
        _isProtectedMeta,
        isProtected.isAcceptableOrUnknown(
          data['is_protected']!,
          _isProtectedMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TwiUserProfileEntry map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TwiUserProfileEntry(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      )!,
      runId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}run_id'],
      )!,
      restId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}rest_id'],
      )!,
      name: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}name'],
      ),
      screenName: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}screen_name'],
      ),
      avatarUrl: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}avatar_url'],
      ),
      bannerUrl: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}banner_url'],
      ),
      bio: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}bio'],
      ),
      link: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}link'],
      ),
      avatarLocalPath: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}avatar_local_path'],
      ),
      bannerLocalPath: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}banner_local_path'],
      ),
      location: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}location'],
      ),
      pinnedTweetIdStr: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pinned_tweet_id_str'],
      ),
      parodyCommentaryFanLabel: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}parody_commentary_fan_label'],
      ),
      birthdateYear: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}birthdate_year'],
      ),
      birthdateMonth: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}birthdate_month'],
      ),
      birthdateDay: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}birthdate_day'],
      ),
      automatedScreenName: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}automated_screen_name'],
      ),
      joinedTime: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}joined_time'],
      ),
      isVerified: attachedDatabase.typeMapping.read(
        DriftSqlType.bool,
        data['${effectivePrefix}is_verified'],
      )!,
      isProtected: attachedDatabase.typeMapping.read(
        DriftSqlType.bool,
        data['${effectivePrefix}is_protected'],
      )!,
    );
  }

  @override
  $TwiUserProfileTable createAlias(String alias) {
    return $TwiUserProfileTable(attachedDatabase, alias);
  }
}

class TwiUserProfileEntry extends DataClass
    implements Insertable<TwiUserProfileEntry> {
  final int id;
  final String runId;
  final String restId;
  final String? name;
  final String? screenName;
  final String? avatarUrl;
  final String? bannerUrl;
  final String? bio;
  final String? link;
  final String? avatarLocalPath;
  final String? bannerLocalPath;
  final String? location;
  final String? pinnedTweetIdStr;
  final String? parodyCommentaryFanLabel;
  final String? birthdateYear;
  final String? birthdateMonth;
  final String? birthdateDay;
  final String? automatedScreenName;
  final String? joinedTime;
  final bool isVerified;
  final bool isProtected;
  const TwiUserProfileEntry({
    required this.id,
    required this.runId,
    required this.restId,
    this.name,
    this.screenName,
    this.avatarUrl,
    this.bannerUrl,
    this.bio,
    this.link,
    this.avatarLocalPath,
    this.bannerLocalPath,
    this.location,
    this.pinnedTweetIdStr,
    this.parodyCommentaryFanLabel,
    this.birthdateYear,
    this.birthdateMonth,
    this.birthdateDay,
    this.automatedScreenName,
    this.joinedTime,
    required this.isVerified,
    required this.isProtected,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['run_id'] = Variable<String>(runId);
    map['rest_id'] = Variable<String>(restId);
    if (!nullToAbsent || name != null) {
      map['name'] = Variable<String>(name);
    }
    if (!nullToAbsent || screenName != null) {
      map['screen_name'] = Variable<String>(screenName);
    }
    if (!nullToAbsent || avatarUrl != null) {
      map['avatar_url'] = Variable<String>(avatarUrl);
    }
    if (!nullToAbsent || bannerUrl != null) {
      map['banner_url'] = Variable<String>(bannerUrl);
    }
    if (!nullToAbsent || bio != null) {
      map['bio'] = Variable<String>(bio);
    }
    if (!nullToAbsent || link != null) {
      map['link'] = Variable<String>(link);
    }
    if (!nullToAbsent || avatarLocalPath != null) {
      map['avatar_local_path'] = Variable<String>(avatarLocalPath);
    }
    if (!nullToAbsent || bannerLocalPath != null) {
      map['banner_local_path'] = Variable<String>(bannerLocalPath);
    }
    if (!nullToAbsent || location != null) {
      map['location'] = Variable<String>(location);
    }
    if (!nullToAbsent || pinnedTweetIdStr != null) {
      map['pinned_tweet_id_str'] = Variable<String>(pinnedTweetIdStr);
    }
    if (!nullToAbsent || parodyCommentaryFanLabel != null) {
      map['parody_commentary_fan_label'] = Variable<String>(
        parodyCommentaryFanLabel,
      );
    }
    if (!nullToAbsent || birthdateYear != null) {
      map['birthdate_year'] = Variable<String>(birthdateYear);
    }
    if (!nullToAbsent || birthdateMonth != null) {
      map['birthdate_month'] = Variable<String>(birthdateMonth);
    }
    if (!nullToAbsent || birthdateDay != null) {
      map['birthdate_day'] = Variable<String>(birthdateDay);
    }
    if (!nullToAbsent || automatedScreenName != null) {
      map['automated_screen_name'] = Variable<String>(automatedScreenName);
    }
    if (!nullToAbsent || joinedTime != null) {
      map['joined_time'] = Variable<String>(joinedTime);
    }
    map['is_verified'] = Variable<bool>(isVerified);
    map['is_protected'] = Variable<bool>(isProtected);
    return map;
  }

  TwiUserProfileCompanion toCompanion(bool nullToAbsent) {
    return TwiUserProfileCompanion(
      id: Value(id),
      runId: Value(runId),
      restId: Value(restId),
      name: name == null && nullToAbsent ? const Value.absent() : Value(name),
      screenName: screenName == null && nullToAbsent
          ? const Value.absent()
          : Value(screenName),
      avatarUrl: avatarUrl == null && nullToAbsent
          ? const Value.absent()
          : Value(avatarUrl),
      bannerUrl: bannerUrl == null && nullToAbsent
          ? const Value.absent()
          : Value(bannerUrl),
      bio: bio == null && nullToAbsent ? const Value.absent() : Value(bio),
      link: link == null && nullToAbsent ? const Value.absent() : Value(link),
      avatarLocalPath: avatarLocalPath == null && nullToAbsent
          ? const Value.absent()
          : Value(avatarLocalPath),
      bannerLocalPath: bannerLocalPath == null && nullToAbsent
          ? const Value.absent()
          : Value(bannerLocalPath),
      location: location == null && nullToAbsent
          ? const Value.absent()
          : Value(location),
      pinnedTweetIdStr: pinnedTweetIdStr == null && nullToAbsent
          ? const Value.absent()
          : Value(pinnedTweetIdStr),
      parodyCommentaryFanLabel: parodyCommentaryFanLabel == null && nullToAbsent
          ? const Value.absent()
          : Value(parodyCommentaryFanLabel),
      birthdateYear: birthdateYear == null && nullToAbsent
          ? const Value.absent()
          : Value(birthdateYear),
      birthdateMonth: birthdateMonth == null && nullToAbsent
          ? const Value.absent()
          : Value(birthdateMonth),
      birthdateDay: birthdateDay == null && nullToAbsent
          ? const Value.absent()
          : Value(birthdateDay),
      automatedScreenName: automatedScreenName == null && nullToAbsent
          ? const Value.absent()
          : Value(automatedScreenName),
      joinedTime: joinedTime == null && nullToAbsent
          ? const Value.absent()
          : Value(joinedTime),
      isVerified: Value(isVerified),
      isProtected: Value(isProtected),
    );
  }

  factory TwiUserProfileEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TwiUserProfileEntry(
      id: serializer.fromJson<int>(json['id']),
      runId: serializer.fromJson<String>(json['runId']),
      restId: serializer.fromJson<String>(json['restId']),
      name: serializer.fromJson<String?>(json['name']),
      screenName: serializer.fromJson<String?>(json['screenName']),
      avatarUrl: serializer.fromJson<String?>(json['avatarUrl']),
      bannerUrl: serializer.fromJson<String?>(json['bannerUrl']),
      bio: serializer.fromJson<String?>(json['bio']),
      link: serializer.fromJson<String?>(json['link']),
      avatarLocalPath: serializer.fromJson<String?>(json['avatarLocalPath']),
      bannerLocalPath: serializer.fromJson<String?>(json['bannerLocalPath']),
      location: serializer.fromJson<String?>(json['location']),
      pinnedTweetIdStr: serializer.fromJson<String?>(json['pinnedTweetIdStr']),
      parodyCommentaryFanLabel: serializer.fromJson<String?>(
        json['parodyCommentaryFanLabel'],
      ),
      birthdateYear: serializer.fromJson<String?>(json['birthdateYear']),
      birthdateMonth: serializer.fromJson<String?>(json['birthdateMonth']),
      birthdateDay: serializer.fromJson<String?>(json['birthdateDay']),
      automatedScreenName: serializer.fromJson<String?>(
        json['automatedScreenName'],
      ),
      joinedTime: serializer.fromJson<String?>(json['joinedTime']),
      isVerified: serializer.fromJson<bool>(json['isVerified']),
      isProtected: serializer.fromJson<bool>(json['isProtected']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'runId': serializer.toJson<String>(runId),
      'restId': serializer.toJson<String>(restId),
      'name': serializer.toJson<String?>(name),
      'screenName': serializer.toJson<String?>(screenName),
      'avatarUrl': serializer.toJson<String?>(avatarUrl),
      'bannerUrl': serializer.toJson<String?>(bannerUrl),
      'bio': serializer.toJson<String?>(bio),
      'link': serializer.toJson<String?>(link),
      'avatarLocalPath': serializer.toJson<String?>(avatarLocalPath),
      'bannerLocalPath': serializer.toJson<String?>(bannerLocalPath),
      'location': serializer.toJson<String?>(location),
      'pinnedTweetIdStr': serializer.toJson<String?>(pinnedTweetIdStr),
      'parodyCommentaryFanLabel': serializer.toJson<String?>(
        parodyCommentaryFanLabel,
      ),
      'birthdateYear': serializer.toJson<String?>(birthdateYear),
      'birthdateMonth': serializer.toJson<String?>(birthdateMonth),
      'birthdateDay': serializer.toJson<String?>(birthdateDay),
      'automatedScreenName': serializer.toJson<String?>(automatedScreenName),
      'joinedTime': serializer.toJson<String?>(joinedTime),
      'isVerified': serializer.toJson<bool>(isVerified),
      'isProtected': serializer.toJson<bool>(isProtected),
    };
  }

  TwiUserProfileEntry copyWith({
    int? id,
    String? runId,
    String? restId,
    Value<String?> name = const Value.absent(),
    Value<String?> screenName = const Value.absent(),
    Value<String?> avatarUrl = const Value.absent(),
    Value<String?> bannerUrl = const Value.absent(),
    Value<String?> bio = const Value.absent(),
    Value<String?> link = const Value.absent(),
    Value<String?> avatarLocalPath = const Value.absent(),
    Value<String?> bannerLocalPath = const Value.absent(),
    Value<String?> location = const Value.absent(),
    Value<String?> pinnedTweetIdStr = const Value.absent(),
    Value<String?> parodyCommentaryFanLabel = const Value.absent(),
    Value<String?> birthdateYear = const Value.absent(),
    Value<String?> birthdateMonth = const Value.absent(),
    Value<String?> birthdateDay = const Value.absent(),
    Value<String?> automatedScreenName = const Value.absent(),
    Value<String?> joinedTime = const Value.absent(),
    bool? isVerified,
    bool? isProtected,
  }) => TwiUserProfileEntry(
    id: id ?? this.id,
    runId: runId ?? this.runId,
    restId: restId ?? this.restId,
    name: name.present ? name.value : this.name,
    screenName: screenName.present ? screenName.value : this.screenName,
    avatarUrl: avatarUrl.present ? avatarUrl.value : this.avatarUrl,
    bannerUrl: bannerUrl.present ? bannerUrl.value : this.bannerUrl,
    bio: bio.present ? bio.value : this.bio,
    link: link.present ? link.value : this.link,
    avatarLocalPath: avatarLocalPath.present
        ? avatarLocalPath.value
        : this.avatarLocalPath,
    bannerLocalPath: bannerLocalPath.present
        ? bannerLocalPath.value
        : this.bannerLocalPath,
    location: location.present ? location.value : this.location,
    pinnedTweetIdStr: pinnedTweetIdStr.present
        ? pinnedTweetIdStr.value
        : this.pinnedTweetIdStr,
    parodyCommentaryFanLabel: parodyCommentaryFanLabel.present
        ? parodyCommentaryFanLabel.value
        : this.parodyCommentaryFanLabel,
    birthdateYear: birthdateYear.present
        ? birthdateYear.value
        : this.birthdateYear,
    birthdateMonth: birthdateMonth.present
        ? birthdateMonth.value
        : this.birthdateMonth,
    birthdateDay: birthdateDay.present ? birthdateDay.value : this.birthdateDay,
    automatedScreenName: automatedScreenName.present
        ? automatedScreenName.value
        : this.automatedScreenName,
    joinedTime: joinedTime.present ? joinedTime.value : this.joinedTime,
    isVerified: isVerified ?? this.isVerified,
    isProtected: isProtected ?? this.isProtected,
  );
  TwiUserProfileEntry copyWithCompanion(TwiUserProfileCompanion data) {
    return TwiUserProfileEntry(
      id: data.id.present ? data.id.value : this.id,
      runId: data.runId.present ? data.runId.value : this.runId,
      restId: data.restId.present ? data.restId.value : this.restId,
      name: data.name.present ? data.name.value : this.name,
      screenName: data.screenName.present
          ? data.screenName.value
          : this.screenName,
      avatarUrl: data.avatarUrl.present ? data.avatarUrl.value : this.avatarUrl,
      bannerUrl: data.bannerUrl.present ? data.bannerUrl.value : this.bannerUrl,
      bio: data.bio.present ? data.bio.value : this.bio,
      link: data.link.present ? data.link.value : this.link,
      avatarLocalPath: data.avatarLocalPath.present
          ? data.avatarLocalPath.value
          : this.avatarLocalPath,
      bannerLocalPath: data.bannerLocalPath.present
          ? data.bannerLocalPath.value
          : this.bannerLocalPath,
      location: data.location.present ? data.location.value : this.location,
      pinnedTweetIdStr: data.pinnedTweetIdStr.present
          ? data.pinnedTweetIdStr.value
          : this.pinnedTweetIdStr,
      parodyCommentaryFanLabel: data.parodyCommentaryFanLabel.present
          ? data.parodyCommentaryFanLabel.value
          : this.parodyCommentaryFanLabel,
      birthdateYear: data.birthdateYear.present
          ? data.birthdateYear.value
          : this.birthdateYear,
      birthdateMonth: data.birthdateMonth.present
          ? data.birthdateMonth.value
          : this.birthdateMonth,
      birthdateDay: data.birthdateDay.present
          ? data.birthdateDay.value
          : this.birthdateDay,
      automatedScreenName: data.automatedScreenName.present
          ? data.automatedScreenName.value
          : this.automatedScreenName,
      joinedTime: data.joinedTime.present
          ? data.joinedTime.value
          : this.joinedTime,
      isVerified: data.isVerified.present
          ? data.isVerified.value
          : this.isVerified,
      isProtected: data.isProtected.present
          ? data.isProtected.value
          : this.isProtected,
    );
  }

  @override
  String toString() {
    return (StringBuffer('TwiUserProfileEntry(')
          ..write('id: $id, ')
          ..write('runId: $runId, ')
          ..write('restId: $restId, ')
          ..write('name: $name, ')
          ..write('screenName: $screenName, ')
          ..write('avatarUrl: $avatarUrl, ')
          ..write('bannerUrl: $bannerUrl, ')
          ..write('bio: $bio, ')
          ..write('link: $link, ')
          ..write('avatarLocalPath: $avatarLocalPath, ')
          ..write('bannerLocalPath: $bannerLocalPath, ')
          ..write('location: $location, ')
          ..write('pinnedTweetIdStr: $pinnedTweetIdStr, ')
          ..write('parodyCommentaryFanLabel: $parodyCommentaryFanLabel, ')
          ..write('birthdateYear: $birthdateYear, ')
          ..write('birthdateMonth: $birthdateMonth, ')
          ..write('birthdateDay: $birthdateDay, ')
          ..write('automatedScreenName: $automatedScreenName, ')
          ..write('joinedTime: $joinedTime, ')
          ..write('isVerified: $isVerified, ')
          ..write('isProtected: $isProtected')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
    id,
    runId,
    restId,
    name,
    screenName,
    avatarUrl,
    bannerUrl,
    bio,
    link,
    avatarLocalPath,
    bannerLocalPath,
    location,
    pinnedTweetIdStr,
    parodyCommentaryFanLabel,
    birthdateYear,
    birthdateMonth,
    birthdateDay,
    automatedScreenName,
    joinedTime,
    isVerified,
    isProtected,
  ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TwiUserProfileEntry &&
          other.id == this.id &&
          other.runId == this.runId &&
          other.restId == this.restId &&
          other.name == this.name &&
          other.screenName == this.screenName &&
          other.avatarUrl == this.avatarUrl &&
          other.bannerUrl == this.bannerUrl &&
          other.bio == this.bio &&
          other.link == this.link &&
          other.avatarLocalPath == this.avatarLocalPath &&
          other.bannerLocalPath == this.bannerLocalPath &&
          other.location == this.location &&
          other.pinnedTweetIdStr == this.pinnedTweetIdStr &&
          other.parodyCommentaryFanLabel == this.parodyCommentaryFanLabel &&
          other.birthdateYear == this.birthdateYear &&
          other.birthdateMonth == this.birthdateMonth &&
          other.birthdateDay == this.birthdateDay &&
          other.automatedScreenName == this.automatedScreenName &&
          other.joinedTime == this.joinedTime &&
          other.isVerified == this.isVerified &&
          other.isProtected == this.isProtected);
}

class TwiUserProfileCompanion extends UpdateCompanion<TwiUserProfileEntry> {
  final Value<int> id;
  final Value<String> runId;
  final Value<String> restId;
  final Value<String?> name;
  final Value<String?> screenName;
  final Value<String?> avatarUrl;
  final Value<String?> bannerUrl;
  final Value<String?> bio;
  final Value<String?> link;
  final Value<String?> avatarLocalPath;
  final Value<String?> bannerLocalPath;
  final Value<String?> location;
  final Value<String?> pinnedTweetIdStr;
  final Value<String?> parodyCommentaryFanLabel;
  final Value<String?> birthdateYear;
  final Value<String?> birthdateMonth;
  final Value<String?> birthdateDay;
  final Value<String?> automatedScreenName;
  final Value<String?> joinedTime;
  final Value<bool> isVerified;
  final Value<bool> isProtected;
  const TwiUserProfileCompanion({
    this.id = const Value.absent(),
    this.runId = const Value.absent(),
    this.restId = const Value.absent(),
    this.name = const Value.absent(),
    this.screenName = const Value.absent(),
    this.avatarUrl = const Value.absent(),
    this.bannerUrl = const Value.absent(),
    this.bio = const Value.absent(),
    this.link = const Value.absent(),
    this.avatarLocalPath = const Value.absent(),
    this.bannerLocalPath = const Value.absent(),
    this.location = const Value.absent(),
    this.pinnedTweetIdStr = const Value.absent(),
    this.parodyCommentaryFanLabel = const Value.absent(),
    this.birthdateYear = const Value.absent(),
    this.birthdateMonth = const Value.absent(),
    this.birthdateDay = const Value.absent(),
    this.automatedScreenName = const Value.absent(),
    this.joinedTime = const Value.absent(),
    this.isVerified = const Value.absent(),
    this.isProtected = const Value.absent(),
  });
  TwiUserProfileCompanion.insert({
    this.id = const Value.absent(),
    required String runId,
    required String restId,
    this.name = const Value.absent(),
    this.screenName = const Value.absent(),
    this.avatarUrl = const Value.absent(),
    this.bannerUrl = const Value.absent(),
    this.bio = const Value.absent(),
    this.link = const Value.absent(),
    this.avatarLocalPath = const Value.absent(),
    this.bannerLocalPath = const Value.absent(),
    this.location = const Value.absent(),
    this.pinnedTweetIdStr = const Value.absent(),
    this.parodyCommentaryFanLabel = const Value.absent(),
    this.birthdateYear = const Value.absent(),
    this.birthdateMonth = const Value.absent(),
    this.birthdateDay = const Value.absent(),
    this.automatedScreenName = const Value.absent(),
    this.joinedTime = const Value.absent(),
    this.isVerified = const Value.absent(),
    this.isProtected = const Value.absent(),
  }) : runId = Value(runId),
       restId = Value(restId);
  static Insertable<TwiUserProfileEntry> custom({
    Expression<int>? id,
    Expression<String>? runId,
    Expression<String>? restId,
    Expression<String>? name,
    Expression<String>? screenName,
    Expression<String>? avatarUrl,
    Expression<String>? bannerUrl,
    Expression<String>? bio,
    Expression<String>? link,
    Expression<String>? avatarLocalPath,
    Expression<String>? bannerLocalPath,
    Expression<String>? location,
    Expression<String>? pinnedTweetIdStr,
    Expression<String>? parodyCommentaryFanLabel,
    Expression<String>? birthdateYear,
    Expression<String>? birthdateMonth,
    Expression<String>? birthdateDay,
    Expression<String>? automatedScreenName,
    Expression<String>? joinedTime,
    Expression<bool>? isVerified,
    Expression<bool>? isProtected,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (runId != null) 'run_id': runId,
      if (restId != null) 'rest_id': restId,
      if (name != null) 'name': name,
      if (screenName != null) 'screen_name': screenName,
      if (avatarUrl != null) 'avatar_url': avatarUrl,
      if (bannerUrl != null) 'banner_url': bannerUrl,
      if (bio != null) 'bio': bio,
      if (link != null) 'link': link,
      if (avatarLocalPath != null) 'avatar_local_path': avatarLocalPath,
      if (bannerLocalPath != null) 'banner_local_path': bannerLocalPath,
      if (location != null) 'location': location,
      if (pinnedTweetIdStr != null) 'pinned_tweet_id_str': pinnedTweetIdStr,
      if (parodyCommentaryFanLabel != null)
        'parody_commentary_fan_label': parodyCommentaryFanLabel,
      if (birthdateYear != null) 'birthdate_year': birthdateYear,
      if (birthdateMonth != null) 'birthdate_month': birthdateMonth,
      if (birthdateDay != null) 'birthdate_day': birthdateDay,
      if (automatedScreenName != null)
        'automated_screen_name': automatedScreenName,
      if (joinedTime != null) 'joined_time': joinedTime,
      if (isVerified != null) 'is_verified': isVerified,
      if (isProtected != null) 'is_protected': isProtected,
    });
  }

  TwiUserProfileCompanion copyWith({
    Value<int>? id,
    Value<String>? runId,
    Value<String>? restId,
    Value<String?>? name,
    Value<String?>? screenName,
    Value<String?>? avatarUrl,
    Value<String?>? bannerUrl,
    Value<String?>? bio,
    Value<String?>? link,
    Value<String?>? avatarLocalPath,
    Value<String?>? bannerLocalPath,
    Value<String?>? location,
    Value<String?>? pinnedTweetIdStr,
    Value<String?>? parodyCommentaryFanLabel,
    Value<String?>? birthdateYear,
    Value<String?>? birthdateMonth,
    Value<String?>? birthdateDay,
    Value<String?>? automatedScreenName,
    Value<String?>? joinedTime,
    Value<bool>? isVerified,
    Value<bool>? isProtected,
  }) {
    return TwiUserProfileCompanion(
      id: id ?? this.id,
      runId: runId ?? this.runId,
      restId: restId ?? this.restId,
      name: name ?? this.name,
      screenName: screenName ?? this.screenName,
      avatarUrl: avatarUrl ?? this.avatarUrl,
      bannerUrl: bannerUrl ?? this.bannerUrl,
      bio: bio ?? this.bio,
      link: link ?? this.link,
      avatarLocalPath: avatarLocalPath ?? this.avatarLocalPath,
      bannerLocalPath: bannerLocalPath ?? this.bannerLocalPath,
      location: location ?? this.location,
      pinnedTweetIdStr: pinnedTweetIdStr ?? this.pinnedTweetIdStr,
      parodyCommentaryFanLabel:
          parodyCommentaryFanLabel ?? this.parodyCommentaryFanLabel,
      birthdateYear: birthdateYear ?? this.birthdateYear,
      birthdateMonth: birthdateMonth ?? this.birthdateMonth,
      birthdateDay: birthdateDay ?? this.birthdateDay,
      automatedScreenName: automatedScreenName ?? this.automatedScreenName,
      joinedTime: joinedTime ?? this.joinedTime,
      isVerified: isVerified ?? this.isVerified,
      isProtected: isProtected ?? this.isProtected,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (runId.present) {
      map['run_id'] = Variable<String>(runId.value);
    }
    if (restId.present) {
      map['rest_id'] = Variable<String>(restId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (screenName.present) {
      map['screen_name'] = Variable<String>(screenName.value);
    }
    if (avatarUrl.present) {
      map['avatar_url'] = Variable<String>(avatarUrl.value);
    }
    if (bannerUrl.present) {
      map['banner_url'] = Variable<String>(bannerUrl.value);
    }
    if (bio.present) {
      map['bio'] = Variable<String>(bio.value);
    }
    if (link.present) {
      map['link'] = Variable<String>(link.value);
    }
    if (avatarLocalPath.present) {
      map['avatar_local_path'] = Variable<String>(avatarLocalPath.value);
    }
    if (bannerLocalPath.present) {
      map['banner_local_path'] = Variable<String>(bannerLocalPath.value);
    }
    if (location.present) {
      map['location'] = Variable<String>(location.value);
    }
    if (pinnedTweetIdStr.present) {
      map['pinned_tweet_id_str'] = Variable<String>(pinnedTweetIdStr.value);
    }
    if (parodyCommentaryFanLabel.present) {
      map['parody_commentary_fan_label'] = Variable<String>(
        parodyCommentaryFanLabel.value,
      );
    }
    if (birthdateYear.present) {
      map['birthdate_year'] = Variable<String>(birthdateYear.value);
    }
    if (birthdateMonth.present) {
      map['birthdate_month'] = Variable<String>(birthdateMonth.value);
    }
    if (birthdateDay.present) {
      map['birthdate_day'] = Variable<String>(birthdateDay.value);
    }
    if (automatedScreenName.present) {
      map['automated_screen_name'] = Variable<String>(
        automatedScreenName.value,
      );
    }
    if (joinedTime.present) {
      map['joined_time'] = Variable<String>(joinedTime.value);
    }
    if (isVerified.present) {
      map['is_verified'] = Variable<bool>(isVerified.value);
    }
    if (isProtected.present) {
      map['is_protected'] = Variable<bool>(isProtected.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TwiUserProfileCompanion(')
          ..write('id: $id, ')
          ..write('runId: $runId, ')
          ..write('restId: $restId, ')
          ..write('name: $name, ')
          ..write('screenName: $screenName, ')
          ..write('avatarUrl: $avatarUrl, ')
          ..write('bannerUrl: $bannerUrl, ')
          ..write('bio: $bio, ')
          ..write('link: $link, ')
          ..write('avatarLocalPath: $avatarLocalPath, ')
          ..write('bannerLocalPath: $bannerLocalPath, ')
          ..write('location: $location, ')
          ..write('pinnedTweetIdStr: $pinnedTweetIdStr, ')
          ..write('parodyCommentaryFanLabel: $parodyCommentaryFanLabel, ')
          ..write('birthdateYear: $birthdateYear, ')
          ..write('birthdateMonth: $birthdateMonth, ')
          ..write('birthdateDay: $birthdateDay, ')
          ..write('automatedScreenName: $automatedScreenName, ')
          ..write('joinedTime: $joinedTime, ')
          ..write('isVerified: $isVerified, ')
          ..write('isProtected: $isProtected')
          ..write(')'))
        .toString();
  }
}

class $ChangeReportsTable extends ChangeReports
    with TableInfo<$ChangeReportsTable, ChangeReportEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ChangeReportsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    false,
    hasAutoIncrement: true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'PRIMARY KEY AUTOINCREMENT',
    ),
  );
  static const VerificationMeta _ownerIdMeta = const VerificationMeta(
    'ownerId',
  );
  @override
  late final GeneratedColumn<String> ownerId = GeneratedColumn<String>(
    'owner_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'REFERENCES logged_accounts (rest_id) ON DELETE CASCADE',
    ),
  );
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
    'user_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _changeTypeMeta = const VerificationMeta(
    'changeType',
  );
  @override
  late final GeneratedColumn<String> changeType = GeneratedColumn<String>(
    'change_type',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _timestampMeta = const VerificationMeta(
    'timestamp',
  );
  @override
  late final GeneratedColumn<DateTime> timestamp = GeneratedColumn<DateTime>(
    'timestamp',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _userSnapshotJsonMeta = const VerificationMeta(
    'userSnapshotJson',
  );
  @override
  late final GeneratedColumn<String> userSnapshotJson = GeneratedColumn<String>(
    'user_snapshot_json',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    ownerId,
    userId,
    changeType,
    timestamp,
    userSnapshotJson,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'change_reports';
  @override
  VerificationContext validateIntegrity(
    Insertable<ChangeReportEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('owner_id')) {
      context.handle(
        _ownerIdMeta,
        ownerId.isAcceptableOrUnknown(data['owner_id']!, _ownerIdMeta),
      );
    } else if (isInserting) {
      context.missing(_ownerIdMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(
        _userIdMeta,
        userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta),
      );
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('change_type')) {
      context.handle(
        _changeTypeMeta,
        changeType.isAcceptableOrUnknown(data['change_type']!, _changeTypeMeta),
      );
    } else if (isInserting) {
      context.missing(_changeTypeMeta);
    }
    if (data.containsKey('timestamp')) {
      context.handle(
        _timestampMeta,
        timestamp.isAcceptableOrUnknown(data['timestamp']!, _timestampMeta),
      );
    } else if (isInserting) {
      context.missing(_timestampMeta);
    }
    if (data.containsKey('user_snapshot_json')) {
      context.handle(
        _userSnapshotJsonMeta,
        userSnapshotJson.isAcceptableOrUnknown(
          data['user_snapshot_json']!,
          _userSnapshotJsonMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ChangeReportEntry map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ChangeReportEntry(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      )!,
      ownerId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}owner_id'],
      )!,
      userId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}user_id'],
      )!,
      changeType: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}change_type'],
      )!,
      timestamp: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}timestamp'],
      )!,
      userSnapshotJson: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}user_snapshot_json'],
      ),
    );
  }

  @override
  $ChangeReportsTable createAlias(String alias) {
    return $ChangeReportsTable(attachedDatabase, alias);
  }
}

class ChangeReportEntry extends DataClass
    implements Insertable<ChangeReportEntry> {
  final int id;
  final String ownerId;
  final String userId;
  final String changeType;
  final DateTime timestamp;
  final String? userSnapshotJson;
  const ChangeReportEntry({
    required this.id,
    required this.ownerId,
    required this.userId,
    required this.changeType,
    required this.timestamp,
    this.userSnapshotJson,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['owner_id'] = Variable<String>(ownerId);
    map['user_id'] = Variable<String>(userId);
    map['change_type'] = Variable<String>(changeType);
    map['timestamp'] = Variable<DateTime>(timestamp);
    if (!nullToAbsent || userSnapshotJson != null) {
      map['user_snapshot_json'] = Variable<String>(userSnapshotJson);
    }
    return map;
  }

  ChangeReportsCompanion toCompanion(bool nullToAbsent) {
    return ChangeReportsCompanion(
      id: Value(id),
      ownerId: Value(ownerId),
      userId: Value(userId),
      changeType: Value(changeType),
      timestamp: Value(timestamp),
      userSnapshotJson: userSnapshotJson == null && nullToAbsent
          ? const Value.absent()
          : Value(userSnapshotJson),
    );
  }

  factory ChangeReportEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ChangeReportEntry(
      id: serializer.fromJson<int>(json['id']),
      ownerId: serializer.fromJson<String>(json['ownerId']),
      userId: serializer.fromJson<String>(json['userId']),
      changeType: serializer.fromJson<String>(json['changeType']),
      timestamp: serializer.fromJson<DateTime>(json['timestamp']),
      userSnapshotJson: serializer.fromJson<String?>(json['userSnapshotJson']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'ownerId': serializer.toJson<String>(ownerId),
      'userId': serializer.toJson<String>(userId),
      'changeType': serializer.toJson<String>(changeType),
      'timestamp': serializer.toJson<DateTime>(timestamp),
      'userSnapshotJson': serializer.toJson<String?>(userSnapshotJson),
    };
  }

  ChangeReportEntry copyWith({
    int? id,
    String? ownerId,
    String? userId,
    String? changeType,
    DateTime? timestamp,
    Value<String?> userSnapshotJson = const Value.absent(),
  }) => ChangeReportEntry(
    id: id ?? this.id,
    ownerId: ownerId ?? this.ownerId,
    userId: userId ?? this.userId,
    changeType: changeType ?? this.changeType,
    timestamp: timestamp ?? this.timestamp,
    userSnapshotJson: userSnapshotJson.present
        ? userSnapshotJson.value
        : this.userSnapshotJson,
  );
  ChangeReportEntry copyWithCompanion(ChangeReportsCompanion data) {
    return ChangeReportEntry(
      id: data.id.present ? data.id.value : this.id,
      ownerId: data.ownerId.present ? data.ownerId.value : this.ownerId,
      userId: data.userId.present ? data.userId.value : this.userId,
      changeType: data.changeType.present
          ? data.changeType.value
          : this.changeType,
      timestamp: data.timestamp.present ? data.timestamp.value : this.timestamp,
      userSnapshotJson: data.userSnapshotJson.present
          ? data.userSnapshotJson.value
          : this.userSnapshotJson,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ChangeReportEntry(')
          ..write('id: $id, ')
          ..write('ownerId: $ownerId, ')
          ..write('userId: $userId, ')
          ..write('changeType: $changeType, ')
          ..write('timestamp: $timestamp, ')
          ..write('userSnapshotJson: $userSnapshotJson')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, ownerId, userId, changeType, timestamp, userSnapshotJson);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ChangeReportEntry &&
          other.id == this.id &&
          other.ownerId == this.ownerId &&
          other.userId == this.userId &&
          other.changeType == this.changeType &&
          other.timestamp == this.timestamp &&
          other.userSnapshotJson == this.userSnapshotJson);
}

class ChangeReportsCompanion extends UpdateCompanion<ChangeReportEntry> {
  final Value<int> id;
  final Value<String> ownerId;
  final Value<String> userId;
  final Value<String> changeType;
  final Value<DateTime> timestamp;
  final Value<String?> userSnapshotJson;
  const ChangeReportsCompanion({
    this.id = const Value.absent(),
    this.ownerId = const Value.absent(),
    this.userId = const Value.absent(),
    this.changeType = const Value.absent(),
    this.timestamp = const Value.absent(),
    this.userSnapshotJson = const Value.absent(),
  });
  ChangeReportsCompanion.insert({
    this.id = const Value.absent(),
    required String ownerId,
    required String userId,
    required String changeType,
    required DateTime timestamp,
    this.userSnapshotJson = const Value.absent(),
  }) : ownerId = Value(ownerId),
       userId = Value(userId),
       changeType = Value(changeType),
       timestamp = Value(timestamp);
  static Insertable<ChangeReportEntry> custom({
    Expression<int>? id,
    Expression<String>? ownerId,
    Expression<String>? userId,
    Expression<String>? changeType,
    Expression<DateTime>? timestamp,
    Expression<String>? userSnapshotJson,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (ownerId != null) 'owner_id': ownerId,
      if (userId != null) 'user_id': userId,
      if (changeType != null) 'change_type': changeType,
      if (timestamp != null) 'timestamp': timestamp,
      if (userSnapshotJson != null) 'user_snapshot_json': userSnapshotJson,
    });
  }

  ChangeReportsCompanion copyWith({
    Value<int>? id,
    Value<String>? ownerId,
    Value<String>? userId,
    Value<String>? changeType,
    Value<DateTime>? timestamp,
    Value<String?>? userSnapshotJson,
  }) {
    return ChangeReportsCompanion(
      id: id ?? this.id,
      ownerId: ownerId ?? this.ownerId,
      userId: userId ?? this.userId,
      changeType: changeType ?? this.changeType,
      timestamp: timestamp ?? this.timestamp,
      userSnapshotJson: userSnapshotJson ?? this.userSnapshotJson,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (ownerId.present) {
      map['owner_id'] = Variable<String>(ownerId.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (changeType.present) {
      map['change_type'] = Variable<String>(changeType.value);
    }
    if (timestamp.present) {
      map['timestamp'] = Variable<DateTime>(timestamp.value);
    }
    if (userSnapshotJson.present) {
      map['user_snapshot_json'] = Variable<String>(userSnapshotJson.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ChangeReportsCompanion(')
          ..write('id: $id, ')
          ..write('ownerId: $ownerId, ')
          ..write('userId: $userId, ')
          ..write('changeType: $changeType, ')
          ..write('timestamp: $timestamp, ')
          ..write('userSnapshotJson: $userSnapshotJson')
          ..write(')'))
        .toString();
  }
}

class $TwiUserMediaTable extends TwiUserMedia
    with TableInfo<$TwiUserMediaTable, TwiUserMediaEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TwiUserMediaTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    false,
    hasAutoIncrement: true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'PRIMARY KEY AUTOINCREMENT',
    ),
  );
  static const VerificationMeta _mediaTypeMeta = const VerificationMeta(
    'mediaType',
  );
  @override
  late final GeneratedColumn<String> mediaType = GeneratedColumn<String>(
    'media_type',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _localFilePathMeta = const VerificationMeta(
    'localFilePath',
  );
  @override
  late final GeneratedColumn<String> localFilePath = GeneratedColumn<String>(
    'local_file_path',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _remoteUrlHashMeta = const VerificationMeta(
    'remoteUrlHash',
  );
  @override
  late final GeneratedColumn<String> remoteUrlHash = GeneratedColumn<String>(
    'remote_url_hash',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _isHighQualityMeta = const VerificationMeta(
    'isHighQuality',
  );
  @override
  late final GeneratedColumn<bool> isHighQuality = GeneratedColumn<bool>(
    'is_high_quality',
    aliasedName,
    false,
    type: DriftSqlType.bool,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'CHECK ("is_high_quality" IN (0, 1))',
    ),
    defaultValue: const Constant(false),
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    mediaType,
    localFilePath,
    remoteUrlHash,
    isHighQuality,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'twi_user_media';
  @override
  VerificationContext validateIntegrity(
    Insertable<TwiUserMediaEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('media_type')) {
      context.handle(
        _mediaTypeMeta,
        mediaType.isAcceptableOrUnknown(data['media_type']!, _mediaTypeMeta),
      );
    } else if (isInserting) {
      context.missing(_mediaTypeMeta);
    }
    if (data.containsKey('local_file_path')) {
      context.handle(
        _localFilePathMeta,
        localFilePath.isAcceptableOrUnknown(
          data['local_file_path']!,
          _localFilePathMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_localFilePathMeta);
    }
    if (data.containsKey('remote_url_hash')) {
      context.handle(
        _remoteUrlHashMeta,
        remoteUrlHash.isAcceptableOrUnknown(
          data['remote_url_hash']!,
          _remoteUrlHashMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_remoteUrlHashMeta);
    }
    if (data.containsKey('is_high_quality')) {
      context.handle(
        _isHighQualityMeta,
        isHighQuality.isAcceptableOrUnknown(
          data['is_high_quality']!,
          _isHighQualityMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TwiUserMediaEntry map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TwiUserMediaEntry(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      )!,
      mediaType: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}media_type'],
      )!,
      localFilePath: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}local_file_path'],
      )!,
      remoteUrlHash: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}remote_url_hash'],
      )!,
      isHighQuality: attachedDatabase.typeMapping.read(
        DriftSqlType.bool,
        data['${effectivePrefix}is_high_quality'],
      )!,
    );
  }

  @override
  $TwiUserMediaTable createAlias(String alias) {
    return $TwiUserMediaTable(attachedDatabase, alias);
  }
}

class TwiUserMediaEntry extends DataClass
    implements Insertable<TwiUserMediaEntry> {
  final int id;
  final String mediaType;
  final String localFilePath;
  final String remoteUrlHash;
  final bool isHighQuality;
  const TwiUserMediaEntry({
    required this.id,
    required this.mediaType,
    required this.localFilePath,
    required this.remoteUrlHash,
    required this.isHighQuality,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['media_type'] = Variable<String>(mediaType);
    map['local_file_path'] = Variable<String>(localFilePath);
    map['remote_url_hash'] = Variable<String>(remoteUrlHash);
    map['is_high_quality'] = Variable<bool>(isHighQuality);
    return map;
  }

  TwiUserMediaCompanion toCompanion(bool nullToAbsent) {
    return TwiUserMediaCompanion(
      id: Value(id),
      mediaType: Value(mediaType),
      localFilePath: Value(localFilePath),
      remoteUrlHash: Value(remoteUrlHash),
      isHighQuality: Value(isHighQuality),
    );
  }

  factory TwiUserMediaEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TwiUserMediaEntry(
      id: serializer.fromJson<int>(json['id']),
      mediaType: serializer.fromJson<String>(json['mediaType']),
      localFilePath: serializer.fromJson<String>(json['localFilePath']),
      remoteUrlHash: serializer.fromJson<String>(json['remoteUrlHash']),
      isHighQuality: serializer.fromJson<bool>(json['isHighQuality']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'mediaType': serializer.toJson<String>(mediaType),
      'localFilePath': serializer.toJson<String>(localFilePath),
      'remoteUrlHash': serializer.toJson<String>(remoteUrlHash),
      'isHighQuality': serializer.toJson<bool>(isHighQuality),
    };
  }

  TwiUserMediaEntry copyWith({
    int? id,
    String? mediaType,
    String? localFilePath,
    String? remoteUrlHash,
    bool? isHighQuality,
  }) => TwiUserMediaEntry(
    id: id ?? this.id,
    mediaType: mediaType ?? this.mediaType,
    localFilePath: localFilePath ?? this.localFilePath,
    remoteUrlHash: remoteUrlHash ?? this.remoteUrlHash,
    isHighQuality: isHighQuality ?? this.isHighQuality,
  );
  TwiUserMediaEntry copyWithCompanion(TwiUserMediaCompanion data) {
    return TwiUserMediaEntry(
      id: data.id.present ? data.id.value : this.id,
      mediaType: data.mediaType.present ? data.mediaType.value : this.mediaType,
      localFilePath: data.localFilePath.present
          ? data.localFilePath.value
          : this.localFilePath,
      remoteUrlHash: data.remoteUrlHash.present
          ? data.remoteUrlHash.value
          : this.remoteUrlHash,
      isHighQuality: data.isHighQuality.present
          ? data.isHighQuality.value
          : this.isHighQuality,
    );
  }

  @override
  String toString() {
    return (StringBuffer('TwiUserMediaEntry(')
          ..write('id: $id, ')
          ..write('mediaType: $mediaType, ')
          ..write('localFilePath: $localFilePath, ')
          ..write('remoteUrlHash: $remoteUrlHash, ')
          ..write('isHighQuality: $isHighQuality')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, mediaType, localFilePath, remoteUrlHash, isHighQuality);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TwiUserMediaEntry &&
          other.id == this.id &&
          other.mediaType == this.mediaType &&
          other.localFilePath == this.localFilePath &&
          other.remoteUrlHash == this.remoteUrlHash &&
          other.isHighQuality == this.isHighQuality);
}

class TwiUserMediaCompanion extends UpdateCompanion<TwiUserMediaEntry> {
  final Value<int> id;
  final Value<String> mediaType;
  final Value<String> localFilePath;
  final Value<String> remoteUrlHash;
  final Value<bool> isHighQuality;
  const TwiUserMediaCompanion({
    this.id = const Value.absent(),
    this.mediaType = const Value.absent(),
    this.localFilePath = const Value.absent(),
    this.remoteUrlHash = const Value.absent(),
    this.isHighQuality = const Value.absent(),
  });
  TwiUserMediaCompanion.insert({
    this.id = const Value.absent(),
    required String mediaType,
    required String localFilePath,
    required String remoteUrlHash,
    this.isHighQuality = const Value.absent(),
  }) : mediaType = Value(mediaType),
       localFilePath = Value(localFilePath),
       remoteUrlHash = Value(remoteUrlHash);
  static Insertable<TwiUserMediaEntry> custom({
    Expression<int>? id,
    Expression<String>? mediaType,
    Expression<String>? localFilePath,
    Expression<String>? remoteUrlHash,
    Expression<bool>? isHighQuality,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (mediaType != null) 'media_type': mediaType,
      if (localFilePath != null) 'local_file_path': localFilePath,
      if (remoteUrlHash != null) 'remote_url_hash': remoteUrlHash,
      if (isHighQuality != null) 'is_high_quality': isHighQuality,
    });
  }

  TwiUserMediaCompanion copyWith({
    Value<int>? id,
    Value<String>? mediaType,
    Value<String>? localFilePath,
    Value<String>? remoteUrlHash,
    Value<bool>? isHighQuality,
  }) {
    return TwiUserMediaCompanion(
      id: id ?? this.id,
      mediaType: mediaType ?? this.mediaType,
      localFilePath: localFilePath ?? this.localFilePath,
      remoteUrlHash: remoteUrlHash ?? this.remoteUrlHash,
      isHighQuality: isHighQuality ?? this.isHighQuality,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (mediaType.present) {
      map['media_type'] = Variable<String>(mediaType.value);
    }
    if (localFilePath.present) {
      map['local_file_path'] = Variable<String>(localFilePath.value);
    }
    if (remoteUrlHash.present) {
      map['remote_url_hash'] = Variable<String>(remoteUrlHash.value);
    }
    if (isHighQuality.present) {
      map['is_high_quality'] = Variable<bool>(isHighQuality.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TwiUserMediaCompanion(')
          ..write('id: $id, ')
          ..write('mediaType: $mediaType, ')
          ..write('localFilePath: $localFilePath, ')
          ..write('remoteUrlHash: $remoteUrlHash, ')
          ..write('isHighQuality: $isHighQuality')
          ..write(')'))
        .toString();
  }
}

class $TwiUserRelationshipTable extends TwiUserRelationship
    with TableInfo<$TwiUserRelationshipTable, TwiUserRelationshipEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TwiUserRelationshipTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    false,
    hasAutoIncrement: true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'PRIMARY KEY AUTOINCREMENT',
    ),
  );
  static const VerificationMeta _runIdMeta = const VerificationMeta('runId');
  @override
  late final GeneratedColumn<String> runId = GeneratedColumn<String>(
    'run_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _ownerIdMeta = const VerificationMeta(
    'ownerId',
  );
  @override
  late final GeneratedColumn<String> ownerId = GeneratedColumn<String>(
    'owner_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _restIdMeta = const VerificationMeta('restId');
  @override
  late final GeneratedColumn<String> restId = GeneratedColumn<String>(
    'rest_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _isFollowingMeta = const VerificationMeta(
    'isFollowing',
  );
  @override
  late final GeneratedColumn<bool> isFollowing = GeneratedColumn<bool>(
    'is_following',
    aliasedName,
    false,
    type: DriftSqlType.bool,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'CHECK ("is_following" IN (0, 1))',
    ),
    defaultValue: const Constant(false),
  );
  static const VerificationMeta _isFollowerMeta = const VerificationMeta(
    'isFollower',
  );
  @override
  late final GeneratedColumn<bool> isFollower = GeneratedColumn<bool>(
    'is_follower',
    aliasedName,
    false,
    type: DriftSqlType.bool,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'CHECK ("is_follower" IN (0, 1))',
    ),
    defaultValue: const Constant(false),
  );
  static const VerificationMeta _canDmMeta = const VerificationMeta('canDm');
  @override
  late final GeneratedColumn<bool> canDm = GeneratedColumn<bool>(
    'can_dm',
    aliasedName,
    false,
    type: DriftSqlType.bool,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'CHECK ("can_dm" IN (0, 1))',
    ),
    defaultValue: const Constant(false),
  );
  static const VerificationMeta _canMediaTagMeta = const VerificationMeta(
    'canMediaTag',
  );
  @override
  late final GeneratedColumn<bool> canMediaTag = GeneratedColumn<bool>(
    'can_media_tag',
    aliasedName,
    false,
    type: DriftSqlType.bool,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'CHECK ("can_media_tag" IN (0, 1))',
    ),
    defaultValue: const Constant(false),
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    runId,
    ownerId,
    restId,
    isFollowing,
    isFollower,
    canDm,
    canMediaTag,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'twi_user_relationship';
  @override
  VerificationContext validateIntegrity(
    Insertable<TwiUserRelationshipEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('run_id')) {
      context.handle(
        _runIdMeta,
        runId.isAcceptableOrUnknown(data['run_id']!, _runIdMeta),
      );
    } else if (isInserting) {
      context.missing(_runIdMeta);
    }
    if (data.containsKey('owner_id')) {
      context.handle(
        _ownerIdMeta,
        ownerId.isAcceptableOrUnknown(data['owner_id']!, _ownerIdMeta),
      );
    } else if (isInserting) {
      context.missing(_ownerIdMeta);
    }
    if (data.containsKey('rest_id')) {
      context.handle(
        _restIdMeta,
        restId.isAcceptableOrUnknown(data['rest_id']!, _restIdMeta),
      );
    } else if (isInserting) {
      context.missing(_restIdMeta);
    }
    if (data.containsKey('is_following')) {
      context.handle(
        _isFollowingMeta,
        isFollowing.isAcceptableOrUnknown(
          data['is_following']!,
          _isFollowingMeta,
        ),
      );
    }
    if (data.containsKey('is_follower')) {
      context.handle(
        _isFollowerMeta,
        isFollower.isAcceptableOrUnknown(data['is_follower']!, _isFollowerMeta),
      );
    }
    if (data.containsKey('can_dm')) {
      context.handle(
        _canDmMeta,
        canDm.isAcceptableOrUnknown(data['can_dm']!, _canDmMeta),
      );
    }
    if (data.containsKey('can_media_tag')) {
      context.handle(
        _canMediaTagMeta,
        canMediaTag.isAcceptableOrUnknown(
          data['can_media_tag']!,
          _canMediaTagMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TwiUserRelationshipEntry map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TwiUserRelationshipEntry(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      )!,
      runId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}run_id'],
      )!,
      ownerId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}owner_id'],
      )!,
      restId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}rest_id'],
      )!,
      isFollowing: attachedDatabase.typeMapping.read(
        DriftSqlType.bool,
        data['${effectivePrefix}is_following'],
      )!,
      isFollower: attachedDatabase.typeMapping.read(
        DriftSqlType.bool,
        data['${effectivePrefix}is_follower'],
      )!,
      canDm: attachedDatabase.typeMapping.read(
        DriftSqlType.bool,
        data['${effectivePrefix}can_dm'],
      )!,
      canMediaTag: attachedDatabase.typeMapping.read(
        DriftSqlType.bool,
        data['${effectivePrefix}can_media_tag'],
      )!,
    );
  }

  @override
  $TwiUserRelationshipTable createAlias(String alias) {
    return $TwiUserRelationshipTable(attachedDatabase, alias);
  }
}

class TwiUserRelationshipEntry extends DataClass
    implements Insertable<TwiUserRelationshipEntry> {
  final int id;
  final String runId;
  final String ownerId;
  final String restId;
  final bool isFollowing;
  final bool isFollower;
  final bool canDm;
  final bool canMediaTag;
  const TwiUserRelationshipEntry({
    required this.id,
    required this.runId,
    required this.ownerId,
    required this.restId,
    required this.isFollowing,
    required this.isFollower,
    required this.canDm,
    required this.canMediaTag,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['run_id'] = Variable<String>(runId);
    map['owner_id'] = Variable<String>(ownerId);
    map['rest_id'] = Variable<String>(restId);
    map['is_following'] = Variable<bool>(isFollowing);
    map['is_follower'] = Variable<bool>(isFollower);
    map['can_dm'] = Variable<bool>(canDm);
    map['can_media_tag'] = Variable<bool>(canMediaTag);
    return map;
  }

  TwiUserRelationshipCompanion toCompanion(bool nullToAbsent) {
    return TwiUserRelationshipCompanion(
      id: Value(id),
      runId: Value(runId),
      ownerId: Value(ownerId),
      restId: Value(restId),
      isFollowing: Value(isFollowing),
      isFollower: Value(isFollower),
      canDm: Value(canDm),
      canMediaTag: Value(canMediaTag),
    );
  }

  factory TwiUserRelationshipEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TwiUserRelationshipEntry(
      id: serializer.fromJson<int>(json['id']),
      runId: serializer.fromJson<String>(json['runId']),
      ownerId: serializer.fromJson<String>(json['ownerId']),
      restId: serializer.fromJson<String>(json['restId']),
      isFollowing: serializer.fromJson<bool>(json['isFollowing']),
      isFollower: serializer.fromJson<bool>(json['isFollower']),
      canDm: serializer.fromJson<bool>(json['canDm']),
      canMediaTag: serializer.fromJson<bool>(json['canMediaTag']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'runId': serializer.toJson<String>(runId),
      'ownerId': serializer.toJson<String>(ownerId),
      'restId': serializer.toJson<String>(restId),
      'isFollowing': serializer.toJson<bool>(isFollowing),
      'isFollower': serializer.toJson<bool>(isFollower),
      'canDm': serializer.toJson<bool>(canDm),
      'canMediaTag': serializer.toJson<bool>(canMediaTag),
    };
  }

  TwiUserRelationshipEntry copyWith({
    int? id,
    String? runId,
    String? ownerId,
    String? restId,
    bool? isFollowing,
    bool? isFollower,
    bool? canDm,
    bool? canMediaTag,
  }) => TwiUserRelationshipEntry(
    id: id ?? this.id,
    runId: runId ?? this.runId,
    ownerId: ownerId ?? this.ownerId,
    restId: restId ?? this.restId,
    isFollowing: isFollowing ?? this.isFollowing,
    isFollower: isFollower ?? this.isFollower,
    canDm: canDm ?? this.canDm,
    canMediaTag: canMediaTag ?? this.canMediaTag,
  );
  TwiUserRelationshipEntry copyWithCompanion(
    TwiUserRelationshipCompanion data,
  ) {
    return TwiUserRelationshipEntry(
      id: data.id.present ? data.id.value : this.id,
      runId: data.runId.present ? data.runId.value : this.runId,
      ownerId: data.ownerId.present ? data.ownerId.value : this.ownerId,
      restId: data.restId.present ? data.restId.value : this.restId,
      isFollowing: data.isFollowing.present
          ? data.isFollowing.value
          : this.isFollowing,
      isFollower: data.isFollower.present
          ? data.isFollower.value
          : this.isFollower,
      canDm: data.canDm.present ? data.canDm.value : this.canDm,
      canMediaTag: data.canMediaTag.present
          ? data.canMediaTag.value
          : this.canMediaTag,
    );
  }

  @override
  String toString() {
    return (StringBuffer('TwiUserRelationshipEntry(')
          ..write('id: $id, ')
          ..write('runId: $runId, ')
          ..write('ownerId: $ownerId, ')
          ..write('restId: $restId, ')
          ..write('isFollowing: $isFollowing, ')
          ..write('isFollower: $isFollower, ')
          ..write('canDm: $canDm, ')
          ..write('canMediaTag: $canMediaTag')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    runId,
    ownerId,
    restId,
    isFollowing,
    isFollower,
    canDm,
    canMediaTag,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TwiUserRelationshipEntry &&
          other.id == this.id &&
          other.runId == this.runId &&
          other.ownerId == this.ownerId &&
          other.restId == this.restId &&
          other.isFollowing == this.isFollowing &&
          other.isFollower == this.isFollower &&
          other.canDm == this.canDm &&
          other.canMediaTag == this.canMediaTag);
}

class TwiUserRelationshipCompanion
    extends UpdateCompanion<TwiUserRelationshipEntry> {
  final Value<int> id;
  final Value<String> runId;
  final Value<String> ownerId;
  final Value<String> restId;
  final Value<bool> isFollowing;
  final Value<bool> isFollower;
  final Value<bool> canDm;
  final Value<bool> canMediaTag;
  const TwiUserRelationshipCompanion({
    this.id = const Value.absent(),
    this.runId = const Value.absent(),
    this.ownerId = const Value.absent(),
    this.restId = const Value.absent(),
    this.isFollowing = const Value.absent(),
    this.isFollower = const Value.absent(),
    this.canDm = const Value.absent(),
    this.canMediaTag = const Value.absent(),
  });
  TwiUserRelationshipCompanion.insert({
    this.id = const Value.absent(),
    required String runId,
    required String ownerId,
    required String restId,
    this.isFollowing = const Value.absent(),
    this.isFollower = const Value.absent(),
    this.canDm = const Value.absent(),
    this.canMediaTag = const Value.absent(),
  }) : runId = Value(runId),
       ownerId = Value(ownerId),
       restId = Value(restId);
  static Insertable<TwiUserRelationshipEntry> custom({
    Expression<int>? id,
    Expression<String>? runId,
    Expression<String>? ownerId,
    Expression<String>? restId,
    Expression<bool>? isFollowing,
    Expression<bool>? isFollower,
    Expression<bool>? canDm,
    Expression<bool>? canMediaTag,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (runId != null) 'run_id': runId,
      if (ownerId != null) 'owner_id': ownerId,
      if (restId != null) 'rest_id': restId,
      if (isFollowing != null) 'is_following': isFollowing,
      if (isFollower != null) 'is_follower': isFollower,
      if (canDm != null) 'can_dm': canDm,
      if (canMediaTag != null) 'can_media_tag': canMediaTag,
    });
  }

  TwiUserRelationshipCompanion copyWith({
    Value<int>? id,
    Value<String>? runId,
    Value<String>? ownerId,
    Value<String>? restId,
    Value<bool>? isFollowing,
    Value<bool>? isFollower,
    Value<bool>? canDm,
    Value<bool>? canMediaTag,
  }) {
    return TwiUserRelationshipCompanion(
      id: id ?? this.id,
      runId: runId ?? this.runId,
      ownerId: ownerId ?? this.ownerId,
      restId: restId ?? this.restId,
      isFollowing: isFollowing ?? this.isFollowing,
      isFollower: isFollower ?? this.isFollower,
      canDm: canDm ?? this.canDm,
      canMediaTag: canMediaTag ?? this.canMediaTag,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (runId.present) {
      map['run_id'] = Variable<String>(runId.value);
    }
    if (ownerId.present) {
      map['owner_id'] = Variable<String>(ownerId.value);
    }
    if (restId.present) {
      map['rest_id'] = Variable<String>(restId.value);
    }
    if (isFollowing.present) {
      map['is_following'] = Variable<bool>(isFollowing.value);
    }
    if (isFollower.present) {
      map['is_follower'] = Variable<bool>(isFollower.value);
    }
    if (canDm.present) {
      map['can_dm'] = Variable<bool>(canDm.value);
    }
    if (canMediaTag.present) {
      map['can_media_tag'] = Variable<bool>(canMediaTag.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TwiUserRelationshipCompanion(')
          ..write('id: $id, ')
          ..write('runId: $runId, ')
          ..write('ownerId: $ownerId, ')
          ..write('restId: $restId, ')
          ..write('isFollowing: $isFollowing, ')
          ..write('isFollower: $isFollower, ')
          ..write('canDm: $canDm, ')
          ..write('canMediaTag: $canMediaTag')
          ..write(')'))
        .toString();
  }
}

class $TwiUserStatisticsTable extends TwiUserStatistics
    with TableInfo<$TwiUserStatisticsTable, TwiUserStatisticsEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TwiUserStatisticsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    false,
    hasAutoIncrement: true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'PRIMARY KEY AUTOINCREMENT',
    ),
  );
  static const VerificationMeta _runIdMeta = const VerificationMeta('runId');
  @override
  late final GeneratedColumn<String> runId = GeneratedColumn<String>(
    'run_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _restIdMeta = const VerificationMeta('restId');
  @override
  late final GeneratedColumn<String> restId = GeneratedColumn<String>(
    'rest_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _followersCountMeta = const VerificationMeta(
    'followersCount',
  );
  @override
  late final GeneratedColumn<int> followersCount = GeneratedColumn<int>(
    'followers_count',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultValue: const Constant(0),
  );
  static const VerificationMeta _followingCountMeta = const VerificationMeta(
    'followingCount',
  );
  @override
  late final GeneratedColumn<int> followingCount = GeneratedColumn<int>(
    'following_count',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultValue: const Constant(0),
  );
  static const VerificationMeta _statusesCountMeta = const VerificationMeta(
    'statusesCount',
  );
  @override
  late final GeneratedColumn<int> statusesCount = GeneratedColumn<int>(
    'statuses_count',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultValue: const Constant(0),
  );
  static const VerificationMeta _listedCountMeta = const VerificationMeta(
    'listedCount',
  );
  @override
  late final GeneratedColumn<int> listedCount = GeneratedColumn<int>(
    'listed_count',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultValue: const Constant(0),
  );
  static const VerificationMeta _favouritesCountMeta = const VerificationMeta(
    'favouritesCount',
  );
  @override
  late final GeneratedColumn<int> favouritesCount = GeneratedColumn<int>(
    'favourites_count',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultValue: const Constant(0),
  );
  static const VerificationMeta _mediaCountMeta = const VerificationMeta(
    'mediaCount',
  );
  @override
  late final GeneratedColumn<int> mediaCount = GeneratedColumn<int>(
    'media_count',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultValue: const Constant(0),
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    runId,
    restId,
    followersCount,
    followingCount,
    statusesCount,
    listedCount,
    favouritesCount,
    mediaCount,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'twi_user_statistics';
  @override
  VerificationContext validateIntegrity(
    Insertable<TwiUserStatisticsEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('run_id')) {
      context.handle(
        _runIdMeta,
        runId.isAcceptableOrUnknown(data['run_id']!, _runIdMeta),
      );
    } else if (isInserting) {
      context.missing(_runIdMeta);
    }
    if (data.containsKey('rest_id')) {
      context.handle(
        _restIdMeta,
        restId.isAcceptableOrUnknown(data['rest_id']!, _restIdMeta),
      );
    } else if (isInserting) {
      context.missing(_restIdMeta);
    }
    if (data.containsKey('followers_count')) {
      context.handle(
        _followersCountMeta,
        followersCount.isAcceptableOrUnknown(
          data['followers_count']!,
          _followersCountMeta,
        ),
      );
    }
    if (data.containsKey('following_count')) {
      context.handle(
        _followingCountMeta,
        followingCount.isAcceptableOrUnknown(
          data['following_count']!,
          _followingCountMeta,
        ),
      );
    }
    if (data.containsKey('statuses_count')) {
      context.handle(
        _statusesCountMeta,
        statusesCount.isAcceptableOrUnknown(
          data['statuses_count']!,
          _statusesCountMeta,
        ),
      );
    }
    if (data.containsKey('listed_count')) {
      context.handle(
        _listedCountMeta,
        listedCount.isAcceptableOrUnknown(
          data['listed_count']!,
          _listedCountMeta,
        ),
      );
    }
    if (data.containsKey('favourites_count')) {
      context.handle(
        _favouritesCountMeta,
        favouritesCount.isAcceptableOrUnknown(
          data['favourites_count']!,
          _favouritesCountMeta,
        ),
      );
    }
    if (data.containsKey('media_count')) {
      context.handle(
        _mediaCountMeta,
        mediaCount.isAcceptableOrUnknown(data['media_count']!, _mediaCountMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TwiUserStatisticsEntry map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TwiUserStatisticsEntry(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      )!,
      runId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}run_id'],
      )!,
      restId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}rest_id'],
      )!,
      followersCount: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}followers_count'],
      )!,
      followingCount: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}following_count'],
      )!,
      statusesCount: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}statuses_count'],
      )!,
      listedCount: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}listed_count'],
      )!,
      favouritesCount: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}favourites_count'],
      )!,
      mediaCount: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}media_count'],
      )!,
    );
  }

  @override
  $TwiUserStatisticsTable createAlias(String alias) {
    return $TwiUserStatisticsTable(attachedDatabase, alias);
  }
}

class TwiUserStatisticsEntry extends DataClass
    implements Insertable<TwiUserStatisticsEntry> {
  final int id;
  final String runId;
  final String restId;
  final int followersCount;
  final int followingCount;
  final int statusesCount;
  final int listedCount;
  final int favouritesCount;
  final int mediaCount;
  const TwiUserStatisticsEntry({
    required this.id,
    required this.runId,
    required this.restId,
    required this.followersCount,
    required this.followingCount,
    required this.statusesCount,
    required this.listedCount,
    required this.favouritesCount,
    required this.mediaCount,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['run_id'] = Variable<String>(runId);
    map['rest_id'] = Variable<String>(restId);
    map['followers_count'] = Variable<int>(followersCount);
    map['following_count'] = Variable<int>(followingCount);
    map['statuses_count'] = Variable<int>(statusesCount);
    map['listed_count'] = Variable<int>(listedCount);
    map['favourites_count'] = Variable<int>(favouritesCount);
    map['media_count'] = Variable<int>(mediaCount);
    return map;
  }

  TwiUserStatisticsCompanion toCompanion(bool nullToAbsent) {
    return TwiUserStatisticsCompanion(
      id: Value(id),
      runId: Value(runId),
      restId: Value(restId),
      followersCount: Value(followersCount),
      followingCount: Value(followingCount),
      statusesCount: Value(statusesCount),
      listedCount: Value(listedCount),
      favouritesCount: Value(favouritesCount),
      mediaCount: Value(mediaCount),
    );
  }

  factory TwiUserStatisticsEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TwiUserStatisticsEntry(
      id: serializer.fromJson<int>(json['id']),
      runId: serializer.fromJson<String>(json['runId']),
      restId: serializer.fromJson<String>(json['restId']),
      followersCount: serializer.fromJson<int>(json['followersCount']),
      followingCount: serializer.fromJson<int>(json['followingCount']),
      statusesCount: serializer.fromJson<int>(json['statusesCount']),
      listedCount: serializer.fromJson<int>(json['listedCount']),
      favouritesCount: serializer.fromJson<int>(json['favouritesCount']),
      mediaCount: serializer.fromJson<int>(json['mediaCount']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'runId': serializer.toJson<String>(runId),
      'restId': serializer.toJson<String>(restId),
      'followersCount': serializer.toJson<int>(followersCount),
      'followingCount': serializer.toJson<int>(followingCount),
      'statusesCount': serializer.toJson<int>(statusesCount),
      'listedCount': serializer.toJson<int>(listedCount),
      'favouritesCount': serializer.toJson<int>(favouritesCount),
      'mediaCount': serializer.toJson<int>(mediaCount),
    };
  }

  TwiUserStatisticsEntry copyWith({
    int? id,
    String? runId,
    String? restId,
    int? followersCount,
    int? followingCount,
    int? statusesCount,
    int? listedCount,
    int? favouritesCount,
    int? mediaCount,
  }) => TwiUserStatisticsEntry(
    id: id ?? this.id,
    runId: runId ?? this.runId,
    restId: restId ?? this.restId,
    followersCount: followersCount ?? this.followersCount,
    followingCount: followingCount ?? this.followingCount,
    statusesCount: statusesCount ?? this.statusesCount,
    listedCount: listedCount ?? this.listedCount,
    favouritesCount: favouritesCount ?? this.favouritesCount,
    mediaCount: mediaCount ?? this.mediaCount,
  );
  TwiUserStatisticsEntry copyWithCompanion(TwiUserStatisticsCompanion data) {
    return TwiUserStatisticsEntry(
      id: data.id.present ? data.id.value : this.id,
      runId: data.runId.present ? data.runId.value : this.runId,
      restId: data.restId.present ? data.restId.value : this.restId,
      followersCount: data.followersCount.present
          ? data.followersCount.value
          : this.followersCount,
      followingCount: data.followingCount.present
          ? data.followingCount.value
          : this.followingCount,
      statusesCount: data.statusesCount.present
          ? data.statusesCount.value
          : this.statusesCount,
      listedCount: data.listedCount.present
          ? data.listedCount.value
          : this.listedCount,
      favouritesCount: data.favouritesCount.present
          ? data.favouritesCount.value
          : this.favouritesCount,
      mediaCount: data.mediaCount.present
          ? data.mediaCount.value
          : this.mediaCount,
    );
  }

  @override
  String toString() {
    return (StringBuffer('TwiUserStatisticsEntry(')
          ..write('id: $id, ')
          ..write('runId: $runId, ')
          ..write('restId: $restId, ')
          ..write('followersCount: $followersCount, ')
          ..write('followingCount: $followingCount, ')
          ..write('statusesCount: $statusesCount, ')
          ..write('listedCount: $listedCount, ')
          ..write('favouritesCount: $favouritesCount, ')
          ..write('mediaCount: $mediaCount')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    runId,
    restId,
    followersCount,
    followingCount,
    statusesCount,
    listedCount,
    favouritesCount,
    mediaCount,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TwiUserStatisticsEntry &&
          other.id == this.id &&
          other.runId == this.runId &&
          other.restId == this.restId &&
          other.followersCount == this.followersCount &&
          other.followingCount == this.followingCount &&
          other.statusesCount == this.statusesCount &&
          other.listedCount == this.listedCount &&
          other.favouritesCount == this.favouritesCount &&
          other.mediaCount == this.mediaCount);
}

class TwiUserStatisticsCompanion
    extends UpdateCompanion<TwiUserStatisticsEntry> {
  final Value<int> id;
  final Value<String> runId;
  final Value<String> restId;
  final Value<int> followersCount;
  final Value<int> followingCount;
  final Value<int> statusesCount;
  final Value<int> listedCount;
  final Value<int> favouritesCount;
  final Value<int> mediaCount;
  const TwiUserStatisticsCompanion({
    this.id = const Value.absent(),
    this.runId = const Value.absent(),
    this.restId = const Value.absent(),
    this.followersCount = const Value.absent(),
    this.followingCount = const Value.absent(),
    this.statusesCount = const Value.absent(),
    this.listedCount = const Value.absent(),
    this.favouritesCount = const Value.absent(),
    this.mediaCount = const Value.absent(),
  });
  TwiUserStatisticsCompanion.insert({
    this.id = const Value.absent(),
    required String runId,
    required String restId,
    this.followersCount = const Value.absent(),
    this.followingCount = const Value.absent(),
    this.statusesCount = const Value.absent(),
    this.listedCount = const Value.absent(),
    this.favouritesCount = const Value.absent(),
    this.mediaCount = const Value.absent(),
  }) : runId = Value(runId),
       restId = Value(restId);
  static Insertable<TwiUserStatisticsEntry> custom({
    Expression<int>? id,
    Expression<String>? runId,
    Expression<String>? restId,
    Expression<int>? followersCount,
    Expression<int>? followingCount,
    Expression<int>? statusesCount,
    Expression<int>? listedCount,
    Expression<int>? favouritesCount,
    Expression<int>? mediaCount,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (runId != null) 'run_id': runId,
      if (restId != null) 'rest_id': restId,
      if (followersCount != null) 'followers_count': followersCount,
      if (followingCount != null) 'following_count': followingCount,
      if (statusesCount != null) 'statuses_count': statusesCount,
      if (listedCount != null) 'listed_count': listedCount,
      if (favouritesCount != null) 'favourites_count': favouritesCount,
      if (mediaCount != null) 'media_count': mediaCount,
    });
  }

  TwiUserStatisticsCompanion copyWith({
    Value<int>? id,
    Value<String>? runId,
    Value<String>? restId,
    Value<int>? followersCount,
    Value<int>? followingCount,
    Value<int>? statusesCount,
    Value<int>? listedCount,
    Value<int>? favouritesCount,
    Value<int>? mediaCount,
  }) {
    return TwiUserStatisticsCompanion(
      id: id ?? this.id,
      runId: runId ?? this.runId,
      restId: restId ?? this.restId,
      followersCount: followersCount ?? this.followersCount,
      followingCount: followingCount ?? this.followingCount,
      statusesCount: statusesCount ?? this.statusesCount,
      listedCount: listedCount ?? this.listedCount,
      favouritesCount: favouritesCount ?? this.favouritesCount,
      mediaCount: mediaCount ?? this.mediaCount,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (runId.present) {
      map['run_id'] = Variable<String>(runId.value);
    }
    if (restId.present) {
      map['rest_id'] = Variable<String>(restId.value);
    }
    if (followersCount.present) {
      map['followers_count'] = Variable<int>(followersCount.value);
    }
    if (followingCount.present) {
      map['following_count'] = Variable<int>(followingCount.value);
    }
    if (statusesCount.present) {
      map['statuses_count'] = Variable<int>(statusesCount.value);
    }
    if (listedCount.present) {
      map['listed_count'] = Variable<int>(listedCount.value);
    }
    if (favouritesCount.present) {
      map['favourites_count'] = Variable<int>(favouritesCount.value);
    }
    if (mediaCount.present) {
      map['media_count'] = Variable<int>(mediaCount.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TwiUserStatisticsCompanion(')
          ..write('id: $id, ')
          ..write('runId: $runId, ')
          ..write('restId: $restId, ')
          ..write('followersCount: $followersCount, ')
          ..write('followingCount: $followingCount, ')
          ..write('statusesCount: $statusesCount, ')
          ..write('listedCount: $listedCount, ')
          ..write('favouritesCount: $favouritesCount, ')
          ..write('mediaCount: $mediaCount')
          ..write(')'))
        .toString();
  }
}

class $RunIdsTable extends RunIds with TableInfo<$RunIdsTable, RunIdsEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $RunIdsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _runIdMeta = const VerificationMeta('runId');
  @override
  late final GeneratedColumn<String> runId = GeneratedColumn<String>(
    'run_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _ownerIdMeta = const VerificationMeta(
    'ownerId',
  );
  @override
  late final GeneratedColumn<String> ownerId = GeneratedColumn<String>(
    'owner_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _timestampMeta = const VerificationMeta(
    'timestamp',
  );
  @override
  late final GeneratedColumn<DateTime> timestamp = GeneratedColumn<DateTime>(
    'timestamp',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [runId, ownerId, timestamp];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'run_ids';
  @override
  VerificationContext validateIntegrity(
    Insertable<RunIdsEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('run_id')) {
      context.handle(
        _runIdMeta,
        runId.isAcceptableOrUnknown(data['run_id']!, _runIdMeta),
      );
    } else if (isInserting) {
      context.missing(_runIdMeta);
    }
    if (data.containsKey('owner_id')) {
      context.handle(
        _ownerIdMeta,
        ownerId.isAcceptableOrUnknown(data['owner_id']!, _ownerIdMeta),
      );
    } else if (isInserting) {
      context.missing(_ownerIdMeta);
    }
    if (data.containsKey('timestamp')) {
      context.handle(
        _timestampMeta,
        timestamp.isAcceptableOrUnknown(data['timestamp']!, _timestampMeta),
      );
    } else if (isInserting) {
      context.missing(_timestampMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {runId};
  @override
  RunIdsEntry map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return RunIdsEntry(
      runId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}run_id'],
      )!,
      ownerId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}owner_id'],
      )!,
      timestamp: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}timestamp'],
      )!,
    );
  }

  @override
  $RunIdsTable createAlias(String alias) {
    return $RunIdsTable(attachedDatabase, alias);
  }
}

class RunIdsEntry extends DataClass implements Insertable<RunIdsEntry> {
  final String runId;
  final String ownerId;
  final DateTime timestamp;
  const RunIdsEntry({
    required this.runId,
    required this.ownerId,
    required this.timestamp,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['run_id'] = Variable<String>(runId);
    map['owner_id'] = Variable<String>(ownerId);
    map['timestamp'] = Variable<DateTime>(timestamp);
    return map;
  }

  RunIdsCompanion toCompanion(bool nullToAbsent) {
    return RunIdsCompanion(
      runId: Value(runId),
      ownerId: Value(ownerId),
      timestamp: Value(timestamp),
    );
  }

  factory RunIdsEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return RunIdsEntry(
      runId: serializer.fromJson<String>(json['runId']),
      ownerId: serializer.fromJson<String>(json['ownerId']),
      timestamp: serializer.fromJson<DateTime>(json['timestamp']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'runId': serializer.toJson<String>(runId),
      'ownerId': serializer.toJson<String>(ownerId),
      'timestamp': serializer.toJson<DateTime>(timestamp),
    };
  }

  RunIdsEntry copyWith({String? runId, String? ownerId, DateTime? timestamp}) =>
      RunIdsEntry(
        runId: runId ?? this.runId,
        ownerId: ownerId ?? this.ownerId,
        timestamp: timestamp ?? this.timestamp,
      );
  RunIdsEntry copyWithCompanion(RunIdsCompanion data) {
    return RunIdsEntry(
      runId: data.runId.present ? data.runId.value : this.runId,
      ownerId: data.ownerId.present ? data.ownerId.value : this.ownerId,
      timestamp: data.timestamp.present ? data.timestamp.value : this.timestamp,
    );
  }

  @override
  String toString() {
    return (StringBuffer('RunIdsEntry(')
          ..write('runId: $runId, ')
          ..write('ownerId: $ownerId, ')
          ..write('timestamp: $timestamp')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(runId, ownerId, timestamp);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is RunIdsEntry &&
          other.runId == this.runId &&
          other.ownerId == this.ownerId &&
          other.timestamp == this.timestamp);
}

class RunIdsCompanion extends UpdateCompanion<RunIdsEntry> {
  final Value<String> runId;
  final Value<String> ownerId;
  final Value<DateTime> timestamp;
  final Value<int> rowid;
  const RunIdsCompanion({
    this.runId = const Value.absent(),
    this.ownerId = const Value.absent(),
    this.timestamp = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  RunIdsCompanion.insert({
    required String runId,
    required String ownerId,
    required DateTime timestamp,
    this.rowid = const Value.absent(),
  }) : runId = Value(runId),
       ownerId = Value(ownerId),
       timestamp = Value(timestamp);
  static Insertable<RunIdsEntry> custom({
    Expression<String>? runId,
    Expression<String>? ownerId,
    Expression<DateTime>? timestamp,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (runId != null) 'run_id': runId,
      if (ownerId != null) 'owner_id': ownerId,
      if (timestamp != null) 'timestamp': timestamp,
      if (rowid != null) 'rowid': rowid,
    });
  }

  RunIdsCompanion copyWith({
    Value<String>? runId,
    Value<String>? ownerId,
    Value<DateTime>? timestamp,
    Value<int>? rowid,
  }) {
    return RunIdsCompanion(
      runId: runId ?? this.runId,
      ownerId: ownerId ?? this.ownerId,
      timestamp: timestamp ?? this.timestamp,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (runId.present) {
      map['run_id'] = Variable<String>(runId.value);
    }
    if (ownerId.present) {
      map['owner_id'] = Variable<String>(ownerId.value);
    }
    if (timestamp.present) {
      map['timestamp'] = Variable<DateTime>(timestamp.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('RunIdsCompanion(')
          ..write('runId: $runId, ')
          ..write('ownerId: $ownerId, ')
          ..write('timestamp: $timestamp, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $NetworkUserProfileHistoryTable extends NetworkUserProfileHistory
    with
        TableInfo<
          $NetworkUserProfileHistoryTable,
          NetworkUserProfileHistoryEntry
        > {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $NetworkUserProfileHistoryTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    false,
    hasAutoIncrement: true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'PRIMARY KEY AUTOINCREMENT',
    ),
  );
  static const VerificationMeta _runIdMeta = const VerificationMeta('runId');
  @override
  late final GeneratedColumn<String> runId = GeneratedColumn<String>(
    'run_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _restIdMeta = const VerificationMeta('restId');
  @override
  late final GeneratedColumn<String> restId = GeneratedColumn<String>(
    'rest_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _reverseDiffJsonMeta = const VerificationMeta(
    'reverseDiffJson',
  );
  @override
  late final GeneratedColumn<String> reverseDiffJson = GeneratedColumn<String>(
    'reverse_diff_json',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _timestampMeta = const VerificationMeta(
    'timestamp',
  );
  @override
  late final GeneratedColumn<DateTime> timestamp = GeneratedColumn<DateTime>(
    'timestamp',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    runId,
    restId,
    reverseDiffJson,
    timestamp,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'network_user_profile_history';
  @override
  VerificationContext validateIntegrity(
    Insertable<NetworkUserProfileHistoryEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('run_id')) {
      context.handle(
        _runIdMeta,
        runId.isAcceptableOrUnknown(data['run_id']!, _runIdMeta),
      );
    } else if (isInserting) {
      context.missing(_runIdMeta);
    }
    if (data.containsKey('rest_id')) {
      context.handle(
        _restIdMeta,
        restId.isAcceptableOrUnknown(data['rest_id']!, _restIdMeta),
      );
    } else if (isInserting) {
      context.missing(_restIdMeta);
    }
    if (data.containsKey('reverse_diff_json')) {
      context.handle(
        _reverseDiffJsonMeta,
        reverseDiffJson.isAcceptableOrUnknown(
          data['reverse_diff_json']!,
          _reverseDiffJsonMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_reverseDiffJsonMeta);
    }
    if (data.containsKey('timestamp')) {
      context.handle(
        _timestampMeta,
        timestamp.isAcceptableOrUnknown(data['timestamp']!, _timestampMeta),
      );
    } else if (isInserting) {
      context.missing(_timestampMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  NetworkUserProfileHistoryEntry map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return NetworkUserProfileHistoryEntry(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      )!,
      runId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}run_id'],
      )!,
      restId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}rest_id'],
      )!,
      reverseDiffJson: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}reverse_diff_json'],
      )!,
      timestamp: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}timestamp'],
      )!,
    );
  }

  @override
  $NetworkUserProfileHistoryTable createAlias(String alias) {
    return $NetworkUserProfileHistoryTable(attachedDatabase, alias);
  }
}

class NetworkUserProfileHistoryEntry extends DataClass
    implements Insertable<NetworkUserProfileHistoryEntry> {
  final int id;
  final String runId;
  final String restId;
  final String reverseDiffJson;
  final DateTime timestamp;
  const NetworkUserProfileHistoryEntry({
    required this.id,
    required this.runId,
    required this.restId,
    required this.reverseDiffJson,
    required this.timestamp,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['run_id'] = Variable<String>(runId);
    map['rest_id'] = Variable<String>(restId);
    map['reverse_diff_json'] = Variable<String>(reverseDiffJson);
    map['timestamp'] = Variable<DateTime>(timestamp);
    return map;
  }

  NetworkUserProfileHistoryCompanion toCompanion(bool nullToAbsent) {
    return NetworkUserProfileHistoryCompanion(
      id: Value(id),
      runId: Value(runId),
      restId: Value(restId),
      reverseDiffJson: Value(reverseDiffJson),
      timestamp: Value(timestamp),
    );
  }

  factory NetworkUserProfileHistoryEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return NetworkUserProfileHistoryEntry(
      id: serializer.fromJson<int>(json['id']),
      runId: serializer.fromJson<String>(json['runId']),
      restId: serializer.fromJson<String>(json['restId']),
      reverseDiffJson: serializer.fromJson<String>(json['reverseDiffJson']),
      timestamp: serializer.fromJson<DateTime>(json['timestamp']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'runId': serializer.toJson<String>(runId),
      'restId': serializer.toJson<String>(restId),
      'reverseDiffJson': serializer.toJson<String>(reverseDiffJson),
      'timestamp': serializer.toJson<DateTime>(timestamp),
    };
  }

  NetworkUserProfileHistoryEntry copyWith({
    int? id,
    String? runId,
    String? restId,
    String? reverseDiffJson,
    DateTime? timestamp,
  }) => NetworkUserProfileHistoryEntry(
    id: id ?? this.id,
    runId: runId ?? this.runId,
    restId: restId ?? this.restId,
    reverseDiffJson: reverseDiffJson ?? this.reverseDiffJson,
    timestamp: timestamp ?? this.timestamp,
  );
  NetworkUserProfileHistoryEntry copyWithCompanion(
    NetworkUserProfileHistoryCompanion data,
  ) {
    return NetworkUserProfileHistoryEntry(
      id: data.id.present ? data.id.value : this.id,
      runId: data.runId.present ? data.runId.value : this.runId,
      restId: data.restId.present ? data.restId.value : this.restId,
      reverseDiffJson: data.reverseDiffJson.present
          ? data.reverseDiffJson.value
          : this.reverseDiffJson,
      timestamp: data.timestamp.present ? data.timestamp.value : this.timestamp,
    );
  }

  @override
  String toString() {
    return (StringBuffer('NetworkUserProfileHistoryEntry(')
          ..write('id: $id, ')
          ..write('runId: $runId, ')
          ..write('restId: $restId, ')
          ..write('reverseDiffJson: $reverseDiffJson, ')
          ..write('timestamp: $timestamp')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, runId, restId, reverseDiffJson, timestamp);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is NetworkUserProfileHistoryEntry &&
          other.id == this.id &&
          other.runId == this.runId &&
          other.restId == this.restId &&
          other.reverseDiffJson == this.reverseDiffJson &&
          other.timestamp == this.timestamp);
}

class NetworkUserProfileHistoryCompanion
    extends UpdateCompanion<NetworkUserProfileHistoryEntry> {
  final Value<int> id;
  final Value<String> runId;
  final Value<String> restId;
  final Value<String> reverseDiffJson;
  final Value<DateTime> timestamp;
  const NetworkUserProfileHistoryCompanion({
    this.id = const Value.absent(),
    this.runId = const Value.absent(),
    this.restId = const Value.absent(),
    this.reverseDiffJson = const Value.absent(),
    this.timestamp = const Value.absent(),
  });
  NetworkUserProfileHistoryCompanion.insert({
    this.id = const Value.absent(),
    required String runId,
    required String restId,
    required String reverseDiffJson,
    required DateTime timestamp,
  }) : runId = Value(runId),
       restId = Value(restId),
       reverseDiffJson = Value(reverseDiffJson),
       timestamp = Value(timestamp);
  static Insertable<NetworkUserProfileHistoryEntry> custom({
    Expression<int>? id,
    Expression<String>? runId,
    Expression<String>? restId,
    Expression<String>? reverseDiffJson,
    Expression<DateTime>? timestamp,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (runId != null) 'run_id': runId,
      if (restId != null) 'rest_id': restId,
      if (reverseDiffJson != null) 'reverse_diff_json': reverseDiffJson,
      if (timestamp != null) 'timestamp': timestamp,
    });
  }

  NetworkUserProfileHistoryCompanion copyWith({
    Value<int>? id,
    Value<String>? runId,
    Value<String>? restId,
    Value<String>? reverseDiffJson,
    Value<DateTime>? timestamp,
  }) {
    return NetworkUserProfileHistoryCompanion(
      id: id ?? this.id,
      runId: runId ?? this.runId,
      restId: restId ?? this.restId,
      reverseDiffJson: reverseDiffJson ?? this.reverseDiffJson,
      timestamp: timestamp ?? this.timestamp,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (runId.present) {
      map['run_id'] = Variable<String>(runId.value);
    }
    if (restId.present) {
      map['rest_id'] = Variable<String>(restId.value);
    }
    if (reverseDiffJson.present) {
      map['reverse_diff_json'] = Variable<String>(reverseDiffJson.value);
    }
    if (timestamp.present) {
      map['timestamp'] = Variable<DateTime>(timestamp.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('NetworkUserProfileHistoryCompanion(')
          ..write('id: $id, ')
          ..write('runId: $runId, ')
          ..write('restId: $restId, ')
          ..write('reverseDiffJson: $reverseDiffJson, ')
          ..write('timestamp: $timestamp')
          ..write(')'))
        .toString();
  }
}

class $NetworkUserStatisticsHistoryTable extends NetworkUserStatisticsHistory
    with
        TableInfo<
          $NetworkUserStatisticsHistoryTable,
          NetworkUserStatisticsHistoryEntry
        > {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $NetworkUserStatisticsHistoryTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    false,
    hasAutoIncrement: true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'PRIMARY KEY AUTOINCREMENT',
    ),
  );
  static const VerificationMeta _runIdMeta = const VerificationMeta('runId');
  @override
  late final GeneratedColumn<String> runId = GeneratedColumn<String>(
    'run_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _restIdMeta = const VerificationMeta('restId');
  @override
  late final GeneratedColumn<String> restId = GeneratedColumn<String>(
    'rest_id',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _reverseDiffJsonMeta = const VerificationMeta(
    'reverseDiffJson',
  );
  @override
  late final GeneratedColumn<String> reverseDiffJson = GeneratedColumn<String>(
    'reverse_diff_json',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _timestampMeta = const VerificationMeta(
    'timestamp',
  );
  @override
  late final GeneratedColumn<DateTime> timestamp = GeneratedColumn<DateTime>(
    'timestamp',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    runId,
    restId,
    reverseDiffJson,
    timestamp,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'network_user_statistics_history';
  @override
  VerificationContext validateIntegrity(
    Insertable<NetworkUserStatisticsHistoryEntry> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('run_id')) {
      context.handle(
        _runIdMeta,
        runId.isAcceptableOrUnknown(data['run_id']!, _runIdMeta),
      );
    } else if (isInserting) {
      context.missing(_runIdMeta);
    }
    if (data.containsKey('rest_id')) {
      context.handle(
        _restIdMeta,
        restId.isAcceptableOrUnknown(data['rest_id']!, _restIdMeta),
      );
    } else if (isInserting) {
      context.missing(_restIdMeta);
    }
    if (data.containsKey('reverse_diff_json')) {
      context.handle(
        _reverseDiffJsonMeta,
        reverseDiffJson.isAcceptableOrUnknown(
          data['reverse_diff_json']!,
          _reverseDiffJsonMeta,
        ),
      );
    } else if (isInserting) {
      context.missing(_reverseDiffJsonMeta);
    }
    if (data.containsKey('timestamp')) {
      context.handle(
        _timestampMeta,
        timestamp.isAcceptableOrUnknown(data['timestamp']!, _timestampMeta),
      );
    } else if (isInserting) {
      context.missing(_timestampMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  NetworkUserStatisticsHistoryEntry map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return NetworkUserStatisticsHistoryEntry(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      )!,
      runId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}run_id'],
      )!,
      restId: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}rest_id'],
      )!,
      reverseDiffJson: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}reverse_diff_json'],
      )!,
      timestamp: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}timestamp'],
      )!,
    );
  }

  @override
  $NetworkUserStatisticsHistoryTable createAlias(String alias) {
    return $NetworkUserStatisticsHistoryTable(attachedDatabase, alias);
  }
}

class NetworkUserStatisticsHistoryEntry extends DataClass
    implements Insertable<NetworkUserStatisticsHistoryEntry> {
  final int id;
  final String runId;
  final String restId;
  final String reverseDiffJson;
  final DateTime timestamp;
  const NetworkUserStatisticsHistoryEntry({
    required this.id,
    required this.runId,
    required this.restId,
    required this.reverseDiffJson,
    required this.timestamp,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['run_id'] = Variable<String>(runId);
    map['rest_id'] = Variable<String>(restId);
    map['reverse_diff_json'] = Variable<String>(reverseDiffJson);
    map['timestamp'] = Variable<DateTime>(timestamp);
    return map;
  }

  NetworkUserStatisticsHistoryCompanion toCompanion(bool nullToAbsent) {
    return NetworkUserStatisticsHistoryCompanion(
      id: Value(id),
      runId: Value(runId),
      restId: Value(restId),
      reverseDiffJson: Value(reverseDiffJson),
      timestamp: Value(timestamp),
    );
  }

  factory NetworkUserStatisticsHistoryEntry.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return NetworkUserStatisticsHistoryEntry(
      id: serializer.fromJson<int>(json['id']),
      runId: serializer.fromJson<String>(json['runId']),
      restId: serializer.fromJson<String>(json['restId']),
      reverseDiffJson: serializer.fromJson<String>(json['reverseDiffJson']),
      timestamp: serializer.fromJson<DateTime>(json['timestamp']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'runId': serializer.toJson<String>(runId),
      'restId': serializer.toJson<String>(restId),
      'reverseDiffJson': serializer.toJson<String>(reverseDiffJson),
      'timestamp': serializer.toJson<DateTime>(timestamp),
    };
  }

  NetworkUserStatisticsHistoryEntry copyWith({
    int? id,
    String? runId,
    String? restId,
    String? reverseDiffJson,
    DateTime? timestamp,
  }) => NetworkUserStatisticsHistoryEntry(
    id: id ?? this.id,
    runId: runId ?? this.runId,
    restId: restId ?? this.restId,
    reverseDiffJson: reverseDiffJson ?? this.reverseDiffJson,
    timestamp: timestamp ?? this.timestamp,
  );
  NetworkUserStatisticsHistoryEntry copyWithCompanion(
    NetworkUserStatisticsHistoryCompanion data,
  ) {
    return NetworkUserStatisticsHistoryEntry(
      id: data.id.present ? data.id.value : this.id,
      runId: data.runId.present ? data.runId.value : this.runId,
      restId: data.restId.present ? data.restId.value : this.restId,
      reverseDiffJson: data.reverseDiffJson.present
          ? data.reverseDiffJson.value
          : this.reverseDiffJson,
      timestamp: data.timestamp.present ? data.timestamp.value : this.timestamp,
    );
  }

  @override
  String toString() {
    return (StringBuffer('NetworkUserStatisticsHistoryEntry(')
          ..write('id: $id, ')
          ..write('runId: $runId, ')
          ..write('restId: $restId, ')
          ..write('reverseDiffJson: $reverseDiffJson, ')
          ..write('timestamp: $timestamp')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, runId, restId, reverseDiffJson, timestamp);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is NetworkUserStatisticsHistoryEntry &&
          other.id == this.id &&
          other.runId == this.runId &&
          other.restId == this.restId &&
          other.reverseDiffJson == this.reverseDiffJson &&
          other.timestamp == this.timestamp);
}

class NetworkUserStatisticsHistoryCompanion
    extends UpdateCompanion<NetworkUserStatisticsHistoryEntry> {
  final Value<int> id;
  final Value<String> runId;
  final Value<String> restId;
  final Value<String> reverseDiffJson;
  final Value<DateTime> timestamp;
  const NetworkUserStatisticsHistoryCompanion({
    this.id = const Value.absent(),
    this.runId = const Value.absent(),
    this.restId = const Value.absent(),
    this.reverseDiffJson = const Value.absent(),
    this.timestamp = const Value.absent(),
  });
  NetworkUserStatisticsHistoryCompanion.insert({
    this.id = const Value.absent(),
    required String runId,
    required String restId,
    required String reverseDiffJson,
    required DateTime timestamp,
  }) : runId = Value(runId),
       restId = Value(restId),
       reverseDiffJson = Value(reverseDiffJson),
       timestamp = Value(timestamp);
  static Insertable<NetworkUserStatisticsHistoryEntry> custom({
    Expression<int>? id,
    Expression<String>? runId,
    Expression<String>? restId,
    Expression<String>? reverseDiffJson,
    Expression<DateTime>? timestamp,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (runId != null) 'run_id': runId,
      if (restId != null) 'rest_id': restId,
      if (reverseDiffJson != null) 'reverse_diff_json': reverseDiffJson,
      if (timestamp != null) 'timestamp': timestamp,
    });
  }

  NetworkUserStatisticsHistoryCompanion copyWith({
    Value<int>? id,
    Value<String>? runId,
    Value<String>? restId,
    Value<String>? reverseDiffJson,
    Value<DateTime>? timestamp,
  }) {
    return NetworkUserStatisticsHistoryCompanion(
      id: id ?? this.id,
      runId: runId ?? this.runId,
      restId: restId ?? this.restId,
      reverseDiffJson: reverseDiffJson ?? this.reverseDiffJson,
      timestamp: timestamp ?? this.timestamp,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (runId.present) {
      map['run_id'] = Variable<String>(runId.value);
    }
    if (restId.present) {
      map['rest_id'] = Variable<String>(restId.value);
    }
    if (reverseDiffJson.present) {
      map['reverse_diff_json'] = Variable<String>(reverseDiffJson.value);
    }
    if (timestamp.present) {
      map['timestamp'] = Variable<DateTime>(timestamp.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('NetworkUserStatisticsHistoryCompanion(')
          ..write('id: $id, ')
          ..write('runId: $runId, ')
          ..write('restId: $restId, ')
          ..write('reverseDiffJson: $reverseDiffJson, ')
          ..write('timestamp: $timestamp')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $LoggedAccountsTable loggedAccounts = $LoggedAccountsTable(this);
  late final $TwiUserProfileTable twiUserProfile = $TwiUserProfileTable(this);
  late final $ChangeReportsTable changeReports = $ChangeReportsTable(this);
  late final $TwiUserMediaTable twiUserMedia = $TwiUserMediaTable(this);
  late final $TwiUserRelationshipTable twiUserRelationship =
      $TwiUserRelationshipTable(this);
  late final $TwiUserStatisticsTable twiUserStatistics =
      $TwiUserStatisticsTable(this);
  late final $RunIdsTable runIds = $RunIdsTable(this);
  late final $NetworkUserProfileHistoryTable networkUserProfileHistory =
      $NetworkUserProfileHistoryTable(this);
  late final $NetworkUserStatisticsHistoryTable networkUserStatisticsHistory =
      $NetworkUserStatisticsHistoryTable(this);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
    loggedAccounts,
    twiUserProfile,
    changeReports,
    twiUserMedia,
    twiUserRelationship,
    twiUserStatistics,
    runIds,
    networkUserProfileHistory,
    networkUserStatisticsHistory,
  ];
  @override
  StreamQueryUpdateRules get streamUpdateRules => const StreamQueryUpdateRules([
    WritePropagation(
      on: TableUpdateQuery.onTableName(
        'logged_accounts',
        limitUpdateKind: UpdateKind.delete,
      ),
      result: [TableUpdate('change_reports', kind: UpdateKind.delete)],
    ),
  ]);
}

typedef $$LoggedAccountsTableCreateCompanionBuilder =
    LoggedAccountsCompanion Function({
      required String restId,
      Value<int> rowid,
    });
typedef $$LoggedAccountsTableUpdateCompanionBuilder =
    LoggedAccountsCompanion Function({Value<String> restId, Value<int> rowid});

final class $$LoggedAccountsTableReferences
    extends BaseReferences<_$AppDatabase, $LoggedAccountsTable, LoggedAccount> {
  $$LoggedAccountsTableReferences(
    super.$_db,
    super.$_table,
    super.$_typedResult,
  );

  static MultiTypedResultKey<$ChangeReportsTable, List<ChangeReportEntry>>
  _changeReportsRefsTable(_$AppDatabase db) => MultiTypedResultKey.fromTable(
    db.changeReports,
    aliasName: $_aliasNameGenerator(
      db.loggedAccounts.restId,
      db.changeReports.ownerId,
    ),
  );

  $$ChangeReportsTableProcessedTableManager get changeReportsRefs {
    final manager = $$ChangeReportsTableTableManager($_db, $_db.changeReports)
        .filter(
          (f) => f.ownerId.restId.sqlEquals($_itemColumn<String>('rest_id')!),
        );

    final cache = $_typedResult.readTableOrNull(_changeReportsRefsTable($_db));
    return ProcessedTableManager(
      manager.$state.copyWith(prefetchedData: cache),
    );
  }
}

class $$LoggedAccountsTableFilterComposer
    extends Composer<_$AppDatabase, $LoggedAccountsTable> {
  $$LoggedAccountsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get restId => $composableBuilder(
    column: $table.restId,
    builder: (column) => ColumnFilters(column),
  );

  Expression<bool> changeReportsRefs(
    Expression<bool> Function($$ChangeReportsTableFilterComposer f) f,
  ) {
    final $$ChangeReportsTableFilterComposer composer = $composerBuilder(
      composer: this,
      getCurrentColumn: (t) => t.restId,
      referencedTable: $db.changeReports,
      getReferencedColumn: (t) => t.ownerId,
      builder:
          (
            joinBuilder, {
            $addJoinBuilderToRootComposer,
            $removeJoinBuilderFromRootComposer,
          }) => $$ChangeReportsTableFilterComposer(
            $db: $db,
            $table: $db.changeReports,
            $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
            joinBuilder: joinBuilder,
            $removeJoinBuilderFromRootComposer:
                $removeJoinBuilderFromRootComposer,
          ),
    );
    return f(composer);
  }
}

class $$LoggedAccountsTableOrderingComposer
    extends Composer<_$AppDatabase, $LoggedAccountsTable> {
  $$LoggedAccountsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get restId => $composableBuilder(
    column: $table.restId,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$LoggedAccountsTableAnnotationComposer
    extends Composer<_$AppDatabase, $LoggedAccountsTable> {
  $$LoggedAccountsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get restId =>
      $composableBuilder(column: $table.restId, builder: (column) => column);

  Expression<T> changeReportsRefs<T extends Object>(
    Expression<T> Function($$ChangeReportsTableAnnotationComposer a) f,
  ) {
    final $$ChangeReportsTableAnnotationComposer composer = $composerBuilder(
      composer: this,
      getCurrentColumn: (t) => t.restId,
      referencedTable: $db.changeReports,
      getReferencedColumn: (t) => t.ownerId,
      builder:
          (
            joinBuilder, {
            $addJoinBuilderToRootComposer,
            $removeJoinBuilderFromRootComposer,
          }) => $$ChangeReportsTableAnnotationComposer(
            $db: $db,
            $table: $db.changeReports,
            $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
            joinBuilder: joinBuilder,
            $removeJoinBuilderFromRootComposer:
                $removeJoinBuilderFromRootComposer,
          ),
    );
    return f(composer);
  }
}

class $$LoggedAccountsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $LoggedAccountsTable,
          LoggedAccount,
          $$LoggedAccountsTableFilterComposer,
          $$LoggedAccountsTableOrderingComposer,
          $$LoggedAccountsTableAnnotationComposer,
          $$LoggedAccountsTableCreateCompanionBuilder,
          $$LoggedAccountsTableUpdateCompanionBuilder,
          (LoggedAccount, $$LoggedAccountsTableReferences),
          LoggedAccount,
          PrefetchHooks Function({bool changeReportsRefs})
        > {
  $$LoggedAccountsTableTableManager(
    _$AppDatabase db,
    $LoggedAccountsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$LoggedAccountsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$LoggedAccountsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$LoggedAccountsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<String> restId = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => LoggedAccountsCompanion(restId: restId, rowid: rowid),
          createCompanionCallback:
              ({
                required String restId,
                Value<int> rowid = const Value.absent(),
              }) =>
                  LoggedAccountsCompanion.insert(restId: restId, rowid: rowid),
          withReferenceMapper: (p0) => p0
              .map(
                (e) => (
                  e.readTable(table),
                  $$LoggedAccountsTableReferences(db, table, e),
                ),
              )
              .toList(),
          prefetchHooksCallback: ({changeReportsRefs = false}) {
            return PrefetchHooks(
              db: db,
              explicitlyWatchedTables: [
                if (changeReportsRefs) db.changeReports,
              ],
              addJoins: null,
              getPrefetchedDataCallback: (items) async {
                return [
                  if (changeReportsRefs)
                    await $_getPrefetchedData<
                      LoggedAccount,
                      $LoggedAccountsTable,
                      ChangeReportEntry
                    >(
                      currentTable: table,
                      referencedTable: $$LoggedAccountsTableReferences
                          ._changeReportsRefsTable(db),
                      managerFromTypedResult: (p0) =>
                          $$LoggedAccountsTableReferences(
                            db,
                            table,
                            p0,
                          ).changeReportsRefs,
                      referencedItemsForCurrentItem: (item, referencedItems) =>
                          referencedItems.where(
                            (e) => e.ownerId == item.restId,
                          ),
                      typedResults: items,
                    ),
                ];
              },
            );
          },
        ),
      );
}

typedef $$LoggedAccountsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $LoggedAccountsTable,
      LoggedAccount,
      $$LoggedAccountsTableFilterComposer,
      $$LoggedAccountsTableOrderingComposer,
      $$LoggedAccountsTableAnnotationComposer,
      $$LoggedAccountsTableCreateCompanionBuilder,
      $$LoggedAccountsTableUpdateCompanionBuilder,
      (LoggedAccount, $$LoggedAccountsTableReferences),
      LoggedAccount,
      PrefetchHooks Function({bool changeReportsRefs})
    >;
typedef $$TwiUserProfileTableCreateCompanionBuilder =
    TwiUserProfileCompanion Function({
      Value<int> id,
      required String runId,
      required String restId,
      Value<String?> name,
      Value<String?> screenName,
      Value<String?> avatarUrl,
      Value<String?> bannerUrl,
      Value<String?> bio,
      Value<String?> link,
      Value<String?> avatarLocalPath,
      Value<String?> bannerLocalPath,
      Value<String?> location,
      Value<String?> pinnedTweetIdStr,
      Value<String?> parodyCommentaryFanLabel,
      Value<String?> birthdateYear,
      Value<String?> birthdateMonth,
      Value<String?> birthdateDay,
      Value<String?> automatedScreenName,
      Value<String?> joinedTime,
      Value<bool> isVerified,
      Value<bool> isProtected,
    });
typedef $$TwiUserProfileTableUpdateCompanionBuilder =
    TwiUserProfileCompanion Function({
      Value<int> id,
      Value<String> runId,
      Value<String> restId,
      Value<String?> name,
      Value<String?> screenName,
      Value<String?> avatarUrl,
      Value<String?> bannerUrl,
      Value<String?> bio,
      Value<String?> link,
      Value<String?> avatarLocalPath,
      Value<String?> bannerLocalPath,
      Value<String?> location,
      Value<String?> pinnedTweetIdStr,
      Value<String?> parodyCommentaryFanLabel,
      Value<String?> birthdateYear,
      Value<String?> birthdateMonth,
      Value<String?> birthdateDay,
      Value<String?> automatedScreenName,
      Value<String?> joinedTime,
      Value<bool> isVerified,
      Value<bool> isProtected,
    });

class $$TwiUserProfileTableFilterComposer
    extends Composer<_$AppDatabase, $TwiUserProfileTable> {
  $$TwiUserProfileTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get runId => $composableBuilder(
    column: $table.runId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get restId => $composableBuilder(
    column: $table.restId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get name => $composableBuilder(
    column: $table.name,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get screenName => $composableBuilder(
    column: $table.screenName,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get avatarUrl => $composableBuilder(
    column: $table.avatarUrl,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get bannerUrl => $composableBuilder(
    column: $table.bannerUrl,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get bio => $composableBuilder(
    column: $table.bio,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get link => $composableBuilder(
    column: $table.link,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get avatarLocalPath => $composableBuilder(
    column: $table.avatarLocalPath,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get bannerLocalPath => $composableBuilder(
    column: $table.bannerLocalPath,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get location => $composableBuilder(
    column: $table.location,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pinnedTweetIdStr => $composableBuilder(
    column: $table.pinnedTweetIdStr,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get parodyCommentaryFanLabel => $composableBuilder(
    column: $table.parodyCommentaryFanLabel,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get birthdateYear => $composableBuilder(
    column: $table.birthdateYear,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get birthdateMonth => $composableBuilder(
    column: $table.birthdateMonth,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get birthdateDay => $composableBuilder(
    column: $table.birthdateDay,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get automatedScreenName => $composableBuilder(
    column: $table.automatedScreenName,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get joinedTime => $composableBuilder(
    column: $table.joinedTime,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<bool> get isVerified => $composableBuilder(
    column: $table.isVerified,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<bool> get isProtected => $composableBuilder(
    column: $table.isProtected,
    builder: (column) => ColumnFilters(column),
  );
}

class $$TwiUserProfileTableOrderingComposer
    extends Composer<_$AppDatabase, $TwiUserProfileTable> {
  $$TwiUserProfileTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get runId => $composableBuilder(
    column: $table.runId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get restId => $composableBuilder(
    column: $table.restId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get name => $composableBuilder(
    column: $table.name,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get screenName => $composableBuilder(
    column: $table.screenName,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get avatarUrl => $composableBuilder(
    column: $table.avatarUrl,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get bannerUrl => $composableBuilder(
    column: $table.bannerUrl,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get bio => $composableBuilder(
    column: $table.bio,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get link => $composableBuilder(
    column: $table.link,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get avatarLocalPath => $composableBuilder(
    column: $table.avatarLocalPath,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get bannerLocalPath => $composableBuilder(
    column: $table.bannerLocalPath,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get location => $composableBuilder(
    column: $table.location,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pinnedTweetIdStr => $composableBuilder(
    column: $table.pinnedTweetIdStr,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get parodyCommentaryFanLabel => $composableBuilder(
    column: $table.parodyCommentaryFanLabel,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get birthdateYear => $composableBuilder(
    column: $table.birthdateYear,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get birthdateMonth => $composableBuilder(
    column: $table.birthdateMonth,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get birthdateDay => $composableBuilder(
    column: $table.birthdateDay,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get automatedScreenName => $composableBuilder(
    column: $table.automatedScreenName,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get joinedTime => $composableBuilder(
    column: $table.joinedTime,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<bool> get isVerified => $composableBuilder(
    column: $table.isVerified,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<bool> get isProtected => $composableBuilder(
    column: $table.isProtected,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$TwiUserProfileTableAnnotationComposer
    extends Composer<_$AppDatabase, $TwiUserProfileTable> {
  $$TwiUserProfileTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get runId =>
      $composableBuilder(column: $table.runId, builder: (column) => column);

  GeneratedColumn<String> get restId =>
      $composableBuilder(column: $table.restId, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<String> get screenName => $composableBuilder(
    column: $table.screenName,
    builder: (column) => column,
  );

  GeneratedColumn<String> get avatarUrl =>
      $composableBuilder(column: $table.avatarUrl, builder: (column) => column);

  GeneratedColumn<String> get bannerUrl =>
      $composableBuilder(column: $table.bannerUrl, builder: (column) => column);

  GeneratedColumn<String> get bio =>
      $composableBuilder(column: $table.bio, builder: (column) => column);

  GeneratedColumn<String> get link =>
      $composableBuilder(column: $table.link, builder: (column) => column);

  GeneratedColumn<String> get avatarLocalPath => $composableBuilder(
    column: $table.avatarLocalPath,
    builder: (column) => column,
  );

  GeneratedColumn<String> get bannerLocalPath => $composableBuilder(
    column: $table.bannerLocalPath,
    builder: (column) => column,
  );

  GeneratedColumn<String> get location =>
      $composableBuilder(column: $table.location, builder: (column) => column);

  GeneratedColumn<String> get pinnedTweetIdStr => $composableBuilder(
    column: $table.pinnedTweetIdStr,
    builder: (column) => column,
  );

  GeneratedColumn<String> get parodyCommentaryFanLabel => $composableBuilder(
    column: $table.parodyCommentaryFanLabel,
    builder: (column) => column,
  );

  GeneratedColumn<String> get birthdateYear => $composableBuilder(
    column: $table.birthdateYear,
    builder: (column) => column,
  );

  GeneratedColumn<String> get birthdateMonth => $composableBuilder(
    column: $table.birthdateMonth,
    builder: (column) => column,
  );

  GeneratedColumn<String> get birthdateDay => $composableBuilder(
    column: $table.birthdateDay,
    builder: (column) => column,
  );

  GeneratedColumn<String> get automatedScreenName => $composableBuilder(
    column: $table.automatedScreenName,
    builder: (column) => column,
  );

  GeneratedColumn<String> get joinedTime => $composableBuilder(
    column: $table.joinedTime,
    builder: (column) => column,
  );

  GeneratedColumn<bool> get isVerified => $composableBuilder(
    column: $table.isVerified,
    builder: (column) => column,
  );

  GeneratedColumn<bool> get isProtected => $composableBuilder(
    column: $table.isProtected,
    builder: (column) => column,
  );
}

class $$TwiUserProfileTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $TwiUserProfileTable,
          TwiUserProfileEntry,
          $$TwiUserProfileTableFilterComposer,
          $$TwiUserProfileTableOrderingComposer,
          $$TwiUserProfileTableAnnotationComposer,
          $$TwiUserProfileTableCreateCompanionBuilder,
          $$TwiUserProfileTableUpdateCompanionBuilder,
          (
            TwiUserProfileEntry,
            BaseReferences<
              _$AppDatabase,
              $TwiUserProfileTable,
              TwiUserProfileEntry
            >,
          ),
          TwiUserProfileEntry,
          PrefetchHooks Function()
        > {
  $$TwiUserProfileTableTableManager(
    _$AppDatabase db,
    $TwiUserProfileTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$TwiUserProfileTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$TwiUserProfileTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$TwiUserProfileTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                Value<String> runId = const Value.absent(),
                Value<String> restId = const Value.absent(),
                Value<String?> name = const Value.absent(),
                Value<String?> screenName = const Value.absent(),
                Value<String?> avatarUrl = const Value.absent(),
                Value<String?> bannerUrl = const Value.absent(),
                Value<String?> bio = const Value.absent(),
                Value<String?> link = const Value.absent(),
                Value<String?> avatarLocalPath = const Value.absent(),
                Value<String?> bannerLocalPath = const Value.absent(),
                Value<String?> location = const Value.absent(),
                Value<String?> pinnedTweetIdStr = const Value.absent(),
                Value<String?> parodyCommentaryFanLabel = const Value.absent(),
                Value<String?> birthdateYear = const Value.absent(),
                Value<String?> birthdateMonth = const Value.absent(),
                Value<String?> birthdateDay = const Value.absent(),
                Value<String?> automatedScreenName = const Value.absent(),
                Value<String?> joinedTime = const Value.absent(),
                Value<bool> isVerified = const Value.absent(),
                Value<bool> isProtected = const Value.absent(),
              }) => TwiUserProfileCompanion(
                id: id,
                runId: runId,
                restId: restId,
                name: name,
                screenName: screenName,
                avatarUrl: avatarUrl,
                bannerUrl: bannerUrl,
                bio: bio,
                link: link,
                avatarLocalPath: avatarLocalPath,
                bannerLocalPath: bannerLocalPath,
                location: location,
                pinnedTweetIdStr: pinnedTweetIdStr,
                parodyCommentaryFanLabel: parodyCommentaryFanLabel,
                birthdateYear: birthdateYear,
                birthdateMonth: birthdateMonth,
                birthdateDay: birthdateDay,
                automatedScreenName: automatedScreenName,
                joinedTime: joinedTime,
                isVerified: isVerified,
                isProtected: isProtected,
              ),
          createCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                required String runId,
                required String restId,
                Value<String?> name = const Value.absent(),
                Value<String?> screenName = const Value.absent(),
                Value<String?> avatarUrl = const Value.absent(),
                Value<String?> bannerUrl = const Value.absent(),
                Value<String?> bio = const Value.absent(),
                Value<String?> link = const Value.absent(),
                Value<String?> avatarLocalPath = const Value.absent(),
                Value<String?> bannerLocalPath = const Value.absent(),
                Value<String?> location = const Value.absent(),
                Value<String?> pinnedTweetIdStr = const Value.absent(),
                Value<String?> parodyCommentaryFanLabel = const Value.absent(),
                Value<String?> birthdateYear = const Value.absent(),
                Value<String?> birthdateMonth = const Value.absent(),
                Value<String?> birthdateDay = const Value.absent(),
                Value<String?> automatedScreenName = const Value.absent(),
                Value<String?> joinedTime = const Value.absent(),
                Value<bool> isVerified = const Value.absent(),
                Value<bool> isProtected = const Value.absent(),
              }) => TwiUserProfileCompanion.insert(
                id: id,
                runId: runId,
                restId: restId,
                name: name,
                screenName: screenName,
                avatarUrl: avatarUrl,
                bannerUrl: bannerUrl,
                bio: bio,
                link: link,
                avatarLocalPath: avatarLocalPath,
                bannerLocalPath: bannerLocalPath,
                location: location,
                pinnedTweetIdStr: pinnedTweetIdStr,
                parodyCommentaryFanLabel: parodyCommentaryFanLabel,
                birthdateYear: birthdateYear,
                birthdateMonth: birthdateMonth,
                birthdateDay: birthdateDay,
                automatedScreenName: automatedScreenName,
                joinedTime: joinedTime,
                isVerified: isVerified,
                isProtected: isProtected,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$TwiUserProfileTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $TwiUserProfileTable,
      TwiUserProfileEntry,
      $$TwiUserProfileTableFilterComposer,
      $$TwiUserProfileTableOrderingComposer,
      $$TwiUserProfileTableAnnotationComposer,
      $$TwiUserProfileTableCreateCompanionBuilder,
      $$TwiUserProfileTableUpdateCompanionBuilder,
      (
        TwiUserProfileEntry,
        BaseReferences<
          _$AppDatabase,
          $TwiUserProfileTable,
          TwiUserProfileEntry
        >,
      ),
      TwiUserProfileEntry,
      PrefetchHooks Function()
    >;
typedef $$ChangeReportsTableCreateCompanionBuilder =
    ChangeReportsCompanion Function({
      Value<int> id,
      required String ownerId,
      required String userId,
      required String changeType,
      required DateTime timestamp,
      Value<String?> userSnapshotJson,
    });
typedef $$ChangeReportsTableUpdateCompanionBuilder =
    ChangeReportsCompanion Function({
      Value<int> id,
      Value<String> ownerId,
      Value<String> userId,
      Value<String> changeType,
      Value<DateTime> timestamp,
      Value<String?> userSnapshotJson,
    });

final class $$ChangeReportsTableReferences
    extends
        BaseReferences<_$AppDatabase, $ChangeReportsTable, ChangeReportEntry> {
  $$ChangeReportsTableReferences(
    super.$_db,
    super.$_table,
    super.$_typedResult,
  );

  static $LoggedAccountsTable _ownerIdTable(_$AppDatabase db) =>
      db.loggedAccounts.createAlias(
        $_aliasNameGenerator(
          db.changeReports.ownerId,
          db.loggedAccounts.restId,
        ),
      );

  $$LoggedAccountsTableProcessedTableManager get ownerId {
    final $_column = $_itemColumn<String>('owner_id')!;

    final manager = $$LoggedAccountsTableTableManager(
      $_db,
      $_db.loggedAccounts,
    ).filter((f) => f.restId.sqlEquals($_column));
    final item = $_typedResult.readTableOrNull(_ownerIdTable($_db));
    if (item == null) return manager;
    return ProcessedTableManager(
      manager.$state.copyWith(prefetchedData: [item]),
    );
  }
}

class $$ChangeReportsTableFilterComposer
    extends Composer<_$AppDatabase, $ChangeReportsTable> {
  $$ChangeReportsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get userId => $composableBuilder(
    column: $table.userId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get changeType => $composableBuilder(
    column: $table.changeType,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get timestamp => $composableBuilder(
    column: $table.timestamp,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get userSnapshotJson => $composableBuilder(
    column: $table.userSnapshotJson,
    builder: (column) => ColumnFilters(column),
  );

  $$LoggedAccountsTableFilterComposer get ownerId {
    final $$LoggedAccountsTableFilterComposer composer = $composerBuilder(
      composer: this,
      getCurrentColumn: (t) => t.ownerId,
      referencedTable: $db.loggedAccounts,
      getReferencedColumn: (t) => t.restId,
      builder:
          (
            joinBuilder, {
            $addJoinBuilderToRootComposer,
            $removeJoinBuilderFromRootComposer,
          }) => $$LoggedAccountsTableFilterComposer(
            $db: $db,
            $table: $db.loggedAccounts,
            $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
            joinBuilder: joinBuilder,
            $removeJoinBuilderFromRootComposer:
                $removeJoinBuilderFromRootComposer,
          ),
    );
    return composer;
  }
}

class $$ChangeReportsTableOrderingComposer
    extends Composer<_$AppDatabase, $ChangeReportsTable> {
  $$ChangeReportsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get userId => $composableBuilder(
    column: $table.userId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get changeType => $composableBuilder(
    column: $table.changeType,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get timestamp => $composableBuilder(
    column: $table.timestamp,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get userSnapshotJson => $composableBuilder(
    column: $table.userSnapshotJson,
    builder: (column) => ColumnOrderings(column),
  );

  $$LoggedAccountsTableOrderingComposer get ownerId {
    final $$LoggedAccountsTableOrderingComposer composer = $composerBuilder(
      composer: this,
      getCurrentColumn: (t) => t.ownerId,
      referencedTable: $db.loggedAccounts,
      getReferencedColumn: (t) => t.restId,
      builder:
          (
            joinBuilder, {
            $addJoinBuilderToRootComposer,
            $removeJoinBuilderFromRootComposer,
          }) => $$LoggedAccountsTableOrderingComposer(
            $db: $db,
            $table: $db.loggedAccounts,
            $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
            joinBuilder: joinBuilder,
            $removeJoinBuilderFromRootComposer:
                $removeJoinBuilderFromRootComposer,
          ),
    );
    return composer;
  }
}

class $$ChangeReportsTableAnnotationComposer
    extends Composer<_$AppDatabase, $ChangeReportsTable> {
  $$ChangeReportsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get changeType => $composableBuilder(
    column: $table.changeType,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get timestamp =>
      $composableBuilder(column: $table.timestamp, builder: (column) => column);

  GeneratedColumn<String> get userSnapshotJson => $composableBuilder(
    column: $table.userSnapshotJson,
    builder: (column) => column,
  );

  $$LoggedAccountsTableAnnotationComposer get ownerId {
    final $$LoggedAccountsTableAnnotationComposer composer = $composerBuilder(
      composer: this,
      getCurrentColumn: (t) => t.ownerId,
      referencedTable: $db.loggedAccounts,
      getReferencedColumn: (t) => t.restId,
      builder:
          (
            joinBuilder, {
            $addJoinBuilderToRootComposer,
            $removeJoinBuilderFromRootComposer,
          }) => $$LoggedAccountsTableAnnotationComposer(
            $db: $db,
            $table: $db.loggedAccounts,
            $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
            joinBuilder: joinBuilder,
            $removeJoinBuilderFromRootComposer:
                $removeJoinBuilderFromRootComposer,
          ),
    );
    return composer;
  }
}

class $$ChangeReportsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ChangeReportsTable,
          ChangeReportEntry,
          $$ChangeReportsTableFilterComposer,
          $$ChangeReportsTableOrderingComposer,
          $$ChangeReportsTableAnnotationComposer,
          $$ChangeReportsTableCreateCompanionBuilder,
          $$ChangeReportsTableUpdateCompanionBuilder,
          (ChangeReportEntry, $$ChangeReportsTableReferences),
          ChangeReportEntry,
          PrefetchHooks Function({bool ownerId})
        > {
  $$ChangeReportsTableTableManager(_$AppDatabase db, $ChangeReportsTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ChangeReportsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ChangeReportsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ChangeReportsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                Value<String> ownerId = const Value.absent(),
                Value<String> userId = const Value.absent(),
                Value<String> changeType = const Value.absent(),
                Value<DateTime> timestamp = const Value.absent(),
                Value<String?> userSnapshotJson = const Value.absent(),
              }) => ChangeReportsCompanion(
                id: id,
                ownerId: ownerId,
                userId: userId,
                changeType: changeType,
                timestamp: timestamp,
                userSnapshotJson: userSnapshotJson,
              ),
          createCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                required String ownerId,
                required String userId,
                required String changeType,
                required DateTime timestamp,
                Value<String?> userSnapshotJson = const Value.absent(),
              }) => ChangeReportsCompanion.insert(
                id: id,
                ownerId: ownerId,
                userId: userId,
                changeType: changeType,
                timestamp: timestamp,
                userSnapshotJson: userSnapshotJson,
              ),
          withReferenceMapper: (p0) => p0
              .map(
                (e) => (
                  e.readTable(table),
                  $$ChangeReportsTableReferences(db, table, e),
                ),
              )
              .toList(),
          prefetchHooksCallback: ({ownerId = false}) {
            return PrefetchHooks(
              db: db,
              explicitlyWatchedTables: [],
              addJoins:
                  <
                    T extends TableManagerState<
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic
                    >
                  >(state) {
                    if (ownerId) {
                      state =
                          state.withJoin(
                                currentTable: table,
                                currentColumn: table.ownerId,
                                referencedTable: $$ChangeReportsTableReferences
                                    ._ownerIdTable(db),
                                referencedColumn: $$ChangeReportsTableReferences
                                    ._ownerIdTable(db)
                                    .restId,
                              )
                              as T;
                    }

                    return state;
                  },
              getPrefetchedDataCallback: (items) async {
                return [];
              },
            );
          },
        ),
      );
}

typedef $$ChangeReportsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ChangeReportsTable,
      ChangeReportEntry,
      $$ChangeReportsTableFilterComposer,
      $$ChangeReportsTableOrderingComposer,
      $$ChangeReportsTableAnnotationComposer,
      $$ChangeReportsTableCreateCompanionBuilder,
      $$ChangeReportsTableUpdateCompanionBuilder,
      (ChangeReportEntry, $$ChangeReportsTableReferences),
      ChangeReportEntry,
      PrefetchHooks Function({bool ownerId})
    >;
typedef $$TwiUserMediaTableCreateCompanionBuilder =
    TwiUserMediaCompanion Function({
      Value<int> id,
      required String mediaType,
      required String localFilePath,
      required String remoteUrlHash,
      Value<bool> isHighQuality,
    });
typedef $$TwiUserMediaTableUpdateCompanionBuilder =
    TwiUserMediaCompanion Function({
      Value<int> id,
      Value<String> mediaType,
      Value<String> localFilePath,
      Value<String> remoteUrlHash,
      Value<bool> isHighQuality,
    });

class $$TwiUserMediaTableFilterComposer
    extends Composer<_$AppDatabase, $TwiUserMediaTable> {
  $$TwiUserMediaTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get mediaType => $composableBuilder(
    column: $table.mediaType,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get localFilePath => $composableBuilder(
    column: $table.localFilePath,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get remoteUrlHash => $composableBuilder(
    column: $table.remoteUrlHash,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<bool> get isHighQuality => $composableBuilder(
    column: $table.isHighQuality,
    builder: (column) => ColumnFilters(column),
  );
}

class $$TwiUserMediaTableOrderingComposer
    extends Composer<_$AppDatabase, $TwiUserMediaTable> {
  $$TwiUserMediaTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get mediaType => $composableBuilder(
    column: $table.mediaType,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get localFilePath => $composableBuilder(
    column: $table.localFilePath,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get remoteUrlHash => $composableBuilder(
    column: $table.remoteUrlHash,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<bool> get isHighQuality => $composableBuilder(
    column: $table.isHighQuality,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$TwiUserMediaTableAnnotationComposer
    extends Composer<_$AppDatabase, $TwiUserMediaTable> {
  $$TwiUserMediaTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get mediaType =>
      $composableBuilder(column: $table.mediaType, builder: (column) => column);

  GeneratedColumn<String> get localFilePath => $composableBuilder(
    column: $table.localFilePath,
    builder: (column) => column,
  );

  GeneratedColumn<String> get remoteUrlHash => $composableBuilder(
    column: $table.remoteUrlHash,
    builder: (column) => column,
  );

  GeneratedColumn<bool> get isHighQuality => $composableBuilder(
    column: $table.isHighQuality,
    builder: (column) => column,
  );
}

class $$TwiUserMediaTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $TwiUserMediaTable,
          TwiUserMediaEntry,
          $$TwiUserMediaTableFilterComposer,
          $$TwiUserMediaTableOrderingComposer,
          $$TwiUserMediaTableAnnotationComposer,
          $$TwiUserMediaTableCreateCompanionBuilder,
          $$TwiUserMediaTableUpdateCompanionBuilder,
          (
            TwiUserMediaEntry,
            BaseReferences<
              _$AppDatabase,
              $TwiUserMediaTable,
              TwiUserMediaEntry
            >,
          ),
          TwiUserMediaEntry,
          PrefetchHooks Function()
        > {
  $$TwiUserMediaTableTableManager(_$AppDatabase db, $TwiUserMediaTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$TwiUserMediaTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$TwiUserMediaTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$TwiUserMediaTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                Value<String> mediaType = const Value.absent(),
                Value<String> localFilePath = const Value.absent(),
                Value<String> remoteUrlHash = const Value.absent(),
                Value<bool> isHighQuality = const Value.absent(),
              }) => TwiUserMediaCompanion(
                id: id,
                mediaType: mediaType,
                localFilePath: localFilePath,
                remoteUrlHash: remoteUrlHash,
                isHighQuality: isHighQuality,
              ),
          createCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                required String mediaType,
                required String localFilePath,
                required String remoteUrlHash,
                Value<bool> isHighQuality = const Value.absent(),
              }) => TwiUserMediaCompanion.insert(
                id: id,
                mediaType: mediaType,
                localFilePath: localFilePath,
                remoteUrlHash: remoteUrlHash,
                isHighQuality: isHighQuality,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$TwiUserMediaTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $TwiUserMediaTable,
      TwiUserMediaEntry,
      $$TwiUserMediaTableFilterComposer,
      $$TwiUserMediaTableOrderingComposer,
      $$TwiUserMediaTableAnnotationComposer,
      $$TwiUserMediaTableCreateCompanionBuilder,
      $$TwiUserMediaTableUpdateCompanionBuilder,
      (
        TwiUserMediaEntry,
        BaseReferences<_$AppDatabase, $TwiUserMediaTable, TwiUserMediaEntry>,
      ),
      TwiUserMediaEntry,
      PrefetchHooks Function()
    >;
typedef $$TwiUserRelationshipTableCreateCompanionBuilder =
    TwiUserRelationshipCompanion Function({
      Value<int> id,
      required String runId,
      required String ownerId,
      required String restId,
      Value<bool> isFollowing,
      Value<bool> isFollower,
      Value<bool> canDm,
      Value<bool> canMediaTag,
    });
typedef $$TwiUserRelationshipTableUpdateCompanionBuilder =
    TwiUserRelationshipCompanion Function({
      Value<int> id,
      Value<String> runId,
      Value<String> ownerId,
      Value<String> restId,
      Value<bool> isFollowing,
      Value<bool> isFollower,
      Value<bool> canDm,
      Value<bool> canMediaTag,
    });

class $$TwiUserRelationshipTableFilterComposer
    extends Composer<_$AppDatabase, $TwiUserRelationshipTable> {
  $$TwiUserRelationshipTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get runId => $composableBuilder(
    column: $table.runId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ownerId => $composableBuilder(
    column: $table.ownerId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get restId => $composableBuilder(
    column: $table.restId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<bool> get isFollowing => $composableBuilder(
    column: $table.isFollowing,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<bool> get isFollower => $composableBuilder(
    column: $table.isFollower,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<bool> get canDm => $composableBuilder(
    column: $table.canDm,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<bool> get canMediaTag => $composableBuilder(
    column: $table.canMediaTag,
    builder: (column) => ColumnFilters(column),
  );
}

class $$TwiUserRelationshipTableOrderingComposer
    extends Composer<_$AppDatabase, $TwiUserRelationshipTable> {
  $$TwiUserRelationshipTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get runId => $composableBuilder(
    column: $table.runId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ownerId => $composableBuilder(
    column: $table.ownerId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get restId => $composableBuilder(
    column: $table.restId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<bool> get isFollowing => $composableBuilder(
    column: $table.isFollowing,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<bool> get isFollower => $composableBuilder(
    column: $table.isFollower,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<bool> get canDm => $composableBuilder(
    column: $table.canDm,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<bool> get canMediaTag => $composableBuilder(
    column: $table.canMediaTag,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$TwiUserRelationshipTableAnnotationComposer
    extends Composer<_$AppDatabase, $TwiUserRelationshipTable> {
  $$TwiUserRelationshipTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get runId =>
      $composableBuilder(column: $table.runId, builder: (column) => column);

  GeneratedColumn<String> get ownerId =>
      $composableBuilder(column: $table.ownerId, builder: (column) => column);

  GeneratedColumn<String> get restId =>
      $composableBuilder(column: $table.restId, builder: (column) => column);

  GeneratedColumn<bool> get isFollowing => $composableBuilder(
    column: $table.isFollowing,
    builder: (column) => column,
  );

  GeneratedColumn<bool> get isFollower => $composableBuilder(
    column: $table.isFollower,
    builder: (column) => column,
  );

  GeneratedColumn<bool> get canDm =>
      $composableBuilder(column: $table.canDm, builder: (column) => column);

  GeneratedColumn<bool> get canMediaTag => $composableBuilder(
    column: $table.canMediaTag,
    builder: (column) => column,
  );
}

class $$TwiUserRelationshipTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $TwiUserRelationshipTable,
          TwiUserRelationshipEntry,
          $$TwiUserRelationshipTableFilterComposer,
          $$TwiUserRelationshipTableOrderingComposer,
          $$TwiUserRelationshipTableAnnotationComposer,
          $$TwiUserRelationshipTableCreateCompanionBuilder,
          $$TwiUserRelationshipTableUpdateCompanionBuilder,
          (
            TwiUserRelationshipEntry,
            BaseReferences<
              _$AppDatabase,
              $TwiUserRelationshipTable,
              TwiUserRelationshipEntry
            >,
          ),
          TwiUserRelationshipEntry,
          PrefetchHooks Function()
        > {
  $$TwiUserRelationshipTableTableManager(
    _$AppDatabase db,
    $TwiUserRelationshipTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$TwiUserRelationshipTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$TwiUserRelationshipTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer: () =>
              $$TwiUserRelationshipTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                Value<String> runId = const Value.absent(),
                Value<String> ownerId = const Value.absent(),
                Value<String> restId = const Value.absent(),
                Value<bool> isFollowing = const Value.absent(),
                Value<bool> isFollower = const Value.absent(),
                Value<bool> canDm = const Value.absent(),
                Value<bool> canMediaTag = const Value.absent(),
              }) => TwiUserRelationshipCompanion(
                id: id,
                runId: runId,
                ownerId: ownerId,
                restId: restId,
                isFollowing: isFollowing,
                isFollower: isFollower,
                canDm: canDm,
                canMediaTag: canMediaTag,
              ),
          createCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                required String runId,
                required String ownerId,
                required String restId,
                Value<bool> isFollowing = const Value.absent(),
                Value<bool> isFollower = const Value.absent(),
                Value<bool> canDm = const Value.absent(),
                Value<bool> canMediaTag = const Value.absent(),
              }) => TwiUserRelationshipCompanion.insert(
                id: id,
                runId: runId,
                ownerId: ownerId,
                restId: restId,
                isFollowing: isFollowing,
                isFollower: isFollower,
                canDm: canDm,
                canMediaTag: canMediaTag,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$TwiUserRelationshipTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $TwiUserRelationshipTable,
      TwiUserRelationshipEntry,
      $$TwiUserRelationshipTableFilterComposer,
      $$TwiUserRelationshipTableOrderingComposer,
      $$TwiUserRelationshipTableAnnotationComposer,
      $$TwiUserRelationshipTableCreateCompanionBuilder,
      $$TwiUserRelationshipTableUpdateCompanionBuilder,
      (
        TwiUserRelationshipEntry,
        BaseReferences<
          _$AppDatabase,
          $TwiUserRelationshipTable,
          TwiUserRelationshipEntry
        >,
      ),
      TwiUserRelationshipEntry,
      PrefetchHooks Function()
    >;
typedef $$TwiUserStatisticsTableCreateCompanionBuilder =
    TwiUserStatisticsCompanion Function({
      Value<int> id,
      required String runId,
      required String restId,
      Value<int> followersCount,
      Value<int> followingCount,
      Value<int> statusesCount,
      Value<int> listedCount,
      Value<int> favouritesCount,
      Value<int> mediaCount,
    });
typedef $$TwiUserStatisticsTableUpdateCompanionBuilder =
    TwiUserStatisticsCompanion Function({
      Value<int> id,
      Value<String> runId,
      Value<String> restId,
      Value<int> followersCount,
      Value<int> followingCount,
      Value<int> statusesCount,
      Value<int> listedCount,
      Value<int> favouritesCount,
      Value<int> mediaCount,
    });

class $$TwiUserStatisticsTableFilterComposer
    extends Composer<_$AppDatabase, $TwiUserStatisticsTable> {
  $$TwiUserStatisticsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get runId => $composableBuilder(
    column: $table.runId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get restId => $composableBuilder(
    column: $table.restId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get followersCount => $composableBuilder(
    column: $table.followersCount,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get followingCount => $composableBuilder(
    column: $table.followingCount,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get statusesCount => $composableBuilder(
    column: $table.statusesCount,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get listedCount => $composableBuilder(
    column: $table.listedCount,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get favouritesCount => $composableBuilder(
    column: $table.favouritesCount,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get mediaCount => $composableBuilder(
    column: $table.mediaCount,
    builder: (column) => ColumnFilters(column),
  );
}

class $$TwiUserStatisticsTableOrderingComposer
    extends Composer<_$AppDatabase, $TwiUserStatisticsTable> {
  $$TwiUserStatisticsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get runId => $composableBuilder(
    column: $table.runId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get restId => $composableBuilder(
    column: $table.restId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get followersCount => $composableBuilder(
    column: $table.followersCount,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get followingCount => $composableBuilder(
    column: $table.followingCount,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get statusesCount => $composableBuilder(
    column: $table.statusesCount,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get listedCount => $composableBuilder(
    column: $table.listedCount,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get favouritesCount => $composableBuilder(
    column: $table.favouritesCount,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get mediaCount => $composableBuilder(
    column: $table.mediaCount,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$TwiUserStatisticsTableAnnotationComposer
    extends Composer<_$AppDatabase, $TwiUserStatisticsTable> {
  $$TwiUserStatisticsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get runId =>
      $composableBuilder(column: $table.runId, builder: (column) => column);

  GeneratedColumn<String> get restId =>
      $composableBuilder(column: $table.restId, builder: (column) => column);

  GeneratedColumn<int> get followersCount => $composableBuilder(
    column: $table.followersCount,
    builder: (column) => column,
  );

  GeneratedColumn<int> get followingCount => $composableBuilder(
    column: $table.followingCount,
    builder: (column) => column,
  );

  GeneratedColumn<int> get statusesCount => $composableBuilder(
    column: $table.statusesCount,
    builder: (column) => column,
  );

  GeneratedColumn<int> get listedCount => $composableBuilder(
    column: $table.listedCount,
    builder: (column) => column,
  );

  GeneratedColumn<int> get favouritesCount => $composableBuilder(
    column: $table.favouritesCount,
    builder: (column) => column,
  );

  GeneratedColumn<int> get mediaCount => $composableBuilder(
    column: $table.mediaCount,
    builder: (column) => column,
  );
}

class $$TwiUserStatisticsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $TwiUserStatisticsTable,
          TwiUserStatisticsEntry,
          $$TwiUserStatisticsTableFilterComposer,
          $$TwiUserStatisticsTableOrderingComposer,
          $$TwiUserStatisticsTableAnnotationComposer,
          $$TwiUserStatisticsTableCreateCompanionBuilder,
          $$TwiUserStatisticsTableUpdateCompanionBuilder,
          (
            TwiUserStatisticsEntry,
            BaseReferences<
              _$AppDatabase,
              $TwiUserStatisticsTable,
              TwiUserStatisticsEntry
            >,
          ),
          TwiUserStatisticsEntry,
          PrefetchHooks Function()
        > {
  $$TwiUserStatisticsTableTableManager(
    _$AppDatabase db,
    $TwiUserStatisticsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$TwiUserStatisticsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$TwiUserStatisticsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$TwiUserStatisticsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                Value<String> runId = const Value.absent(),
                Value<String> restId = const Value.absent(),
                Value<int> followersCount = const Value.absent(),
                Value<int> followingCount = const Value.absent(),
                Value<int> statusesCount = const Value.absent(),
                Value<int> listedCount = const Value.absent(),
                Value<int> favouritesCount = const Value.absent(),
                Value<int> mediaCount = const Value.absent(),
              }) => TwiUserStatisticsCompanion(
                id: id,
                runId: runId,
                restId: restId,
                followersCount: followersCount,
                followingCount: followingCount,
                statusesCount: statusesCount,
                listedCount: listedCount,
                favouritesCount: favouritesCount,
                mediaCount: mediaCount,
              ),
          createCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                required String runId,
                required String restId,
                Value<int> followersCount = const Value.absent(),
                Value<int> followingCount = const Value.absent(),
                Value<int> statusesCount = const Value.absent(),
                Value<int> listedCount = const Value.absent(),
                Value<int> favouritesCount = const Value.absent(),
                Value<int> mediaCount = const Value.absent(),
              }) => TwiUserStatisticsCompanion.insert(
                id: id,
                runId: runId,
                restId: restId,
                followersCount: followersCount,
                followingCount: followingCount,
                statusesCount: statusesCount,
                listedCount: listedCount,
                favouritesCount: favouritesCount,
                mediaCount: mediaCount,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$TwiUserStatisticsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $TwiUserStatisticsTable,
      TwiUserStatisticsEntry,
      $$TwiUserStatisticsTableFilterComposer,
      $$TwiUserStatisticsTableOrderingComposer,
      $$TwiUserStatisticsTableAnnotationComposer,
      $$TwiUserStatisticsTableCreateCompanionBuilder,
      $$TwiUserStatisticsTableUpdateCompanionBuilder,
      (
        TwiUserStatisticsEntry,
        BaseReferences<
          _$AppDatabase,
          $TwiUserStatisticsTable,
          TwiUserStatisticsEntry
        >,
      ),
      TwiUserStatisticsEntry,
      PrefetchHooks Function()
    >;
typedef $$RunIdsTableCreateCompanionBuilder =
    RunIdsCompanion Function({
      required String runId,
      required String ownerId,
      required DateTime timestamp,
      Value<int> rowid,
    });
typedef $$RunIdsTableUpdateCompanionBuilder =
    RunIdsCompanion Function({
      Value<String> runId,
      Value<String> ownerId,
      Value<DateTime> timestamp,
      Value<int> rowid,
    });

class $$RunIdsTableFilterComposer
    extends Composer<_$AppDatabase, $RunIdsTable> {
  $$RunIdsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get runId => $composableBuilder(
    column: $table.runId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ownerId => $composableBuilder(
    column: $table.ownerId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get timestamp => $composableBuilder(
    column: $table.timestamp,
    builder: (column) => ColumnFilters(column),
  );
}

class $$RunIdsTableOrderingComposer
    extends Composer<_$AppDatabase, $RunIdsTable> {
  $$RunIdsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get runId => $composableBuilder(
    column: $table.runId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ownerId => $composableBuilder(
    column: $table.ownerId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get timestamp => $composableBuilder(
    column: $table.timestamp,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$RunIdsTableAnnotationComposer
    extends Composer<_$AppDatabase, $RunIdsTable> {
  $$RunIdsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get runId =>
      $composableBuilder(column: $table.runId, builder: (column) => column);

  GeneratedColumn<String> get ownerId =>
      $composableBuilder(column: $table.ownerId, builder: (column) => column);

  GeneratedColumn<DateTime> get timestamp =>
      $composableBuilder(column: $table.timestamp, builder: (column) => column);
}

class $$RunIdsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $RunIdsTable,
          RunIdsEntry,
          $$RunIdsTableFilterComposer,
          $$RunIdsTableOrderingComposer,
          $$RunIdsTableAnnotationComposer,
          $$RunIdsTableCreateCompanionBuilder,
          $$RunIdsTableUpdateCompanionBuilder,
          (
            RunIdsEntry,
            BaseReferences<_$AppDatabase, $RunIdsTable, RunIdsEntry>,
          ),
          RunIdsEntry,
          PrefetchHooks Function()
        > {
  $$RunIdsTableTableManager(_$AppDatabase db, $RunIdsTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$RunIdsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$RunIdsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$RunIdsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<String> runId = const Value.absent(),
                Value<String> ownerId = const Value.absent(),
                Value<DateTime> timestamp = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => RunIdsCompanion(
                runId: runId,
                ownerId: ownerId,
                timestamp: timestamp,
                rowid: rowid,
              ),
          createCompanionCallback:
              ({
                required String runId,
                required String ownerId,
                required DateTime timestamp,
                Value<int> rowid = const Value.absent(),
              }) => RunIdsCompanion.insert(
                runId: runId,
                ownerId: ownerId,
                timestamp: timestamp,
                rowid: rowid,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$RunIdsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $RunIdsTable,
      RunIdsEntry,
      $$RunIdsTableFilterComposer,
      $$RunIdsTableOrderingComposer,
      $$RunIdsTableAnnotationComposer,
      $$RunIdsTableCreateCompanionBuilder,
      $$RunIdsTableUpdateCompanionBuilder,
      (RunIdsEntry, BaseReferences<_$AppDatabase, $RunIdsTable, RunIdsEntry>),
      RunIdsEntry,
      PrefetchHooks Function()
    >;
typedef $$NetworkUserProfileHistoryTableCreateCompanionBuilder =
    NetworkUserProfileHistoryCompanion Function({
      Value<int> id,
      required String runId,
      required String restId,
      required String reverseDiffJson,
      required DateTime timestamp,
    });
typedef $$NetworkUserProfileHistoryTableUpdateCompanionBuilder =
    NetworkUserProfileHistoryCompanion Function({
      Value<int> id,
      Value<String> runId,
      Value<String> restId,
      Value<String> reverseDiffJson,
      Value<DateTime> timestamp,
    });

class $$NetworkUserProfileHistoryTableFilterComposer
    extends Composer<_$AppDatabase, $NetworkUserProfileHistoryTable> {
  $$NetworkUserProfileHistoryTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get runId => $composableBuilder(
    column: $table.runId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get restId => $composableBuilder(
    column: $table.restId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get reverseDiffJson => $composableBuilder(
    column: $table.reverseDiffJson,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get timestamp => $composableBuilder(
    column: $table.timestamp,
    builder: (column) => ColumnFilters(column),
  );
}

class $$NetworkUserProfileHistoryTableOrderingComposer
    extends Composer<_$AppDatabase, $NetworkUserProfileHistoryTable> {
  $$NetworkUserProfileHistoryTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get runId => $composableBuilder(
    column: $table.runId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get restId => $composableBuilder(
    column: $table.restId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get reverseDiffJson => $composableBuilder(
    column: $table.reverseDiffJson,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get timestamp => $composableBuilder(
    column: $table.timestamp,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$NetworkUserProfileHistoryTableAnnotationComposer
    extends Composer<_$AppDatabase, $NetworkUserProfileHistoryTable> {
  $$NetworkUserProfileHistoryTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get runId =>
      $composableBuilder(column: $table.runId, builder: (column) => column);

  GeneratedColumn<String> get restId =>
      $composableBuilder(column: $table.restId, builder: (column) => column);

  GeneratedColumn<String> get reverseDiffJson => $composableBuilder(
    column: $table.reverseDiffJson,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get timestamp =>
      $composableBuilder(column: $table.timestamp, builder: (column) => column);
}

class $$NetworkUserProfileHistoryTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $NetworkUserProfileHistoryTable,
          NetworkUserProfileHistoryEntry,
          $$NetworkUserProfileHistoryTableFilterComposer,
          $$NetworkUserProfileHistoryTableOrderingComposer,
          $$NetworkUserProfileHistoryTableAnnotationComposer,
          $$NetworkUserProfileHistoryTableCreateCompanionBuilder,
          $$NetworkUserProfileHistoryTableUpdateCompanionBuilder,
          (
            NetworkUserProfileHistoryEntry,
            BaseReferences<
              _$AppDatabase,
              $NetworkUserProfileHistoryTable,
              NetworkUserProfileHistoryEntry
            >,
          ),
          NetworkUserProfileHistoryEntry,
          PrefetchHooks Function()
        > {
  $$NetworkUserProfileHistoryTableTableManager(
    _$AppDatabase db,
    $NetworkUserProfileHistoryTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$NetworkUserProfileHistoryTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer: () =>
              $$NetworkUserProfileHistoryTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer: () =>
              $$NetworkUserProfileHistoryTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                Value<String> runId = const Value.absent(),
                Value<String> restId = const Value.absent(),
                Value<String> reverseDiffJson = const Value.absent(),
                Value<DateTime> timestamp = const Value.absent(),
              }) => NetworkUserProfileHistoryCompanion(
                id: id,
                runId: runId,
                restId: restId,
                reverseDiffJson: reverseDiffJson,
                timestamp: timestamp,
              ),
          createCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                required String runId,
                required String restId,
                required String reverseDiffJson,
                required DateTime timestamp,
              }) => NetworkUserProfileHistoryCompanion.insert(
                id: id,
                runId: runId,
                restId: restId,
                reverseDiffJson: reverseDiffJson,
                timestamp: timestamp,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$NetworkUserProfileHistoryTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $NetworkUserProfileHistoryTable,
      NetworkUserProfileHistoryEntry,
      $$NetworkUserProfileHistoryTableFilterComposer,
      $$NetworkUserProfileHistoryTableOrderingComposer,
      $$NetworkUserProfileHistoryTableAnnotationComposer,
      $$NetworkUserProfileHistoryTableCreateCompanionBuilder,
      $$NetworkUserProfileHistoryTableUpdateCompanionBuilder,
      (
        NetworkUserProfileHistoryEntry,
        BaseReferences<
          _$AppDatabase,
          $NetworkUserProfileHistoryTable,
          NetworkUserProfileHistoryEntry
        >,
      ),
      NetworkUserProfileHistoryEntry,
      PrefetchHooks Function()
    >;
typedef $$NetworkUserStatisticsHistoryTableCreateCompanionBuilder =
    NetworkUserStatisticsHistoryCompanion Function({
      Value<int> id,
      required String runId,
      required String restId,
      required String reverseDiffJson,
      required DateTime timestamp,
    });
typedef $$NetworkUserStatisticsHistoryTableUpdateCompanionBuilder =
    NetworkUserStatisticsHistoryCompanion Function({
      Value<int> id,
      Value<String> runId,
      Value<String> restId,
      Value<String> reverseDiffJson,
      Value<DateTime> timestamp,
    });

class $$NetworkUserStatisticsHistoryTableFilterComposer
    extends Composer<_$AppDatabase, $NetworkUserStatisticsHistoryTable> {
  $$NetworkUserStatisticsHistoryTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get runId => $composableBuilder(
    column: $table.runId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get restId => $composableBuilder(
    column: $table.restId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get reverseDiffJson => $composableBuilder(
    column: $table.reverseDiffJson,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get timestamp => $composableBuilder(
    column: $table.timestamp,
    builder: (column) => ColumnFilters(column),
  );
}

class $$NetworkUserStatisticsHistoryTableOrderingComposer
    extends Composer<_$AppDatabase, $NetworkUserStatisticsHistoryTable> {
  $$NetworkUserStatisticsHistoryTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get runId => $composableBuilder(
    column: $table.runId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get restId => $composableBuilder(
    column: $table.restId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get reverseDiffJson => $composableBuilder(
    column: $table.reverseDiffJson,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get timestamp => $composableBuilder(
    column: $table.timestamp,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$NetworkUserStatisticsHistoryTableAnnotationComposer
    extends Composer<_$AppDatabase, $NetworkUserStatisticsHistoryTable> {
  $$NetworkUserStatisticsHistoryTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get runId =>
      $composableBuilder(column: $table.runId, builder: (column) => column);

  GeneratedColumn<String> get restId =>
      $composableBuilder(column: $table.restId, builder: (column) => column);

  GeneratedColumn<String> get reverseDiffJson => $composableBuilder(
    column: $table.reverseDiffJson,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get timestamp =>
      $composableBuilder(column: $table.timestamp, builder: (column) => column);
}

class $$NetworkUserStatisticsHistoryTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $NetworkUserStatisticsHistoryTable,
          NetworkUserStatisticsHistoryEntry,
          $$NetworkUserStatisticsHistoryTableFilterComposer,
          $$NetworkUserStatisticsHistoryTableOrderingComposer,
          $$NetworkUserStatisticsHistoryTableAnnotationComposer,
          $$NetworkUserStatisticsHistoryTableCreateCompanionBuilder,
          $$NetworkUserStatisticsHistoryTableUpdateCompanionBuilder,
          (
            NetworkUserStatisticsHistoryEntry,
            BaseReferences<
              _$AppDatabase,
              $NetworkUserStatisticsHistoryTable,
              NetworkUserStatisticsHistoryEntry
            >,
          ),
          NetworkUserStatisticsHistoryEntry,
          PrefetchHooks Function()
        > {
  $$NetworkUserStatisticsHistoryTableTableManager(
    _$AppDatabase db,
    $NetworkUserStatisticsHistoryTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$NetworkUserStatisticsHistoryTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer: () =>
              $$NetworkUserStatisticsHistoryTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer: () =>
              $$NetworkUserStatisticsHistoryTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                Value<String> runId = const Value.absent(),
                Value<String> restId = const Value.absent(),
                Value<String> reverseDiffJson = const Value.absent(),
                Value<DateTime> timestamp = const Value.absent(),
              }) => NetworkUserStatisticsHistoryCompanion(
                id: id,
                runId: runId,
                restId: restId,
                reverseDiffJson: reverseDiffJson,
                timestamp: timestamp,
              ),
          createCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                required String runId,
                required String restId,
                required String reverseDiffJson,
                required DateTime timestamp,
              }) => NetworkUserStatisticsHistoryCompanion.insert(
                id: id,
                runId: runId,
                restId: restId,
                reverseDiffJson: reverseDiffJson,
                timestamp: timestamp,
              ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$NetworkUserStatisticsHistoryTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $NetworkUserStatisticsHistoryTable,
      NetworkUserStatisticsHistoryEntry,
      $$NetworkUserStatisticsHistoryTableFilterComposer,
      $$NetworkUserStatisticsHistoryTableOrderingComposer,
      $$NetworkUserStatisticsHistoryTableAnnotationComposer,
      $$NetworkUserStatisticsHistoryTableCreateCompanionBuilder,
      $$NetworkUserStatisticsHistoryTableUpdateCompanionBuilder,
      (
        NetworkUserStatisticsHistoryEntry,
        BaseReferences<
          _$AppDatabase,
          $NetworkUserStatisticsHistoryTable,
          NetworkUserStatisticsHistoryEntry
        >,
      ),
      NetworkUserStatisticsHistoryEntry,
      PrefetchHooks Function()
    >;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$LoggedAccountsTableTableManager get loggedAccounts =>
      $$LoggedAccountsTableTableManager(_db, _db.loggedAccounts);
  $$TwiUserProfileTableTableManager get twiUserProfile =>
      $$TwiUserProfileTableTableManager(_db, _db.twiUserProfile);
  $$ChangeReportsTableTableManager get changeReports =>
      $$ChangeReportsTableTableManager(_db, _db.changeReports);
  $$TwiUserMediaTableTableManager get twiUserMedia =>
      $$TwiUserMediaTableTableManager(_db, _db.twiUserMedia);
  $$TwiUserRelationshipTableTableManager get twiUserRelationship =>
      $$TwiUserRelationshipTableTableManager(_db, _db.twiUserRelationship);
  $$TwiUserStatisticsTableTableManager get twiUserStatistics =>
      $$TwiUserStatisticsTableTableManager(_db, _db.twiUserStatistics);
  $$RunIdsTableTableManager get runIds =>
      $$RunIdsTableTableManager(_db, _db.runIds);
  $$NetworkUserProfileHistoryTableTableManager get networkUserProfileHistory =>
      $$NetworkUserProfileHistoryTableTableManager(
        _db,
        _db.networkUserProfileHistory,
      );
  $$NetworkUserStatisticsHistoryTableTableManager
  get networkUserStatisticsHistory =>
      $$NetworkUserStatisticsHistoryTableTableManager(
        _db,
        _db.networkUserStatisticsHistory,
      );
}
