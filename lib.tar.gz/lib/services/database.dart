import 'dart:io';
import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;

part 'database.g.dart';

@DataClassName('LoggedAccount')
class LoggedAccounts extends Table {
  TextColumn get restId => text()();
  @override
  Set<Column> get primaryKey => {restId};
}

@DataClassName('TwiUserProfileEntry')
class TwiUserProfile extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get runId => text().named('run_id')();
  TextColumn get restId => text().named('rest_id')();
  TextColumn get name => text().named('name').nullable()();
  TextColumn get screenName => text().named('screen_name').nullable()();
  TextColumn get avatarUrl => text().named('avatar_url').nullable()();
  TextColumn get bannerUrl => text().named('banner_url').nullable()();
  TextColumn get bio => text().named('bio').nullable()();
  TextColumn get link => text().named('link').nullable()();
  TextColumn get avatarLocalPath =>
      text().named('avatar_local_path').nullable()();
  TextColumn get bannerLocalPath =>
      text().named('banner_local_path').nullable()();
  TextColumn get location => text().named('location').nullable()();
  TextColumn get pinnedTweetIdStr =>
      text().named('pinned_tweet_id_str').nullable()();
  TextColumn get parodyCommentaryFanLabel =>
      text().named('parody_commentary_fan_label').nullable()();
  TextColumn get birthdateYear => text().named('birthdate_year').nullable()();
  TextColumn get birthdateMonth => text().named('birthdate_month').nullable()();
  TextColumn get birthdateDay => text().named('birthdate_day').nullable()();
  TextColumn get automatedScreenName =>
      text().named('automated_screen_name').nullable()();
  TextColumn get joinedTime => text().named('joined_time').nullable()();
  BoolColumn get isVerified =>
      boolean().named('is_verified').withDefault(const Constant(false))();
  BoolColumn get isProtected =>
      boolean().named('is_protected').withDefault(const Constant(false))();
  
  @override
  List<String> get customConstraints => [
    'UNIQUE(run_id, rest_id)'
  ];
}

@DataClassName('TwiUserStatisticsEntry')
class TwiUserStatistics extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get runId => text().named('run_id')();
  TextColumn get restId => text().named('rest_id')();
  IntColumn get followersCount =>
      integer().named('followers_count').withDefault(const Constant(0))();
  IntColumn get followingCount =>
      integer().named('following_count').withDefault(const Constant(0))();
  IntColumn get statusesCount =>
      integer().named('statuses_count').withDefault(const Constant(0))();
  IntColumn get listedCount =>
      integer().named('listed_count').withDefault(const Constant(0))();
  IntColumn get favouritesCount =>
      integer().named('favourites_count').withDefault(const Constant(0))();
  IntColumn get mediaCount =>
      integer().named('media_count').withDefault(const Constant(0))();
      
  @override
  List<String> get customConstraints => [
    'UNIQUE(run_id, rest_id)'
  ];
}

@DataClassName('TwiUserRelationshipEntry')
class TwiUserRelationship extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get runId => text().named('run_id')();
  TextColumn get ownerId => text().named('owner_id')();
  TextColumn get restId => text().named('rest_id')();
  BoolColumn get isFollowing =>
      boolean().named('is_following').withDefault(const Constant(false))();
  BoolColumn get isFollower =>
      boolean().named('is_follower').withDefault(const Constant(false))();
  BoolColumn get canDm =>
      boolean().named('can_dm').withDefault(const Constant(false))();
  BoolColumn get canMediaTag =>
      boolean().named('can_media_tag').withDefault(const Constant(false))();

  @override
  List<String> get customConstraints => [
    'UNIQUE(run_id, owner_id, rest_id)'
  ];
}

@DataClassName('ChangeReportEntry')
class ChangeReports extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get ownerId => text()
      .named('owner_id')
      .references(LoggedAccounts, #restId, onDelete: KeyAction.cascade)();
  TextColumn get userId => text().named('user_id')();
  TextColumn get changeType => text().named('change_type')();
  DateTimeColumn get timestamp => dateTime()();
  TextColumn get userSnapshotJson =>
      text().named('user_snapshot_json').nullable()();
}

@DataClassName('TwiUserMediaEntry')
class TwiUserMedia extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get mediaType => text().named('media_type')();
  TextColumn get localFilePath => text().named('local_file_path')();
  TextColumn get remoteUrlHash => text().named('remote_url_hash')();
  BoolColumn get isHighQuality =>
      boolean().named('is_high_quality').withDefault(const Constant(false))();
  
  @override
  List<String> get customConstraints => [
    'UNIQUE(remote_url_hash, media_type)'
  ];
}

@DataClassName('RunIdsEntry')
class RunIds extends Table {
  TextColumn get runId => text().named('run_id')();
  TextColumn get ownerId => text().named('owner_id')();
  DateTimeColumn get timestamp => dateTime().named('timestamp')();
  @override
  Set<Column> get primaryKey => {runId};
}

// --- 新增：网络用户 Profile 历史表 ---
@DataClassName('NetworkUserProfileHistoryEntry')
class NetworkUserProfileHistory extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get runId => text().named('run_id')();
  TextColumn get restId => text().named('rest_id')();
  TextColumn get reverseDiffJson => text().named('reverse_diff_json')();
  DateTimeColumn get timestamp => dateTime()();
}

// --- 新增：网络用户 Statistics 历史表 ---
@DataClassName('NetworkUserStatisticsHistoryEntry')
class NetworkUserStatisticsHistory extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get runId => text().named('run_id')();
  TextColumn get restId => text().named('rest_id')();
  TextColumn get reverseDiffJson => text().named('reverse_diff_json')();
  DateTimeColumn get timestamp => dateTime()();
}

@DriftDatabase(
  tables: [
    LoggedAccounts,
    TwiUserProfile,
    ChangeReports,
    TwiUserMedia,
    TwiUserRelationship,
    TwiUserStatistics,
    RunIds,
    NetworkUserProfileHistory,    // 新增
    NetworkUserStatisticsHistory, // 新增
  ],
)
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());

  @override
  int get schemaVersion => 1; // 记得增加版本号并迁移，或卸载重装 App

  Future<List<NetworkUser>> getNetworkUsers(String runId) async {
    final profiles = await (select(
      twiUserProfile,
    )..where((tbl) => tbl.runId.equals(runId)))
        .get();

    final statisticsList = await (select(
      twiUserStatistics,
    )..where((tbl) => tbl.runId.equals(runId)))
        .get();

    final relationships = await (select(
      twiUserRelationship,
    )..where((tbl) => tbl.runId.equals(runId)))
        .get();

    final statMap = {for (var s in statisticsList) s.restId: s};
    final relMap = {for (var r in relationships) r.restId: r};

    final networkUsers = <NetworkUser>[];

    for (var profile in profiles) {
      final stats = statMap[profile.restId];
      final rel = relMap[profile.restId];
      if (stats != null && rel != null) {
        networkUsers.add(
          NetworkUser(profile: profile, statistics: stats, relationship: rel),
        );
      }
    }

    return networkUsers;
  }

  Future<void> batchUpsertNetworkUsers(List<NetworkUser> users) async {
    await batch((batch) {
      batch.insertAll(
        twiUserProfile,
        users.map((u) => u.profile.toCompanion(false)),
        mode: InsertMode.replace,
      );
      batch.insertAll(
        twiUserStatistics,
        users.map((u) => u.statistics.toCompanion(false)),
        mode: InsertMode.replace,
      );
      batch.insertAll(
        twiUserRelationship,
        users.map((u) => u.relationship.toCompanion(false)),
        mode: InsertMode.replace,
      );
    });
  }

  Future<void> deleteNetworkUsers(
    String runId,
    List<String> restIdsToRemove,
  ) async {
    await (delete(twiUserProfile)
          ..where(
              (tbl) => tbl.runId.equals(runId) & tbl.restId.isIn(restIdsToRemove)))
        .go();
    await (delete(twiUserStatistics)
          ..where(
              (tbl) => tbl.runId.equals(runId) & tbl.restId.isIn(restIdsToRemove)))
        .go();
    await (delete(twiUserRelationship)
          ..where(
              (tbl) => tbl.runId.equals(runId) & tbl.restId.isIn(restIdsToRemove)))
        .go();
  }

  Future<void> updateUserLocalPaths(
    String runId,
    String restId, {
    String? avatarPath,
    String? bannerPath,
  }) {
    final companion = TwiUserProfileCompanion(
      avatarLocalPath:
          avatarPath == null ? const Value.absent() : Value(avatarPath),
      bannerLocalPath:
          bannerPath == null ? const Value.absent() : Value(bannerPath),
    );
    return (update(twiUserProfile)
          ..where((tbl) => tbl.runId.equals(runId) & tbl.restId.equals(restId)))
        .write(companion);
  }

  Future<int> insertTwiUserMedia(TwiUserMediaCompanion companion) {
    return into(twiUserMedia).insert(companion, mode: InsertMode.replace);
  }

  Future<void> replaceChangeReport(
    String ownerId,
    List<ChangeReportsCompanion> reportCompanions,
  ) async {
    await transaction(() async {
      await (delete(
        changeReports,
      )..where((tbl) => tbl.ownerId.equals(ownerId.toString())))
          .go();
      await batch((batch) {
        batch.insertAll(changeReports, reportCompanions);
      });
    });
  }

  // --- 新增：批量插入历史的方法 ---

  Future<void> batchInsertNetworkUserProfileHistory(
    List<NetworkUserProfileHistoryCompanion> historyCompanions,
  ) async {
    if (historyCompanions.isEmpty) return;
    await batch((batch) {
      batch.insertAll(networkUserProfileHistory, historyCompanions);
    });
  }

  Future<void> batchInsertNetworkUserStatisticsHistory(
    List<NetworkUserStatisticsHistoryCompanion> historyCompanions,
  ) async {
    if (historyCompanions.isEmpty) return;
    await batch((batch) {
      batch.insertAll(networkUserStatisticsHistory, historyCompanions);
    });
  }
}

class NetworkUser {
  final TwiUserProfileEntry profile;
  final TwiUserStatisticsEntry statistics;
  final TwiUserRelationshipEntry relationship;

  NetworkUser({
    required this.profile,
    required this.statistics,
    required this.relationship,
  });
}

extension TwiUserProfileEntryX on TwiUserProfileEntry {
  TwiUserProfileCompanion toCompanion() {
    return TwiUserProfileCompanion(
      id: Value(id),
      runId: Value(runId),
      restId: Value(restId),
      name: Value(name),
      screenName: Value(screenName),
      avatarUrl: Value(avatarUrl),
      bannerUrl: Value(bannerUrl),
      bio: Value(bio),
      link: Value(link),
      avatarLocalPath: Value(avatarLocalPath),
      bannerLocalPath: Value(bannerLocalPath),
      location: Value(location),
      pinnedTweetIdStr: Value(pinnedTweetIdStr),
      parodyCommentaryFanLabel: Value(parodyCommentaryFanLabel),
      birthdateYear: Value(birthdateYear),
      birthdateMonth: Value(birthdateMonth),
      birthdateDay: Value(birthdateDay),
      automatedScreenName: Value(automatedScreenName),
      joinedTime: Value(joinedTime),
      isVerified: Value(isVerified),
      isProtected: Value(isProtected),
    );
  }
}

extension TwiUserStatisticsEntryX on TwiUserStatisticsEntry {
  TwiUserStatisticsCompanion toCompanion() {
    return TwiUserStatisticsCompanion(
      id: Value(id),
      runId: Value(runId),
      restId: Value(restId),
      followersCount: Value(followersCount),
      followingCount: Value(followingCount),
      statusesCount: Value(statusesCount),
      listedCount: Value(listedCount),
      favouritesCount: Value(favouritesCount),
      mediaCount: Value(mediaCount),
    );
  }
}

extension TwiUserRelationshipEntryX on TwiUserRelationshipEntry {
  TwiUserRelationshipCompanion toCompanion() {
    return TwiUserRelationshipCompanion(
      id: Value(id),
      runId: Value(runId),
      ownerId: Value(ownerId),
      restId: Value(restId),
      isFollowing: Value(isFollowing),
      isFollower: Value(isFollower),
      canDm: Value(canDm),
      canMediaTag: Value(canMediaTag),
    );
  }
}

extension AppDatabaseNetworkUserX on AppDatabase {
  Future<List<NetworkUser>> getNetworkUsers(String ownerId) async {
    final profiles = await (select(
      twiUserProfile,
    )..where((tbl) => tbl.runId.equals(ownerId)))
        .get();
    final statisticsList = await (select(
      twiUserStatistics,
    )..where((tbl) => tbl.runId.equals(ownerId)))
        .get();
    final relationships = await (select(
      twiUserRelationship,
    )..where((tbl) => tbl.runId.equals(ownerId)))
        .get();
    final statMap = {for (var s in statisticsList) s.restId: s};
    final relMap = {for (var r in relationships) r.restId.toString(): r};
    final networkUsers = <NetworkUser>[];
    for (var profile in profiles) {
      final stats = statMap[profile.restId];
      final rel = relMap[profile.restId];
      if (stats != null && rel != null) {
        networkUsers.add(
          NetworkUser(profile: profile, statistics: stats, relationship: rel),
        );
      }
    }
    return networkUsers;
  }

  Future<void> batchUpsertNetworkUsers(List<NetworkUser> users) async {
    await batch((batch) {
      batch.insertAll(
        twiUserProfile,
        users.map((u) => u.profile.toCompanion(false)),
        mode: InsertMode.replace,
      );
      batch.insertAll(
        twiUserStatistics,
        users.map((u) => u.statistics.toCompanion(false)),
        mode: InsertMode.replace,
      );
      batch.insertAll(
        twiUserRelationship,
        users.map((u) => u.relationship.toCompanion(false)),
        mode: InsertMode.replace,
      );
    });
  }

  Future<void> deleteNetworkUsers(
    String ownerId,
    List<String> restIdsToRemove,
  ) async {
    await (delete(twiUserProfile)
          ..where(
              (tbl) => tbl.runId.equals(ownerId) & tbl.restId.isIn(restIdsToRemove)))
        .go();
    await (delete(twiUserStatistics)
          ..where(
              (tbl) =>
                  tbl.runId.equals(ownerId) &
                  tbl.restId.isIn(restIdsToRemove)))
        .go();
    await (delete(twiUserRelationship)
          ..where(
              (tbl) =>
                  tbl.runId.equals(ownerId) &
                  tbl.restId.isIn(restIdsToRemove)))
        .go();
  }

  Future<void> updateUserLocalPaths(
    String runId,
    String restId, {
    String? avatarPath,
    String? bannerPath,
  }) {
    final companion = TwiUserProfileCompanion(
      avatarLocalPath:
          avatarPath == null ? const Value.absent() : Value(avatarPath),
      bannerLocalPath:
          bannerPath == null ? const Value.absent() : Value(bannerPath),
    );
    return (update(twiUserProfile)
          ..where((tbl) => tbl.runId.equals(runId) & tbl.restId.equals(restId)))
        .write(companion);
  }
}

extension AppDatabaseFollowersX on AppDatabase {
  Future<Map<String, int>> getFollowersFollowingCount(String ownerId) async {
    final latestRunId = await getLatestRunId(ownerId);
    if (latestRunId == null) return {'followers': 0, 'following': 0};

    final networkUsers = await getNetworkUsers(latestRunId);
    int followersCount = 0;
    int followingCount = 0;

    for (var user in networkUsers) {
      followersCount += user.relationship.isFollower ? 1 : 0;
      followingCount += user.relationship.isFollowing ? 1 : 0;
    }

    return {
      'followers': followersCount,
      'following': followingCount,
    };
  }
}

extension AppDatabaseRunIdX on AppDatabase {
  Future<String?> getLatestRunId(String ownerId) async {
    final runs = await (select(runIds)
          ..where((tbl) => tbl.ownerId.equals(ownerId))
          ..orderBy([
            (tbl) => OrderingTerm(
                expression: tbl.timestamp, mode: OrderingMode.desc)
          ])
          ..limit(1))
        .get();

    if (runs.isEmpty) return null;
    return runs.first.runId;
  }
}

LazyDatabase _openConnection() {
  return LazyDatabase(() async {
    final dbFolder = await getApplicationSupportDirectory();
    await Directory(dbFolder.path).create(recursive: true);
    final file = File(p.join(dbFolder.path, 'autonitor_data.db'));
    return NativeDatabase(file);
  });
}