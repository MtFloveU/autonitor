import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:drift/drift.dart';
import 'dart:convert';
import '../models/account.dart';
import '../services/database.dart';
import '../services/twitter_api_service.dart';
import '../services/secure_storage_service.dart';
import '../main.dart';
// import '../utils/diff_utils.dart'; // 已移除
import 'package:autonitor/services/log_service.dart';
import '../models/app_settings.dart';
import '../providers/settings_provider.dart';
import '../services/image_history_service.dart';

final accountRepositoryProvider = Provider<AccountRepository>((ref) {
  final db = ref.watch(databaseProvider);
  final apiService = ref.watch(twitterApiServiceProvider);
  final secureStorage = ref.watch(secureStorageServiceProvider);
  return AccountRepository(db, apiService, secureStorage, ref);
});

class AccountRepository {
  final AppDatabase _database;
  final TwitterApiService _apiService;
  final SecureStorageService _secureStorage;
  final Ref _ref;

  AccountRepository(
    this._database,
    this._apiService,
    this._secureStorage,
    this._ref,
  );

  String? _parseidFromCookie(String cookie) {
    try {
      final parts = cookie.split(';');
      final idPart = parts.firstWhere(
        (part) => part.trim().startsWith('twid='),
        orElse: () => '',
      );
      if (idPart.isNotEmpty) {
        var valuePart = idPart.split('=')[1].trim();
        valuePart = Uri.decodeComponent(valuePart);
        if (valuePart.startsWith('u=')) {
          final id = valuePart.substring(2);
          return id.isNotEmpty ? id : null;
        } else if (valuePart.startsWith('u_')) {
          final id = valuePart.substring(2);
          return id.isNotEmpty ? id : null;
        } else {
          logger.w("解析 id 失败: id value ($valuePart) 不以 'u=' 或 'u_' 开头");
          return null;
        }
      }
      return null;
    } catch (e, s) {
      logger.e("Error parsing id from cookie", error: e, stackTrace: s);
      return null;
    }
  }

  Future<Account> addAccount(String cookie) async {
    final id = _parseidFromCookie(cookie);
    if (id == null) {
      throw Exception('Unable to parse ID from Cookie');
    }
    await _secureStorage.saveCookie(id, cookie);
    logger.i("addAccount: Saved cookie to SecureStorage for ID: $id");
    return await _fetchAndSaveAccountProfile(id, cookie);
  }

  Future<void> removeAccount(String id) async {
    try {
      await _secureStorage.deleteCookie(id);
      logger.i(
        "AccountRepository: Deleted cookie from SecureStorage for ID $id.",
      );

      await _database.transaction(() async {
        final deletedLoggedAccount = await (_database.delete(
          _database.loggedAccounts,
        )..where((tbl) => tbl.restId.equals(id))).go();

        await (_database.delete(
          _database.twiUserProfile,
        )..where((tbl) => tbl.restId.equals(id))).go();

        await (_database.delete(
          _database.twiUserStatistics,
        )..where((tbl) => tbl.restId.equals(id))).go();

        await (_database.delete(
          _database.twiUserRelationship,
        )..where((tbl) => tbl.restId.equals(id))).go();

        // AccountProfileHistory 表已不存在，相关删除已移除

        if (deletedLoggedAccount > 0) {
          logger.i("AccountRepository: Deleted account $id from database.");
        } else {
          logger.w(
            "AccountRepository: Tried to delete account $id, but it was not found.",
          );
        }
      });
    } catch (e, s) {
      logger.e(
        "AccountRepository: Error removing account ID $id",
        error: e,
        stackTrace: s,
      );
      throw Exception('Failed to remove account: $e');
    }
  }

  Future<List<Account>> getAllAccounts() async {
    try {
      final loggedAccounts = await _database
          .select(_database.loggedAccounts)
          .get();
      final cookies = await _secureStorage.getAllCookies();

      if (loggedAccounts.isEmpty) {
        return [];
      }

      final accountIds = loggedAccounts.map((a) => a.restId).toList();

      final profiles =
          await (_database.select(_database.twiUserProfile)..where(
                (tbl) =>
                    tbl.restId.isIn(accountIds) & tbl.runId.isIn(accountIds),
              ))
              .get();

      final stats =
          await (_database.select(_database.twiUserStatistics)..where(
                (tbl) =>
                    tbl.restId.isIn(accountIds) & tbl.runId.isIn(accountIds),
              ))
              .get();

      final profileMap = {for (var p in profiles) p.restId: p};
      final statsMap = {for (var s in stats) s.restId: s};

      final List<Account> loadedAccounts = [];
      for (final acc in loggedAccounts) {
        final cookie = cookies[acc.restId];
        final profile = profileMap[acc.restId];
        final stat = statsMap[acc.restId];

        if (cookie != null && profile != null && stat != null) {
          loadedAccounts.add(
            Account(
              id: acc.restId,
              cookie: cookie,
              name: profile.name,
              screenName: profile.screenName,
              avatarUrl: profile.avatarUrl,
              avatarLocalPath: profile.avatarLocalPath,
              bannerUrl: profile.bannerUrl,
              bannerLocalPath: profile.bannerLocalPath,
              bio: profile.bio,
              location: profile.location,
              link: profile.link,
              joinTime: profile.joinedTime,
              followersCount: stat.followersCount,
              followingCount: stat.followingCount,
              statusesCount: stat.statusesCount,
              mediaCount: stat.mediaCount,
              favouritesCount: stat.favouritesCount,
              listedCount: stat.listedCount,
              latestRawJson: null,
              isVerified: profile.isVerified,
              isProtected: profile.isProtected,
              pinnedTweetIdStr: profile.pinnedTweetIdStr,
              parodyCommentaryFanLabel: profile.parodyCommentaryFanLabel,
              birthdateYear: profile.birthdateYear,
              birthdateMonth: profile.birthdateMonth,
              birthdateDay: profile.birthdateDay,
              automatedScreenName: profile.automatedScreenName,
            ),
          );
        } else {
          logger.w(
            "AccountRepository: Account data incomplete for ID ${acc.restId}. Cookie: ${cookie != null}, Profile: ${profile != null}, Stats: ${stat != null}. Skipping.",
          );
        }
      }
      return loadedAccounts;
    } catch (e, s) {
      logger.e(
        "AccountRepository: Error getting all accounts",
        error: e,
        stackTrace: s,
      );
      rethrow;
    }
  }

  Future<Account> refreshAccountProfile(Account account) async {
    return await _fetchAndSaveAccountProfile(account.id, account.cookie);
  }

  Future<Account> _fetchAndSaveAccountProfile(String id, String cookie) async {
    String? name;
    String? screenName;
    String? avatarUrl;
    String? bannerUrl;
    String? bio;
    String? location;
    String? link;
    String? joinTime;
    int followersCount = 0;
    int followingCount = 0;
    int statusesCount = 0;
    int mediaCount = 0;
    int favouritesCount = 0;
    int listedCount = 0;
    String rawJsonString = '{}';
    bool isVerified = false;
    bool isProtected = false;

    String? pinnedTweetIdStr;
    String? parodyCommentaryFanLabel;
    String? birthdateYear;
    String? birthdateMonth;
    String? birthdateDay;
    String? automatedScreenName;

    try {
      final Map<String, dynamic> userProfileJson = await _apiService
          .getUserByRestId(id, cookie);
      rawJsonString = jsonEncode(userProfileJson);
      final result = userProfileJson['data']?['user']?['result'];
      if (result != null &&
          result is Map<String, dynamic> &&
          result['__typename'] == 'User') {
        final core = result['core'];
        final legacy = result['legacy'];
        if (core != null && core is Map<String, dynamic>) {
          name = core['name'] as String?;
          screenName = core['screen_name'] as String?;
          avatarUrl = (result['avatar']['image_url'] as String?);
          joinTime = core['created_at'] as String?;
        }
        if (legacy != null && legacy is Map<String, dynamic>) {
          bio = legacy['description'] as String?;
          followersCount = legacy['followers_count'] as int? ?? 0;
          followingCount = legacy['friends_count'] as int? ?? 0;
          final String? tcoUrl = legacy['url'] as String?;
          String? finalLink = tcoUrl;
          try {
            final entities = legacy['entities'] as Map<String, dynamic>?;
            final urlBlock = entities?['url'] as Map<String, dynamic>?;
            final urlsList = urlBlock?['urls'] as List<dynamic>?;
            if (tcoUrl != null && urlsList != null) {
              for (final item in urlsList) {
                final urlMap = item as Map<String, dynamic>?;
                if (urlMap != null && urlMap['url'] == tcoUrl) {
                  finalLink = urlMap['expanded_url'] as String?;
                  break;
                }
              }
            }
          } catch (e, s) {
            logger.w(
              "addAccount: Failed to parse URL entities",
              error: e,
              stackTrace: s,
            );
          }
          link = finalLink;
          bannerUrl = legacy['profile_banner_url'] as String?;
          statusesCount = legacy['statuses_count'] as int? ?? 0;
          mediaCount = legacy['media_count'] as int? ?? 0;
          favouritesCount = legacy['favourites_count'] as int? ?? 0;
          listedCount = legacy['listed_count'] as int? ?? 0;
          pinnedTweetIdStr =
              (legacy['pinned_tweet_ids_str'] as List?)?.first as String?;
        }

        isVerified = result['verification']['verified'] as bool? ?? false;
        isProtected = result['privacy']['protected'] as bool? ?? false;

        final locationMap = result['location'] as Map<String, dynamic>?;
        location = locationMap?['location'] as String?;

        final birthdateMap = result['birthdate'] as Map<String, dynamic>?;
        if (birthdateMap != null) {
          birthdateYear = birthdateMap['year']?.toString();
          birthdateMonth = birthdateMap['month']?.toString();
          birthdateDay = birthdateMap['day']?.toString();
        }
        parodyCommentaryFanLabel =
            result['parody_commentary_fan_label']?['text'] as String?;
        automatedScreenName =
            (result['affiliates_highlighted_label']?['label']?['longDescription']?['entities']
                    as List?)
                ?.first?['ref']?['mention_results']?['result']?['core']?['screen_name'] ??
            (result['affiliates_highlighted_label']?['label']?['longDescription']?['entities']
                        as List?)
                    ?.first?['ref']?['screen_name']
                as String?;
      } else {
        logger.w(
          "addAccount: The API call succeeded, but the result field is either missing or malformed.",
        );
      }
    } catch (e, s) {
      logger.e(
        "addAccount: Failed to call the API or parse the Profile.",
        error: e,
        stackTrace: s,
      );
      rethrow;
    }

    try {
      final settingsValue = _ref.read(settingsProvider);
      final imageService = _ref.read(imageHistoryServiceProvider);

      final AppSettings settings;
      if (settingsValue is AsyncData<AppSettings>) {
        settings = settingsValue.value;
      } else {
        logger.e("在 AccountRepository 中读取设置失败，状态为: $settingsValue");
        throw Exception("无法执行操作，因为设置未准备好: $settingsValue");
      }

      await _database.transaction(() async {
        final oldProfile = await (_database.select(
          _database.twiUserProfile,
        )..where((tbl) => tbl.restId.equals(id))).getSingleOrNull();

        final String? newAvatarLocalPath = await imageService
            .processMediaUpdate(
              ownerId: id,
              userId: id,
              mediaType: MediaType.avatar,
              oldUrl: oldProfile?.avatarUrl,
              newUrl: avatarUrl,
              settings: settings,
            );

        final String? newBannerLocalPath = await imageService
            .processMediaUpdate(
              ownerId: id,
              userId: id,
              mediaType: MediaType.banner,
              oldUrl: oldProfile?.bannerUrl,
              newUrl: bannerUrl,
              settings: settings,
            );

        final loggedAccountCompanion = LoggedAccountsCompanion(
          restId: Value(id),
        );

        final profileCompanion = TwiUserProfileCompanion(
          runId: Value(id),
          restId: Value(id),
          name: name == null ? const Value.absent() : Value(name),
          screenName: screenName == null
              ? const Value.absent()
              : Value(screenName),
          avatarUrl: avatarUrl == null
              ? const Value.absent()
              : Value(avatarUrl),
          bannerUrl: bannerUrl == null
              ? const Value.absent()
              : Value(bannerUrl),
          bio: bio == null ? const Value.absent() : Value(bio),
          location: location == null ? const Value.absent() : Value(location),
          link: link == null ? const Value.absent() : Value(link),
          joinedTime: joinTime == null ? const Value.absent() : Value(joinTime),
          isVerified: Value(isVerified),
          isProtected: Value(isProtected),
          avatarLocalPath: newAvatarLocalPath != null
              ? Value(newAvatarLocalPath)
              : (avatarUrl == oldProfile?.avatarUrl
                    ? Value(oldProfile?.avatarLocalPath)
                    : const Value.absent()),
          bannerLocalPath: newBannerLocalPath != null
              ? Value(newBannerLocalPath)
              : (bannerUrl == oldProfile?.bannerUrl
                    ? Value(oldProfile?.bannerLocalPath)
                    : const Value.absent()),
          pinnedTweetIdStr: Value(pinnedTweetIdStr),
          parodyCommentaryFanLabel: Value(parodyCommentaryFanLabel),
          birthdateYear: Value(birthdateYear),
          birthdateMonth: Value(birthdateMonth),
          birthdateDay: Value(birthdateDay),
          automatedScreenName: Value(automatedScreenName),
        );

        final statsCompanion = TwiUserStatisticsCompanion(
          runId: Value(id),
          restId: Value(id),
          followersCount: Value(followersCount),
          followingCount: Value(followingCount),
          statusesCount: Value(statusesCount),
          mediaCount: Value(mediaCount),
          favouritesCount: Value(favouritesCount),
          listedCount: Value(listedCount),
        );

        await _database
            .into(_database.loggedAccounts)
            .insert(loggedAccountCompanion, mode: InsertMode.replace);

        await _database
            .into(_database.twiUserProfile)
            .insert(profileCompanion, mode: InsertMode.replace);

        await _database
            .into(_database.twiUserStatistics)
            .insert(statsCompanion, mode: InsertMode.replace);

        logger.i(
          "addAccount: Inserted/Replaced profile data in LoggedAccounts, TwiUserProfile, and TwiUserStatistics for ID: $id",
        );

        // --- 历史记录逻辑已*彻底*移除 (Account 历史已禁用) ---
      });

      return Account(
        id: id,
        cookie: cookie,
        name: name,
        screenName: screenName,
        avatarUrl: avatarUrl,
        bannerUrl: bannerUrl,
        bio: bio,
        location: location,
        link: link,
        joinTime: joinTime,
        followersCount: followersCount,
        followingCount: followingCount,
        statusesCount: statusesCount,
        mediaCount: mediaCount,
        favouritesCount: favouritesCount,
        isVerified: isVerified,
        isProtected: isProtected,
        listedCount: listedCount,
        latestRawJson: rawJsonString,
        pinnedTweetIdStr: pinnedTweetIdStr,
        parodyCommentaryFanLabel: parodyCommentaryFanLabel,
        birthdateYear: birthdateYear,
        birthdateMonth: birthdateMonth,
        birthdateDay: birthdateDay,
        automatedScreenName: automatedScreenName,
      );
    } catch (e, s) {
      logger.e(
        "addAccount: Error during database transaction for ID $id",
        error: e,
        stackTrace: s,
      );
      throw Exception('Failed to save account data: $e');
    }
  }
}
