import 'package:autonitor/main.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/database.dart';
import '../models/twitter_user.dart';
import '../models/account.dart';
import '../utils/runid_generator.dart';
import 'package:drift/drift.dart';
import 'package:autonitor/services/log_service.dart';
import '../utils/diff_utils.dart';

final networkRepositoryProvider = Provider<NetworkRepository>((ref) {
  final db = ref.watch(databaseProvider);
  return NetworkRepository(db);
});

class NetworkRepository {
  final AppDatabase _database;

  NetworkRepository(this._database);

  Future<List<TwitterUser>> getNetworkUsers(String runId) async {
    final List<NetworkUser> dbUsers = await _database.getNetworkUsers(runId);
    return dbUsers.map((dbUser) {
      final profile = dbUser.profile;
      final stats = dbUser.statistics;
      final rel = dbUser.relationship;

      return TwitterUser(
        runId: runId,
        restId: profile.restId,
        name: profile.name,
        screenName: profile.screenName,
        avatarUrl: profile.avatarUrl,
        avatarLocalPath: profile.avatarLocalPath,
        bannerUrl: profile.bannerUrl,
        bannerLocalPath: profile.bannerLocalPath,
        bio: profile.bio,
        location: profile.location,
        pinnedTweetIdStr: profile.pinnedTweetIdStr,
        parodyCommentaryFanLabel: profile.parodyCommentaryFanLabel,
        birthdateYear: profile.birthdateYear,
        birthdateMonth: profile.birthdateMonth,
        birthdateDay: profile.birthdateDay,
        automatedScreenName: profile.automatedScreenName,
        joinedTime: profile.joinedTime,
        link: profile.link,
        isVerified: profile.isVerified,
        isProtected: profile.isProtected,
        followersCount: stats.followersCount,
        followingCount: stats.followingCount,
        statusesCount: stats.statusesCount,
        listedCount: stats.listedCount,
        favouritesCount: stats.favouritesCount,
        mediaCount: stats.mediaCount,
        isFollowing: rel.isFollowing,
        isFollower: rel.isFollower,
        canDm: rel.canDm,
        canMediaTag: rel.canMediaTag,
      );
    }).toList();
  }

  Future<String> saveNetworkRun(
      Account owner, List<TwitterUser> users) async {
    final ownerId = owner.id;
    final runId = generateRunId();
    final timestamp = DateTime.now();

    logger.i(
        'Saving network run $runId for owner $ownerId with ${users.length} users.');

    // 1. 获取上一个 RunId 来进行 diff
    final previousRunId = await _database.getLatestRunId(ownerId);
    List<TwitterUser> previousUsers = [];
    if (previousRunId != null) {
      previousUsers = await getNetworkUsers(previousRunId);
    }
    final previousUserMap = {for (var u in previousUsers) u.restId: u};

    final List<TwiUserProfileCompanion> profileCompanions = [];
    final List<TwiUserStatisticsCompanion> statsCompanions = [];
    final List<TwiUserRelationshipCompanion> relCompanions = [];
    final List<NetworkUserProfileHistoryCompanion> profileHistoryCompanions = [];
    final List<NetworkUserStatisticsHistoryCompanion> statsHistoryCompanions =
        [];

    for (final user in users) {
      profileCompanions.add(TwiUserProfileCompanion(
        runId: Value(runId),
        restId: Value(user.restId),
        name: Value(user.name),
        screenName: Value(user.screenName),
        avatarUrl: Value(user.avatarUrl),
        bannerUrl: Value(user.bannerUrl),
        bio: Value(user.bio),
        link: Value(user.link),
        avatarLocalPath: Value(user.avatarLocalPath),
        bannerLocalPath: Value(user.bannerLocalPath),
        location: Value(user.location),
        pinnedTweetIdStr: Value(user.pinnedTweetIdStr),
        parodyCommentaryFanLabel: Value(user.parodyCommentaryFanLabel),
        birthdateYear: Value(user.birthdateYear),
        birthdateMonth: Value(user.birthdateMonth),
        birthdateDay: Value(user.birthdateDay),
        automatedScreenName: Value(user.automatedScreenName),
        joinedTime: Value(user.joinedTime),
        isVerified: Value(user.isVerified),
        isProtected: Value(user.isProtected),
      ));

      statsCompanions.add(TwiUserStatisticsCompanion(
        runId: Value(runId),
        restId: Value(user.restId),
        followersCount: Value(user.followersCount),
        followingCount: Value(user.followingCount),
        statusesCount: Value(user.statusesCount),
        listedCount: Value(user.listedCount),
        favouritesCount: Value(user.favouritesCount),
        mediaCount: Value(user.mediaCount),
      ));

      relCompanions.add(TwiUserRelationshipCompanion(
        runId: Value(runId),
        ownerId: Value(ownerId),
        restId: Value(user.restId),
        isFollowing: Value(user.isFollowing),
        isFollower: Value(user.isFollower),
        canDm: Value(user.canDm),
        canMediaTag: Value(user.canMediaTag),
      ));

      // --- 核心：创建历史 Diff ---
      final previousUser = previousUserMap[user.restId];
      if (previousUser != null) {
        // 2. Profile Diff
        final String? profileDiff = calculateReverseDiff(
          user.profileAsJson(),
          previousUser.profileAsJson(),
        );
        if (profileDiff != null && profileDiff.isNotEmpty) {
          profileHistoryCompanions.add(
            NetworkUserProfileHistoryCompanion(
              runId: Value(runId),
              restId: Value(user.restId),
              reverseDiffJson: Value(profileDiff),
              timestamp: Value(timestamp),
            ),
          );
        }

        // 3. Statistics Diff
        final String? statsDiff = calculateReverseDiff(
          user.statisticsAsJson(),
          previousUser.statisticsAsJson(),
        );
        if (statsDiff != null && statsDiff.isNotEmpty) {
          statsHistoryCompanions.add(
            NetworkUserStatisticsHistoryCompanion(
              runId: Value(runId),
              restId: Value(user.restId),
              reverseDiffJson: Value(statsDiff),
              timestamp: Value(timestamp),
            ),
          );
        }
      }
    }

    try {
      // 4. 批量插入所有数据
      await _database.batch((batch) {
        batch.insertAll(_database.twiUserProfile, profileCompanions,
            mode: InsertMode.replace);
        batch.insertAll(_database.twiUserStatistics, statsCompanions,
            mode: InsertMode.replace);
        batch.insertAll(_database.twiUserRelationship, relCompanions,
            mode: InsertMode.replace);
      });

      // 5. 批量插入所有历史记录
      await _database
          .batchInsertNetworkUserProfileHistory(profileHistoryCompanions);
      await _database
          .batchInsertNetworkUserStatisticsHistory(statsHistoryCompanions);

      // 6. 最后，插入新的 RunId 记录
      await _database.into(_database.runIds).insert(
            RunIdsEntry(runId: runId, ownerId: ownerId, timestamp: timestamp),
          );

      logger.i(
          'Successfully saved network run $runId with ${profileHistoryCompanions.length} profile changes and ${statsHistoryCompanions.length} stats changes.');
      return runId;
    } catch (e, s) {
      logger.e('Failed to save network run $runId', error: e, stackTrace: s);
      rethrow;
    }
  }

  Future<String?> getLatestRunId(String ownerId) async {
    return _database.getLatestRunId(ownerId);
  }
}